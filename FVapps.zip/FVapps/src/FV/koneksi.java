/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class koneksi {
    public static Connection con;

    public static Connection Getconnection() throws SQLException {
        if (con == null) {
            new Driver();
            con = DriverManager.getConnection("jdbc:mysql://localhost/fvdb", "root", "");
        }
        return con;
    }
}
