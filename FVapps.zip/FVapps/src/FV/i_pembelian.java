/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DwiY
 */
public class i_pembelian extends javax.swing.JInternalFrame {

    /**
     * Creates new form i_pembelian
     */
    int tahun, bulan, hari;

    public i_pembelian() {
        initComponents();
        getdatabarang();
        getdatastok();
        hapus_jenis();
        c_tampil_jenis();
        saldo();
        new Thread() {
            public void run() {
                while (true) {
                    Calendar kl = new GregorianCalendar();
                    tahun = kl.get(Calendar.YEAR);
                    bulan = kl.get(Calendar.MONTH) + 1;
                    hari = kl.get(Calendar.DAY_OF_MONTH);
                }
            }
        }.start();
    }

    public void saldo() {
        String d = "0", k = "0";
        int d1 = 0, k1 = 0, s = 0;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select *  from keuangan");
            while (res.next()) {
                d = res.getString("debet");
                k = res.getString("kredit");
                d1 = Integer.parseInt(d);
                k1 = Integer.parseInt(k);
                s = s + (d1 - k1);
            }

            i_saldo.setText(Integer.toString(s));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabarang() {
        DefaultTableModel model0 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model0.addColumn("Id Barang");
        model0.addColumn("Nama Barang");
        model0.addColumn("Jenis Barang");
        model0.addColumn("Stok");
        model0.addColumn("Minimum Stok");
        model0.addColumn("Satuan");
        model0.addColumn("Harga Jual");
        model0.addColumn("Harga Beli");
        tbl_barang.setModel(model0);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from barang,jenis_barang where barang.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model0.addRow(new Object[]{
                    res.getString("id_barang"),
                    res.getString("nama_barang"),
                    res.getString("nama_jenis"),
                    res.getString("stok"),
                    res.getString("min_stok"),
                    res.getString("satuan"),
                    res.getString("harga_jual"),
                    res.getString("harga_beli")

                });
                tbl_barang.setModel(model0);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatastok() {
        DefaultTableModel model1 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model1.addColumn("Id Barang");
        model1.addColumn("Nama Barang");
        model1.addColumn("Jenis Barang");
        model1.addColumn("Stok");
        model1.addColumn("Minimum Stok");
        model1.addColumn("Satuan");
        tbl_stok.setModel(model1);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from barang,jenis_barang where stok<min_stok and barang.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model1.addRow(new Object[]{
                    res.getString("id_barang"),
                    res.getString("nama_barang"),
                    res.getString("nama_jenis"),
                    res.getString("stok"),
                    res.getString("min_stok"),
                    res.getString("satuan")

                });
                tbl_stok.setModel(model1);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    String row_id, row_nama, row_jenis, row_satuan;

    private void GetData_View1() {
        int row = tbl_barang.getSelectedRow();
        row_id = (tbl_barang.getModel().getValueAt(row, 0).toString());
        row_nama = (tbl_barang.getModel().getValueAt(row, 1).toString());
        row_jenis = (tbl_barang.getModel().getValueAt(row, 2).toString());
        row_satuan = (tbl_barang.getModel().getValueAt(row, 5).toString());

        i_id_barang.setText(row_id);
        i_nama_barang.setText(row_nama);
        c_jenis_barang.setSelectedItem(row_jenis);
        i_satuan.setText(row_satuan);
    }

    private void GetData_View2() {
        int row = tbl_stok.getSelectedRow();
        row_id = (tbl_stok.getModel().getValueAt(row, 0).toString());
        row_nama = (tbl_stok.getModel().getValueAt(row, 1).toString());
        row_jenis = (tbl_stok.getModel().getValueAt(row, 2).toString());
        row_satuan = (tbl_stok.getModel().getValueAt(row, 5).toString());

        i_id_barang.setText(row_id);
        i_nama_barang.setText(row_nama);
        c_jenis_barang.setSelectedItem(row_jenis);
        i_satuan.setText(row_satuan);
    }

    public void hapus_jenis() {
        int itemCount = c_jenis_barang.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            c_jenis_barang.removeItemAt(0);
        }
    }

    public void c_tampil_jenis() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from jenis_barang");

            c_jenis_barang.addItem("-Pilih-");
            while (res.next()) {
                c_jenis_barang.addItem(res.getString("nama_jenis"));
            }
        } catch (Exception ex) {

        }
    }

    String idbeli;

    public void idbeli() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_pembelian,6)) as idbeli from pembelian");
            while (res.next()) {
                if (res.first() == false) {
                    idbeli = "BL00001";
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 6 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    idbeli = "BL" + nomor;
                }

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void hitung() {
        int j, h, t;
        j = Integer.parseInt(i_jumlah.getText());
        h = Integer.parseInt(i_harga.getText());
        t = j * h;
        i_total.setText(Integer.toString(t));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_barang = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_stok = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        i_id_barang = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        i_nama_barang = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        c_jenis_barang = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        i_satuan = new javax.swing.JTextField();
        i_jumlah = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        i_total = new javax.swing.JTextField();
        i_harga = new javax.swing.JTextField();
        t_simpan = new javax.swing.JButton();
        t_batal = new javax.swing.JButton();
        t_hitung = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        i_saldo = new javax.swing.JTextField();

        setTitle("Pembelian");
        setPreferredSize(new java.awt.Dimension(1150, 540));

        tbl_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id Barang", "Nama Barang", "Jenis Barang", "Stok", "Minimum Stok", "Satuan", "Harga Jual", "Harga Beli"
            }
        ));
        tbl_barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_barangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_barang);

        jPanel3.setBackground(new java.awt.Color(102, 204, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tbl_stok.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id Barang", "Nama Barang", "Jenis Barang", "Stok", "Satuan"
            }
        ));
        tbl_stok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_stokMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_stok);

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel4.setText("Stok Minimum");

        jLabel29.setBackground(new java.awt.Color(255, 255, 255));
        jLabel29.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel29.setText("Id Barang");

        i_id_barang.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel30.setBackground(new java.awt.Color(255, 255, 255));
        jLabel30.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel30.setText("Nama Barang");

        i_nama_barang.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel31.setText("Jenis Barang");

        jLabel32.setBackground(new java.awt.Color(255, 255, 255));
        jLabel32.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel32.setText("Jumlah");

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel33.setText("Satuan");

        i_satuan.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_jumlah.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_jumlah.setText("0");

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel34.setText("Harga Beli");

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel35.setText("Total");

        i_total.setEditable(false);
        i_total.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_total.setText("0");

        i_harga.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_harga.setText("0");
        i_harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_hargaActionPerformed(evt);
            }
        });

        t_simpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan.setText("Simpan");
        t_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpanActionPerformed(evt);
            }
        });

        t_batal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal.setText("Batal");
        t_batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batalActionPerformed(evt);
            }
        });

        t_hitung.setText("Hitung");
        t_hitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hitungActionPerformed(evt);
            }
        });

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel36.setText("SALDO");

        i_saldo.setEditable(false);
        i_saldo.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_saldo.setText("0");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(163, 163, 163)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(467, 467, 467)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(t_hitung, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_batal, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(i_satuan))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(c_jenis_barang, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(i_nama_barang))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(i_id_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(i_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(i_total, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(i_jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(110, 110, 110)
                                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(i_saldo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(41, 41, 41))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(573, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_id_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_nama_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c_jenis_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38))
                    .addComponent(jLabel35, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_total, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_satuan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t_simpan)
                            .addComponent(t_batal)
                            .addComponent(t_hitung))
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_saldo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31))))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                    .addContainerGap(38, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1176, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(27, 27, 27)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(27, 27, 27)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 502, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(9, 9, 9)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(9, 9, 9)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_barangMouseClicked
        tbl_stok.clearSelection();
        GetData_View1();
    }//GEN-LAST:event_tbl_barangMouseClicked

    private void tbl_stokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_stokMouseClicked
        tbl_barang.clearSelection();
        GetData_View2();
    }//GEN-LAST:event_tbl_stokMouseClicked

    private void i_hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_hargaActionPerformed
        hitung();
    }//GEN-LAST:event_i_hargaActionPerformed

    private void t_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpanActionPerformed
        String id = i_id_barang.getText(),
                nama = i_nama_barang.getText(),
                jenis = (String) c_jenis_barang.getSelectedItem(),
                satuan = i_satuan.getText(),
                jumlah = i_jumlah.getText(),
                harga = i_harga.getText(),
                total = i_total.getText(),
                saldo = i_saldo.getText();
        int hr = Integer.parseInt(harga), ttl = Integer.parseInt(total), sl = Integer.parseInt(saldo);
        idbeli();
        String idb = null, idj = null, stok;
        int stk = 0, stk1;
        if (id.equals("") || nama.equals("") || jenis.equals("-Pilih-") || satuan.equals("") || jumlah.equals("0") || harga.equals("0") || total.equals("0")) {
            JOptionPane.showMessageDialog(null, "Masukan Data Dengan Benar", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
        } else {
            if (ttl > sl) {
                JOptionPane.showMessageDialog(null, "Saldo Tidak Mencukupi", "", JOptionPane.ERROR_MESSAGE);
            } else {
                try {

                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    ResultSet res = stat.executeQuery("select id_jenis from jenis_barang where nama_jenis='" + jenis + "'");
                    while (res.next()) {
                        idj = res.getString("id_jenis");
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(rootPane, e.getMessage());
                }

                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    ResultSet res1 = stat.executeQuery("select * from barang where id_barang='" + i_id_barang.getText() + "'");
                    while (res1.next()) {
                        stok = res1.getString("stok");
                        stk = Integer.parseInt(stok);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(i_pembelian.class.getName()).log(Level.SEVERE, null, ex);
                }
                stk1 = stk + Integer.parseInt(i_jumlah.getText());
                String tgl = Integer.toString(tahun) + "-" + Integer.toString(bulan) + "-" + Integer.toString(hari);
                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();

                    stat.executeUpdate("insert into pembelian values('" + idbeli + "','" + tgl + "','" + id + "','" + nama + "','" + idj + "','" + stk1 + "','" + satuan + "','" + hr + "','" + ttl + "')");
                    stat.executeUpdate("update barang set stok='" + stk1 + "',harga_beli='" + hr + "' where id_barang='" + id + "'");
                    stat.executeUpdate("insert into keuangan values('" + tgl + "','" + "Pembelian" + "','" + idbeli + "','" + "0" + "','" + total + "')");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        }
        i_id_barang.setText("");
        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-Pilih-");
        i_satuan.setText("");
        i_jumlah.setText("0");
        i_harga.setText("0");
        i_total.setText("0");
        tbl_barang.clearSelection();
        tbl_stok.clearSelection();
        getdatastok();
        getdatabarang();
    }//GEN-LAST:event_t_simpanActionPerformed

    private void t_batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batalActionPerformed
        i_id_barang.setText("");
        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-Pilih-");
        i_satuan.setText("");
        i_jumlah.setText("0");
        i_harga.setText("0");
        i_total.setText("0");
        tbl_barang.clearSelection();
        tbl_stok.clearSelection();
    }//GEN-LAST:event_t_batalActionPerformed

    private void t_hitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hitungActionPerformed
        hitung();
    }//GEN-LAST:event_t_hitungActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> c_jenis_barang;
    private javax.swing.JTextField i_harga;
    private javax.swing.JTextField i_id_barang;
    private javax.swing.JTextField i_jumlah;
    private javax.swing.JTextField i_nama_barang;
    private javax.swing.JTextField i_saldo;
    private javax.swing.JTextField i_satuan;
    private javax.swing.JTextField i_total;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton t_batal;
    private javax.swing.JButton t_hitung;
    private javax.swing.JButton t_simpan;
    private javax.swing.JTable tbl_barang;
    private javax.swing.JTable tbl_stok;
    // End of variables declaration//GEN-END:variables
}
