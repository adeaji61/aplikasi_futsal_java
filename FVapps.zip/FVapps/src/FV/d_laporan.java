/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import static FV.koneksi.con;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author User
 */
public class d_laporan extends javax.swing.JDialog {

    /**
     * Creates new form d_akun
     */
    DefaultTableModel tabmodel;

    public d_laporan(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initUI();
        home();
        tgl_lp1.setDateFormatString("dd-MM-yyyy");
        tgl_lp2.setDateFormatString("dd-MM-yyyy");
        tgl_lp3.setDateFormatString("dd-MM-yyyy");
        tgl_lp4.setDateFormatString("dd-MM-yyyy");
        tgl_lp5.setDateFormatString("dd-MM-yyyy");
        tgl_lp6.setDateFormatString("dd-MM-yyyy");
        //tgl_lp7.setDateFormatString("dd-MM-yyyy");
        // tgl_lp8.setDateFormatString("dd-MM-yyyy");
    }

    private void initUI() {
        getContentPane().setBackground(new Color(245, 245, 245));

        Dimension windowSize = getSize();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Point centerPoint = ge.getCenterPoint();
        int dx = centerPoint.x - windowSize.width / 2;
        int dy = centerPoint.y - windowSize.height / 2;
        setLocation(dx, dy);
    }

    public void home() {
        getdatabeli();
        getdatastok();
        getdatalapangantotal();
        getdatapenjualan();
        getdatasewa();
        total();
        tgl_lp1.setDate(null);
        tgl_lp2.setDate(null);
        tgl_lp3.setDate(null);
        tgl_lp4.setDate(null);
        tgl_lp5.setDate(null);
        tgl_lp6.setDate(null);
        //tgl_lp7.setDate(null);
        //tgl_lp8.setDate(null);
        //tgl_lp7.setDate(null);
        //tgl_lp8.setDate(null);
    }

    public void getdatapenjualan() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Penjualan");
        model.addColumn("Tanggal");
        model.addColumn("Id Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jumlah");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Total");
        tbl_penjualan1.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from penjualan,jenis_barang where penjualan.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_penjualan"),
                    res.getString("tanggal"),
                    res.getString("id_barang"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("jumlah"),
                    res.getString("satuan"),
                    res.getString("harga"),
                    res.getString("total")
                });
                tbl_penjualan1.setModel(model);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_penjualan1.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_penjualan1.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 8).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_jual.setText(String.valueOf(totalBiaya));
    }

    public void getdatabeli() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Pembelian");
        model.addColumn("Tanggal");
        model.addColumn("Id Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jumlah");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Total");
        tbl_beli.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from pembelian,jenis_barang where pembelian.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_pembelian"),
                    res.getString("tanggal"),
                    res.getString("id_barang"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("jumlah"),
                    res.getString("satuan"),
                    res.getString("harga_beli"),
                    res.getString("total_beli"),});
                tbl_beli.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_beli.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_beli.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 8).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_beli.setText(String.valueOf(totalBiaya));
    }
    String count_rows = null;

    public void getdatastok() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Stok");
        model.addColumn("Minimum Stok");
        model.addColumn("Satuan");
        model.addColumn("Harga Beli");
        model.addColumn("Harga Jual");
        tbl_stok.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from barang,jenis_barang where barang.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_barang"),
                    res.getString("nama_barang"),
                    res.getString("nama_jenis"),
                    res.getString("stok"),
                    res.getString("min_stok"),
                    res.getString("satuan"),
                    res.getString("harga_beli"),
                    res.getString("harga_jual")
                });
                tbl_stok.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_total_stok.setText(count_rows);
    }

    //Ini Codingan buat nampilin tabel aja de, ganti aja dengan punyamu, OKEH
    public void getdatalapangantotal() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("ID Booking");
        model.addColumn("Tanggal");
        model.addColumn("Nama Lapangan");
        model.addColumn("Harga");
        model.addColumn("Durasi");
        model.addColumn("Status");
        model.addColumn("ID Member");
        model.addColumn("Nama");
        model.addColumn("Telepon");
        model.addColumn("ID Sewa");
        model.addColumn("Total");
        //model.addColumn("Status Main");
        tbl_futsal.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking,lapangan where booking.id_lapangan=lapangan.id_lapangan");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("nama_lapangan"),
                    res.getString("harga"),
                    res.getString("durasi"),
                    res.getString("status"),
                    res.getString("id_member"),
                    res.getString("nama"),
                    res.getString("telepon"),
                    res.getString("id_sewa"),
                    res.getString("total"), //res.getString("status_main")
                });
                tbl_futsal.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_futsal.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_futsal.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 10).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_booking.setText(String.valueOf(totalBiaya));
    }

    public void getdatasewa() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Sewa");
        model.addColumn("Id Booking");
        model.addColumn("Tanggal");
        model.addColumn("Id Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jumlah");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Total");
        tbl_futsal1.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from sewa,barang,jenis_barang where sewa.id_barang=barang.id_barang and barang.id_jenis=jenis_barang.id_jenis order by sewa.id_sewa asc");
            //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_sewa"),
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("id_barang"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("qty"),
                    res.getString("satuan"),
                    res.getString("harga"),
                    res.getString("jumlah"),});
                tbl_futsal1.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_futsal1.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_futsal1.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 9).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_sewa.setText(String.valueOf(totalBiaya));
    }

    public void total() {
        int a = Integer.parseInt(i_total_booking.getText()), b = Integer.parseInt(i_total_sewa.getText()), c;
        c = a + b;
        i_total_futsal.setText(Integer.toString(c));
    }

    public void carifutsal() {
        String t = null, t1 = null;

        if (tgl_lp1.getDate() != null && tgl_lp2.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_lp1.getDate());
            t1 = format.format(tgl_lp2.getDate());
        }
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("ID Booking");
        model.addColumn("Tanggal");
        model.addColumn("Nama Lapangan");
        model.addColumn("Harga");
        model.addColumn("Durasi");
        model.addColumn("Status");
        model.addColumn("ID Member");
        model.addColumn("Nama");
        model.addColumn("Telepon");
        model.addColumn("ID Sewa");
        model.addColumn("Total");
        //model.addColumn("Status Main");
        tbl_futsal.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking,lapangan where booking.id_lapangan=lapangan.id_lapangan and booking.tanggal between '" + t + "'and'" + t1 + "'");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("nama_lapangan"),
                    res.getString("harga"),
                    res.getString("durasi"),
                    res.getString("status"),
                    res.getString("id_member"),
                    res.getString("nama"),
                    res.getString("telepon"),
                    res.getString("id_sewa"),
                    res.getString("total"), //res.getString("status_main")
                });
                tbl_futsal.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_futsal.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_futsal.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 10).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_booking.setText(String.valueOf(totalBiaya));
    }

    public void carisewa() {
        String t = null, t1 = null;

        if (tgl_lp1.getDate() != null && tgl_lp2.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_lp1.getDate());
            t1 = format.format(tgl_lp2.getDate());
        }
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Sewa");
        model.addColumn("Id Booking");
        model.addColumn("Tanggal");
        model.addColumn("Id Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jumlah");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Total");
        tbl_futsal1.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from sewa,barang,jenis_barang where sewa.id_barang=barang.id_barang and barang.id_jenis=jenis_barang.id_jenis and tanggal between '" + t + "'and'" + t1 + "' order by sewa.id_sewa asc");
            //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_sewa"),
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("id_barang"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("qty"),
                    res.getString("satuan"),
                    res.getString("harga"),
                    res.getString("jumlah"),});
                tbl_futsal1.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_futsal1.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_futsal1.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 9).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_sewa.setText(String.valueOf(totalBiaya));
    }

    public void carijual() {
        String t = null, t1 = null;

        if (tgl_lp3.getDate() != null && tgl_lp4.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_lp3.getDate());
            t1 = format.format(tgl_lp4.getDate());
        }
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Penjualan");
        model.addColumn("Tanggal");
        model.addColumn("Id Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jumlah");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Total");
        tbl_penjualan1.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from penjualan,jenis_barang where penjualan.id_jenis=jenis_barang.id_jenis and tanggal between '" + t + "'and'" + t1 + "'");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_penjualan"),
                    res.getString("tanggal"),
                    res.getString("id_barang"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("jumlah"),
                    res.getString("satuan"),
                    res.getString("harga"),
                    res.getString("total")
                });
                tbl_penjualan1.setModel(model);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_penjualan1.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_penjualan1.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 8).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_jual.setText(String.valueOf(totalBiaya));
    }

    public void caribeli() {
        String t = null, t1 = null;

        if (tgl_lp5.getDate() != null && tgl_lp6.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_lp5.getDate());
            t1 = format.format(tgl_lp6.getDate());
        }
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Pembelian");
        model.addColumn("Tanggal");
        model.addColumn("Id Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jumlah");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Total");
        tbl_beli.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from pembelian,jenis_barang where pembelian.id_jenis=jenis_barang.id_jenis and tanggal between '" + t + "'and'" + t1 + "'");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_pembelian"),
                    res.getString("tanggal"),
                    res.getString("id_barang"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("jumlah"),
                    res.getString("satuan"),
                    res.getString("harga_beli"),
                    res.getString("total_beli"),});
                tbl_beli.setModel(model);
                count_rows = String.valueOf(res.getRow());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_beli.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_beli.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 8).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_total_beli.setText(String.valueOf(totalBiaya));
    }

    public void caristok() {
        String cari = i_cari.getText();
        if (c_cari.getSelectedIndex() == 0) {
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            model.addColumn("Id Barang");
            model.addColumn("Nama Barang");
            model.addColumn("Jenis Barang");
            model.addColumn("Stok");
            model.addColumn("Minimum Stok");
            model.addColumn("Satuan");
            model.addColumn("Harga Beli");
            model.addColumn("Harga Jual");
            tbl_stok.setModel(model);
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select * from barang,jenis_barang where barang.id_jenis=jenis_barang.id_jenis and id_barang='" + cari + "'");
                while (res.next()) {

                    model.addRow(new Object[]{
                        res.getString("id_barang"),
                        res.getString("nama_barang"),
                        res.getString("nama_jenis"),
                        res.getString("stok"),
                        res.getString("min_stok"),
                        res.getString("satuan"),
                        res.getString("harga_beli"),
                        res.getString("harga_jual")
                    });
                    tbl_stok.setModel(model);
                    count_rows = String.valueOf(res.getRow());
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(rootPane, e.getMessage());
            }
            i_total_stok.setText(count_rows);
        } else if (c_cari.getSelectedIndex() == 1) {
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            model.addColumn("Id Barang");
            model.addColumn("Nama Barang");
            model.addColumn("Jenis Barang");
            model.addColumn("Stok");
            model.addColumn("Minimum Stok");
            model.addColumn("Satuan");
            model.addColumn("Harga Beli");
            model.addColumn("Harga Jual");
            tbl_stok.setModel(model);
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select * from barang,jenis_barang where barang.id_jenis=jenis_barang.id_jenis and nama_barang='" + cari + "'");
                while (res.next()) {

                    model.addRow(new Object[]{
                        res.getString("id_barang"),
                        res.getString("nama_barang"),
                        res.getString("nama_jenis"),
                        res.getString("stok"),
                        res.getString("min_stok"),
                        res.getString("satuan"),
                        res.getString("harga_beli"),
                        res.getString("harga_jual")
                    });
                    tbl_stok.setModel(model);
                    count_rows = String.valueOf(res.getRow());
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(rootPane, e.getMessage());
            }
            i_total_stok.setText(count_rows);
        } else if (c_cari.getSelectedIndex() == 2) {
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            model.addColumn("Id Barang");
            model.addColumn("Nama Barang");
            model.addColumn("Jenis Barang");
            model.addColumn("Stok");
            model.addColumn("Minimum Stok");
            model.addColumn("Satuan");
            model.addColumn("Harga Beli");
            model.addColumn("Harga Jual");
            tbl_stok.setModel(model);
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select * from barang,jenis_barang where barang.id_jenis=jenis_barang.id_jenis and nama_jenis='" + cari + "'");
                while (res.next()) {

                    model.addRow(new Object[]{
                        res.getString("id_barang"),
                        res.getString("nama_barang"),
                        res.getString("nama_jenis"),
                        res.getString("stok"),
                        res.getString("min_stok"),
                        res.getString("satuan"),
                        res.getString("harga_beli"),
                        res.getString("harga_jual")
                    });
                    tbl_stok.setModel(model);
                    count_rows = String.valueOf(res.getRow());
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(rootPane, e.getMessage());
            }
            i_total_stok.setText(count_rows);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        r_group = new javax.swing.ButtonGroup();
        panelTransparan21 = new FV.PanelTransparan2();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelTransparan31 = new FV.PanelTransparan3();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_futsal = new javax.swing.JTable();
        t_cetak = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        i_total_sewa = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        tgl_lp1 = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        tgl_lp2 = new com.toedter.calendar.JDateChooser();
        t_cari_lp_jl1 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        i_total_booking = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        i_total_futsal = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_futsal1 = new javax.swing.JTable();
        jLabel43 = new javax.swing.JLabel();
        t_refresh1 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tbl_penjualan1 = new javax.swing.JTable();
        t_cetak1 = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        i_total_jual = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        tgl_lp3 = new com.toedter.calendar.JDateChooser();
        jLabel9 = new javax.swing.JLabel();
        tgl_lp4 = new com.toedter.calendar.JDateChooser();
        t_cari_lp_jl2 = new javax.swing.JButton();
        t_refresh2 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        t_main2 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        i_total_beli = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        tgl_lp5 = new com.toedter.calendar.JDateChooser();
        jLabel32 = new javax.swing.JLabel();
        tgl_lp6 = new com.toedter.calendar.JDateChooser();
        t_cari_lp_jl3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_beli = new javax.swing.JTable();
        t_refresh3 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tbl_stok = new javax.swing.JTable();
        t_main3 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        i_total_stok = new javax.swing.JTextField();
        t_cari_lp_jl4 = new javax.swing.JButton();
        t_refresh4 = new javax.swing.JButton();
        i_cari = new javax.swing.JTextField();
        c_cari = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTransparan21.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(11, 108, 151));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("LAPORAN");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(689, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelTransparan21Layout = new javax.swing.GroupLayout(panelTransparan21);
        panelTransparan21.setLayout(panelTransparan21Layout);
        panelTransparan21Layout.setHorizontalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelTransparan21Layout.setVerticalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan21Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(panelTransparan21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 50));

        panelTransparan31.setBackground(new java.awt.Color(51, 51, 51));

        tbl_futsal.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        tbl_futsal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Transaksi", "Id Booking", "Tanggal", "Lapangan", "Jam", "Durasi", "Status", "Id Member", "Nama"
            }
        ));
        tbl_futsal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_futsalMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_futsal);
        if (tbl_futsal.getColumnModel().getColumnCount() > 0) {
            tbl_futsal.getColumnModel().getColumn(3).setPreferredWidth(90);
            tbl_futsal.getColumnModel().getColumn(5).setResizable(false);
        }

        t_cetak.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_cetak.setText("Cetak");
        t_cetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cetakActionPerformed(evt);
            }
        });

        jLabel28.setBackground(new java.awt.Color(255, 255, 255));
        jLabel28.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setText("Jumlah");

        i_total_sewa.setEditable(false);
        i_total_sewa.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_total_sewa.setText("0");

        jLabel33.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel33.setText("Tanggal");

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("s/d");

        t_cari_lp_jl1.setText("Cari");
        t_cari_lp_jl1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari_lp_jl1ActionPerformed(evt);
            }
        });

        jLabel29.setBackground(new java.awt.Color(255, 255, 255));
        jLabel29.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 0, 0));
        jLabel29.setText("Jumlah");

        i_total_booking.setEditable(false);
        i_total_booking.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_total_booking.setText("0");

        jLabel42.setBackground(new java.awt.Color(255, 255, 255));
        jLabel42.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(0, 0, 0));
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setText("Total");

        i_total_futsal.setEditable(false);
        i_total_futsal.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        i_total_futsal.setText("0");

        tbl_futsal1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbl_futsal1);

        jLabel43.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel43.setText("Sewa barang :");

        t_refresh1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        t_refresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_refresh1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(t_cetak, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(i_total_sewa, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(639, 639, 639)
                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(i_total_futsal, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel43)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(i_total_booking, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4)))
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tgl_lp1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tgl_lp2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari_lp_jl1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_refresh1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tgl_lp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl_lp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari_lp_jl1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(t_refresh1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_total_booking, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_cetak)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(i_total_sewa, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(i_total_futsal, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Lapangan Futsal", jPanel5);

        tbl_penjualan1.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        tbl_penjualan1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Penjualan", "Tanggal", "Id barang", "Jenis barang", "Nama Barang", "Jumlah", "Satuan", "Harga", "Total"
            }
        ));
        tbl_penjualan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_penjualan1MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(tbl_penjualan1);
        if (tbl_penjualan1.getColumnModel().getColumnCount() > 0) {
            tbl_penjualan1.getColumnModel().getColumn(7).setResizable(false);
        }

        t_cetak1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_cetak1.setText("Cetak");
        t_cetak1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cetak1ActionPerformed(evt);
            }
        });

        jLabel30.setBackground(new java.awt.Color(255, 255, 255));
        jLabel30.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 0, 0));
        jLabel30.setText("Total");

        i_total_jual.setEditable(false);
        i_total_jual.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_total_jual.setText("0");
        i_total_jual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_total_jualActionPerformed(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel34.setText("Tanggal");

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("s/d");

        t_cari_lp_jl2.setText("Cari");
        t_cari_lp_jl2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari_lp_jl2ActionPerformed(evt);
            }
        });

        t_refresh2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        t_refresh2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_refresh2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tgl_lp3, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tgl_lp4, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_cari_lp_jl2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_refresh2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(t_cetak1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(i_total_jual, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 919, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tgl_lp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl_lp4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari_lp_jl2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(t_refresh2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_cetak1)
                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_total_jual, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Penjualan", jPanel10);

        t_main2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_main2.setText("Cetak");
        t_main2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_main2ActionPerformed(evt);
            }
        });

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 0, 0));
        jLabel31.setText("Total");

        i_total_beli.setEditable(false);
        i_total_beli.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_total_beli.setText("0");

        jLabel35.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel35.setText("Tanggal");

        jLabel32.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("s/d");

        t_cari_lp_jl3.setText("Cari");
        t_cari_lp_jl3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari_lp_jl3ActionPerformed(evt);
            }
        });

        tbl_beli.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tbl_beli);

        t_refresh3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        t_refresh3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_refresh3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tgl_lp5, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tgl_lp6, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_cari_lp_jl3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_refresh3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 337, Short.MAX_VALUE))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(t_main2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(i_total_beli, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tgl_lp5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl_lp6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari_lp_jl3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(t_refresh3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_main2)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_total_beli, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Pembelian", jPanel11);

        tbl_stok.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        tbl_stok.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Barang", "Nama Barang", "Jenis Barang", "Stok", "Satuan", "Minimum Stok"
            }
        ));
        tbl_stok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_stokMouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(tbl_stok);

        t_main3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_main3.setText("Cetak");
        t_main3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_main3ActionPerformed(evt);
            }
        });

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 0, 0));
        jLabel36.setText("Total");

        i_total_stok.setEditable(false);
        i_total_stok.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_total_stok.setText("0");

        t_cari_lp_jl4.setText("Cari");
        t_cari_lp_jl4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari_lp_jl4ActionPerformed(evt);
            }
        });

        t_refresh4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        t_refresh4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_refresh4ActionPerformed(evt);
            }
        });

        i_cari.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        i_cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_cariActionPerformed(evt);
            }
        });
        i_cari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                i_cariKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                i_cariKeyReleased(evt);
            }
        });

        c_cari.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        c_cari.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Barang", "Nama Barang", "Jenis Barang" }));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(t_main3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(i_total_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 919, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(c_cari, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(i_cari, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(t_cari_lp_jl4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_refresh4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t_cari_lp_jl4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(i_cari, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(c_cari, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(t_refresh4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_main3)
                    .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_total_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Stok Barang", jPanel12);

        javax.swing.GroupLayout panelTransparan31Layout = new javax.swing.GroupLayout(panelTransparan31);
        panelTransparan31.setLayout(panelTransparan31Layout);
        panelTransparan31Layout.setHorizontalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 933, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        panelTransparan31Layout.setVerticalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(panelTransparan31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 700));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Soccer-Ball-Wallpaper-HD-Desktop-Background-2014-Soccer-Ball-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 700));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t_cetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cetakActionPerformed
        try {
            tbl_futsal.print();
        } catch (PrinterException ex) {
            Logger.getLogger(d_laporan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_t_cetakActionPerformed

    private void tbl_futsalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_futsalMouseClicked

    }//GEN-LAST:event_tbl_futsalMouseClicked

    private void t_cari_lp_jl1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari_lp_jl1ActionPerformed
        carifutsal();
        carisewa();
    }//GEN-LAST:event_t_cari_lp_jl1ActionPerformed

    private void tbl_penjualan1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_penjualan1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_penjualan1MouseClicked

    public Connection koneksi() {
        Connection khusus = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            khusus = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fvdb", "root", "");
            return khusus;
        } catch (ClassNotFoundException ex) {
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }
    private void t_cetak1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cetak1ActionPerformed
        try {
            tbl_penjualan1.print();
        } catch (PrinterException ex) {
            Logger.getLogger(d_laporan.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*Masih belum bisa 
        String reportSource = null;
        String reportDest = null;

        try {
            com.mysql.jdbc.Connection c = (com.mysql.jdbc.Connection) con;
            reportSource = System.getProperty("user.dir") + "src/Laporan/laporan_penjualan.jrxml";
            reportDest = System.getProperty("user.dir") + "src/Laporan/laporan_penjualan.jasper";
            
            JasperReport jas = JasperCompileManager.compileReport(reportSource);
            JasperPrint jap = JasperFillManager.fillReport(jas, null, c);
            JasperExportManager.exportReportToHtmlFile(jap, reportDest);
            JasperViewer.viewReport(jap, false);
        } catch (Exception ex) {
            System.out.println(ex);
        }

        koneksi k = new koneksi();
        try {
            String file = "src/Laporan/laporan_penjualan.jasper";
            JasperPrint jp = JasperFillManager.fillReport(file, null, koneksi());
            JasperViewer jv = new JasperViewer(jp, false);
            jv.setVisible(true);
        } catch (Exception e) {
        }*/
    }//GEN-LAST:event_t_cetak1ActionPerformed

    private void t_cari_lp_jl2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari_lp_jl2ActionPerformed
        carijual();
    }//GEN-LAST:event_t_cari_lp_jl2ActionPerformed

    private void t_main2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_main2ActionPerformed
        try {
            tbl_beli.print();
        } catch (PrinterException ex) {
            Logger.getLogger(d_laporan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_t_main2ActionPerformed

    private void t_cari_lp_jl3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari_lp_jl3ActionPerformed
        caribeli();
    }//GEN-LAST:event_t_cari_lp_jl3ActionPerformed

    private void tbl_stokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_stokMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_stokMouseClicked

    private void t_main3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_main3ActionPerformed
         try {
            tbl_stok.print();
        } catch (PrinterException ex) {
            Logger.getLogger(d_laporan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_t_main3ActionPerformed

    private void t_cari_lp_jl4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari_lp_jl4ActionPerformed
        caristok();
    }//GEN-LAST:event_t_cari_lp_jl4ActionPerformed

    private void i_total_jualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_total_jualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_total_jualActionPerformed

    private void t_refresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_refresh1ActionPerformed
        home();
    }//GEN-LAST:event_t_refresh1ActionPerformed

    private void t_refresh4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_refresh4ActionPerformed
        home();
        c_cari.setSelectedIndex(0);
        i_cari.setText("");
    }//GEN-LAST:event_t_refresh4ActionPerformed

    private void t_refresh3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_refresh3ActionPerformed
        home();
    }//GEN-LAST:event_t_refresh3ActionPerformed

    private void t_refresh2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_refresh2ActionPerformed
        home();
    }//GEN-LAST:event_t_refresh2ActionPerformed

    private void i_cariKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_cariKeyPressed

    }//GEN-LAST:event_i_cariKeyPressed

    private void i_cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_cariActionPerformed
        caristok();
    }//GEN-LAST:event_i_cariActionPerformed

    private void i_cariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_cariKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_i_cariKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(d_laporan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(d_laporan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(d_laporan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(d_laporan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                d_laporan dialog = new d_laporan(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> c_cari;
    private javax.swing.JTextField i_cari;
    private javax.swing.JTextField i_total_beli;
    private javax.swing.JTextField i_total_booking;
    private javax.swing.JTextField i_total_futsal;
    private javax.swing.JTextField i_total_jual;
    private javax.swing.JTextField i_total_sewa;
    private javax.swing.JTextField i_total_stok;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private FV.PanelTransparan2 panelTransparan21;
    private FV.PanelTransparan3 panelTransparan31;
    private javax.swing.ButtonGroup r_group;
    private javax.swing.JButton t_cari_lp_jl1;
    private javax.swing.JButton t_cari_lp_jl2;
    private javax.swing.JButton t_cari_lp_jl3;
    private javax.swing.JButton t_cari_lp_jl4;
    private javax.swing.JButton t_cetak;
    private javax.swing.JButton t_cetak1;
    private javax.swing.JButton t_main2;
    private javax.swing.JButton t_main3;
    private javax.swing.JButton t_refresh1;
    private javax.swing.JButton t_refresh2;
    private javax.swing.JButton t_refresh3;
    private javax.swing.JButton t_refresh4;
    private javax.swing.JTable tbl_beli;
    private javax.swing.JTable tbl_futsal;
    private javax.swing.JTable tbl_futsal1;
    private javax.swing.JTable tbl_penjualan1;
    private javax.swing.JTable tbl_stok;
    private com.toedter.calendar.JDateChooser tgl_lp1;
    private com.toedter.calendar.JDateChooser tgl_lp2;
    private com.toedter.calendar.JDateChooser tgl_lp3;
    private com.toedter.calendar.JDateChooser tgl_lp4;
    private com.toedter.calendar.JDateChooser tgl_lp5;
    private com.toedter.calendar.JDateChooser tgl_lp6;
    // End of variables declaration//GEN-END:variables
}
