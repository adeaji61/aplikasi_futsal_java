/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

/**
 *
 * @author User
 */
public class d_booking extends javax.swing.JDialog {

    /**
     * Creates new form d_akun
     */
    public d_booking(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initUI();

        hapus_item();
        c_tampil_item();
        kal_1.setDateFormatString("dd-MM-yyyy");
        kal_2.setDateFormatString("dd-MM-yyyy");
        kal_3.setDateFormatString("dd-MM-yyyy");
        kal_4.setDateFormatString("dd-MM-yyyy");
        kal_5.setDateFormatString("dd-MM-yyyy");
        kal_6.setDateFormatString("dd-MM-yyyy");
        kal_7.setDateFormatString("dd-MM-yyyy");
        kal_8.setDateFormatString("dd-MM-yyyy");
        kal_9.setDateFormatString("dd-MM-yyyy");
        Date date = new Date();
        kal_1.setDate(date);
        kal_2.setDate(date);
        kal_3.setDate(date);
        kal_4.setDate(date);
        kal_5.setDate(date);
        kal_6.setDate(date);
        kal_7.setDate(date);
        kal_8.setDate(date);
        kal_9.setDate(date);
        status1();
        status2();
        getdatajadwal1();
        getdatajadwal2();
        getdatajadwal3();
        getdatajadwal4();
        getdatajadwal5();
        getdatajadwal6();
        getdatajadwal7();
        getdatajadwal8();
        getdatajadwal9();
        t_tambah.setBackground(Color.CYAN);
        t_hapus.setBackground(new java.awt.Color(188, 188, 188));
    }

    private void initUI() {
        getContentPane().setBackground(new Color(245, 245, 245));

        Dimension windowSize = getSize();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Point centerPoint = ge.getCenterPoint();
        int dx = centerPoint.x - windowSize.width / 2;
        int dy = centerPoint.y - windowSize.height / 2;
        setLocation(dx, dy);
    }

    public void status1() {
        String ob;
        int i = 0;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where status='NonAktif'");
            while (res.next()) {
                ob = res.getString("id_lapangan");
                if (ob.equals("L01")) {
                    t_ok1.setEnabled(false);
                } else if (ob.equals("L02")) {
                    t_ok2.setEnabled(false);
                } else if (ob.equals("L03")) {
                    t_ok3.setEnabled(false);
                } else if (ob.equals("L04")) {
                    t_ok4.setEnabled(false);
                } else if (ob.equals("L05")) {
                    t_ok5.setEnabled(false);
                } else if (ob.equals("L06")) {
                    t_ok6.setEnabled(false);
                } else if (ob.equals("L07")) {
                    t_ok7.setEnabled(false);
                } else if (ob.equals("L08")) {
                    t_ok8.setEnabled(false);
                } else if (ob.equals("L09")) {
                    t_ok9.setEnabled(false);
                }
            }
            res.close();
            stat.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }

    public void status2() {
        String ob;
        int i = 0;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where status='Aktif'");
            while (res.next()) {
                ob = res.getString("id_lapangan");
                if (ob.equals("L01")) {
                    t_ok1.setEnabled(true);
                } else if (ob.equals("L02")) {
                    t_ok2.setEnabled(true);
                } else if (ob.equals("L03")) {
                    t_ok3.setEnabled(true);
                } else if (ob.equals("L04")) {
                    t_ok4.setEnabled(true);
                } else if (ob.equals("L05")) {
                    t_ok5.setEnabled(true);
                } else if (ob.equals("L06")) {
                    t_ok6.setEnabled(true);
                } else if (ob.equals("L07")) {
                    t_ok7.setEnabled(true);
                } else if (ob.equals("L08")) {
                    t_ok8.setEnabled(true);
                } else if (ob.equals("L09")) {
                    t_ok9.setEnabled(true);
                }
            }
            res.close();
            stat.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }

    public void idbooking() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_booking,5)) as idbook from booking");
            while (res.next()) {
                if (res.first() == false) {
                    i_id_booking.setText("B00001");
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 5 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    i_id_booking.setText("B" + nomor);
                }

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    String idsewa = null;

    public void idsewa() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_booking,5)) as idsewa from sewa");
            while (res.next()) {
                if (res.first() == false) {
                    idsewa = "S00001";
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 5 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    idsewa = "S" + nomor;
                }

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatajadwal1() {
        DefaultTableModel model1 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_1.getDate()));

        model1.addColumn("Jam");
        model1.addColumn("Durasi");
        model1.addColumn("Status");
        tbl_1.setModel(model1);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L01' and tanggal='" + t1 + "'");
            while (res.next()) {

                model1.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_1.setModel(model1);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal2() {
        DefaultTableModel model2 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t2 = String.valueOf(sdf.format(kal_2.getDate()));

        model2.addColumn("Jam");
        model2.addColumn("Durasi");
        model2.addColumn("Status");
        tbl_2.setModel(model2);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L02' and tanggal='" + t2 + "'");
            while (res.next()) {

                model2.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_2.setModel(model2);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatajadwal3() {
        DefaultTableModel model3 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t3 = String.valueOf(sdf.format(kal_3.getDate()));

        model3.addColumn("Jam");
        model3.addColumn("Durasi");
        model3.addColumn("Status");
        tbl_3.setModel(model3);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L03' and tanggal='" + t3 + "'");
            while (res.next()) {

                model3.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_3.setModel(model3);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal4() {
        DefaultTableModel model4 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_4.getDate()));

        model4.addColumn("Jam");
        model4.addColumn("Durasi");
        model4.addColumn("Status");
        tbl_4.setModel(model4);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L04' and tanggal='" + t1 + "'");
            while (res.next()) {

                model4.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_4.setModel(model4);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal5() {
        DefaultTableModel model5 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_5.getDate()));

        model5.addColumn("Jam");
        model5.addColumn("Durasi");
        model5.addColumn("Status");
        tbl_5.setModel(model5);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L05' and tanggal='" + t1 + "'");
            while (res.next()) {

                model5.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_5.setModel(model5);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal6() {
        DefaultTableModel model6 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_6.getDate()));

        model6.addColumn("Jam");
        model6.addColumn("Durasi");
        model6.addColumn("Status");
        tbl_6.setModel(model6);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L06' and tanggal='" + t1 + "'");
            while (res.next()) {

                model6.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_6.setModel(model6);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal7() {
        DefaultTableModel model7 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_7.getDate()));

        model7.addColumn("Jam");
        model7.addColumn("Durasi");
        model7.addColumn("Status");
        tbl_7.setModel(model7);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L07' and tanggal='" + t1 + "'");
            while (res.next()) {

                model7.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_7.setModel(model7);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal8() {
        DefaultTableModel model8 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_8.getDate()));

        model8.addColumn("Jam");
        model8.addColumn("Durasi");
        model8.addColumn("Status");
        tbl_8.setModel(model8);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L08' and tanggal='" + t1 + "'");
            while (res.next()) {

                model8.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_8.setModel(model8);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatajadwal9() {
        DefaultTableModel model9 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String t1 = String.valueOf(sdf.format(kal_9.getDate()));

        model9.addColumn("Jam");
        model9.addColumn("Durasi");
        model9.addColumn("Status");
        tbl_9.setModel(model9);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='L09' and tanggal='" + t1 + "'");
            while (res.next()) {

                model9.addRow(new Object[]{
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),});
                tbl_9.setModel(model9);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void hapus_item() {
        int itemCount = c_item.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            c_item.removeItemAt(0);
        }
    }

    public void c_tampil_item() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from item_sewa");

            c_item.addItem("-Pilih-");
            while (res.next()) {
                c_item.addItem(res.getString("nama_barang"));
            }
        } catch (Exception ex) {

        }
    }

    int st = 0;

    private void GetData_View() {
        int row = tbl_item.getSelectedRow();
        if (st == 1) {
            DefaultTableModel model = (DefaultTableModel) tbl_item.getModel();
            model.removeRow(row);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        r_group = new javax.swing.ButtonGroup();
        jLabel9 = new javax.swing.JLabel();
        i_nama5 = new javax.swing.JTextField();
        panelTransparan21 = new FV.PanelTransparan2();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelTransparan31 = new FV.PanelTransparan3();
        jPanel6 = new javax.swing.JPanel();
        panel_booking = new javax.swing.JTabbedPane();
        panel_bk1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_1 = new javax.swing.JTable();
        t_ok1 = new javax.swing.JButton();
        kal_1 = new com.toedter.calendar.JDateChooser();
        t_cari1 = new javax.swing.JButton();
        panel_bk2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_2 = new javax.swing.JTable();
        kal_2 = new com.toedter.calendar.JDateChooser();
        t_cari2 = new javax.swing.JButton();
        t_ok2 = new javax.swing.JButton();
        panel_bk3 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbl_3 = new javax.swing.JTable();
        t_ok3 = new javax.swing.JButton();
        kal_3 = new com.toedter.calendar.JDateChooser();
        t_cari3 = new javax.swing.JButton();
        panel_bk4 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tbl_4 = new javax.swing.JTable();
        t_ok4 = new javax.swing.JButton();
        kal_4 = new com.toedter.calendar.JDateChooser();
        t_cari4 = new javax.swing.JButton();
        panel_bk5 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tbl_5 = new javax.swing.JTable();
        t_ok5 = new javax.swing.JButton();
        kal_5 = new com.toedter.calendar.JDateChooser();
        t_cari5 = new javax.swing.JButton();
        panel_bk6 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tbl_6 = new javax.swing.JTable();
        t_ok6 = new javax.swing.JButton();
        kal_6 = new com.toedter.calendar.JDateChooser();
        t_cari6 = new javax.swing.JButton();
        panel_bk7 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tbl_7 = new javax.swing.JTable();
        t_ok7 = new javax.swing.JButton();
        kal_7 = new com.toedter.calendar.JDateChooser();
        t_cari7 = new javax.swing.JButton();
        panel_bk8 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tbl_8 = new javax.swing.JTable();
        t_ok8 = new javax.swing.JButton();
        kal_8 = new com.toedter.calendar.JDateChooser();
        t_cari8 = new javax.swing.JButton();
        panel_bk9 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        tbl_9 = new javax.swing.JTable();
        t_ok9 = new javax.swing.JButton();
        kal_9 = new com.toedter.calendar.JDateChooser();
        t_cari9 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        r_member = new javax.swing.JRadioButton();
        r_non = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        i_idmember = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        i_nama = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        i_tlp = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        i_dp = new javax.swing.JTextField();
        i_id_booking = new javax.swing.JTextField();
        i_tgl = new javax.swing.JTextField();
        i_lp = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        i_ttl = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        i_durasi = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        i_harga = new javax.swing.JTextField();
        t_hitung = new javax.swing.JButton();
        c_jam = new javax.swing.JComboBox<>();
        jPanel7 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        i_jml = new javax.swing.JTextField();
        c_item = new javax.swing.JComboBox<>();
        t_tambah = new javax.swing.JButton();
        t_hapus = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        i_ttl2 = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        tbl_item = new javax.swing.JTable();
        t_simpan = new javax.swing.JButton();
        t_batal = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        i_ttl3 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Nama");

        i_nama5.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTransparan21.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(11, 108, 151));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Sewa Lapangan");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(763, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelTransparan21Layout = new javax.swing.GroupLayout(panelTransparan21);
        panelTransparan21.setLayout(panelTransparan21Layout);
        panelTransparan21Layout.setHorizontalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan21Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelTransparan21Layout.setVerticalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan21Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(panelTransparan21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 50));

        panelTransparan31.setBackground(new java.awt.Color(51, 51, 51));

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        panel_booking.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tbl_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane3.setViewportView(tbl_1);

        t_ok1.setText("OK");
        t_ok1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok1ActionPerformed(evt);
            }
        });

        kal_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kal_1MouseClicked(evt);
            }
        });
        kal_1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                kal_1PropertyChange(evt);
            }
        });
        kal_1.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                kal_1VetoableChange(evt);
            }
        });

        t_cari1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk1Layout = new javax.swing.GroupLayout(panel_bk1);
        panel_bk1.setLayout(panel_bk1Layout);
        panel_bk1Layout.setHorizontalGroup(
            panel_bk1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk1Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk1Layout.createSequentialGroup()
                        .addComponent(kal_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk1Layout.setVerticalGroup(
            panel_bk1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(kal_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(t_cari1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(t_ok1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("1", panel_bk1);

        tbl_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane4.setViewportView(tbl_2);

        t_cari2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari2ActionPerformed(evt);
            }
        });

        t_ok2.setText("OK");
        t_ok2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk2Layout = new javax.swing.GroupLayout(panel_bk2);
        panel_bk2.setLayout(panel_bk2Layout);
        panel_bk2Layout.setHorizontalGroup(
            panel_bk2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk2Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk2Layout.createSequentialGroup()
                        .addComponent(kal_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(t_ok2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panel_bk2Layout.setVerticalGroup(
            panel_bk2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari2, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_ok2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4))
        );

        panel_booking.addTab("2", panel_bk2);

        tbl_3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane5.setViewportView(tbl_3);

        t_ok3.setText("OK");
        t_ok3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok3ActionPerformed(evt);
            }
        });

        t_cari3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk3Layout = new javax.swing.GroupLayout(panel_bk3);
        panel_bk3.setLayout(panel_bk3Layout);
        panel_bk3Layout.setHorizontalGroup(
            panel_bk3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk3Layout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk3Layout.createSequentialGroup()
                        .addComponent(kal_3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk3Layout.setVerticalGroup(
            panel_bk3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("3", panel_bk3);

        tbl_4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane7.setViewportView(tbl_4);

        t_ok4.setText("OK");
        t_ok4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok4ActionPerformed(evt);
            }
        });

        t_cari4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk4Layout = new javax.swing.GroupLayout(panel_bk4);
        panel_bk4.setLayout(panel_bk4Layout);
        panel_bk4Layout.setHorizontalGroup(
            panel_bk4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk4Layout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk4Layout.createSequentialGroup()
                        .addComponent(kal_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari4, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk4Layout.setVerticalGroup(
            panel_bk4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("4", panel_bk4);

        tbl_5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane8.setViewportView(tbl_5);

        t_ok5.setText("OK");
        t_ok5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok5ActionPerformed(evt);
            }
        });

        t_cari5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk5Layout = new javax.swing.GroupLayout(panel_bk5);
        panel_bk5.setLayout(panel_bk5Layout);
        panel_bk5Layout.setHorizontalGroup(
            panel_bk5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk5Layout.createSequentialGroup()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk5Layout.createSequentialGroup()
                        .addComponent(kal_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari5, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk5Layout.setVerticalGroup(
            panel_bk5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("5", panel_bk5);

        tbl_6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane9.setViewportView(tbl_6);

        t_ok6.setText("OK");
        t_ok6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok6ActionPerformed(evt);
            }
        });

        t_cari6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk6Layout = new javax.swing.GroupLayout(panel_bk6);
        panel_bk6.setLayout(panel_bk6Layout);
        panel_bk6Layout.setHorizontalGroup(
            panel_bk6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk6Layout.createSequentialGroup()
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk6Layout.createSequentialGroup()
                        .addComponent(kal_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari6, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk6Layout.setVerticalGroup(
            panel_bk6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("6", panel_bk6);

        tbl_7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane10.setViewportView(tbl_7);

        t_ok7.setText("OK");
        t_ok7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok7ActionPerformed(evt);
            }
        });

        t_cari7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk7Layout = new javax.swing.GroupLayout(panel_bk7);
        panel_bk7.setLayout(panel_bk7Layout);
        panel_bk7Layout.setHorizontalGroup(
            panel_bk7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk7Layout.createSequentialGroup()
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk7Layout.createSequentialGroup()
                        .addComponent(kal_7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari7, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk7Layout.setVerticalGroup(
            panel_bk7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("7", panel_bk7);

        tbl_8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane11.setViewportView(tbl_8);

        t_ok8.setText("OK");
        t_ok8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok8ActionPerformed(evt);
            }
        });

        t_cari8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk8Layout = new javax.swing.GroupLayout(panel_bk8);
        panel_bk8.setLayout(panel_bk8Layout);
        panel_bk8Layout.setHorizontalGroup(
            panel_bk8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk8Layout.createSequentialGroup()
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk8Layout.createSequentialGroup()
                        .addComponent(kal_8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari8, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk8Layout.setVerticalGroup(
            panel_bk8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("8", panel_bk8);

        tbl_9.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Jam", "Status"
            }
        ));
        jScrollPane12.setViewportView(tbl_9);

        t_ok9.setText("OK");
        t_ok9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok9ActionPerformed(evt);
            }
        });

        t_cari9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        t_cari9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bk9Layout = new javax.swing.GroupLayout(panel_bk9);
        panel_bk9.setLayout(panel_bk9Layout);
        panel_bk9Layout.setHorizontalGroup(
            panel_bk9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bk9Layout.createSequentialGroup()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(panel_bk9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_ok9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_bk9Layout.createSequentialGroup()
                        .addComponent(kal_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_cari9, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel_bk9Layout.setVerticalGroup(
            panel_bk9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bk9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bk9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kal_9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cari9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(4, 4, 4)
                .addComponent(t_ok9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_booking.addTab("9", panel_bk9);

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Id Booking");

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Tanggal");

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Lapangan");

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Status");

        r_group.add(r_member);
        r_member.setText("Member");
        r_member.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                r_memberActionPerformed(evt);
            }
        });

        r_group.add(r_non);
        r_non.setText("NonMember");
        r_non.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                r_nonActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Id Member");

        i_idmember.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_idmember.setEnabled(false);
        i_idmember.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_idmemberActionPerformed(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Nama");

        i_nama.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("No Telepon");

        i_tlp.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Uang Muka");

        i_dp.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_id_booking.setEditable(false);
        i_id_booking.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_tgl.setEditable(false);
        i_tgl.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_lp.setEditable(false);
        i_lp.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Jam");

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("Durasi");

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("Total");

        i_ttl.setEditable(false);
        i_ttl.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_ttl.setText("0");
        i_ttl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_ttlActionPerformed(evt);
            }
        });

        jLabel21.setText("Jam");

        i_durasi.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_durasi.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                i_durasiComponentAdded(evt);
            }
        });
        i_durasi.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                i_durasiFocusGained(evt);
            }
        });
        i_durasi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                i_durasiKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i_durasiKeyTyped(evt);
            }
        });

        jLabel18.setBackground(new java.awt.Color(255, 255, 255));
        jLabel18.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("Harga");

        i_harga.setEditable(false);
        i_harga.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        t_hitung.setText("Hitung");
        t_hitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hitungActionPerformed(evt);
            }
        });

        c_jam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-Pilih-", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00", "24:00" }));
        c_jam.setEnabled(false);
        c_jam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_jamActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_tlp))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_nama))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_idmember))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(r_member)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(r_non))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_dp))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_ttl))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_durasi, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_hitung))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_harga))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(c_jam, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_lp))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_tgl))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(i_id_booking, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_id_booking, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_tgl, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_lp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(c_jam))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(i_durasi, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t_hitung))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(r_member)
                    .addComponent(r_non))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_idmember, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_nama, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_tlp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_dp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_ttl, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("SEWA BARANG");

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Barang ");

        jLabel19.setBackground(new java.awt.Color(255, 255, 255));
        jLabel19.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("Qty");

        jLabel20.setText("Pcs");

        i_jml.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        t_tambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_tambah.setText("Tambah");
        t_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_tambahActionPerformed(evt);
            }
        });

        t_hapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_hapus.setText("Hapus");
        t_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hapusActionPerformed(evt);
            }
        });

        jLabel17.setBackground(new java.awt.Color(255, 255, 255));
        jLabel17.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("Total");

        i_ttl2.setEditable(false);
        i_ttl2.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_ttl2.setText("0");

        tbl_item.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Barang", "Harga", "Jumlah", "Total"
            }
        ));
        tbl_item.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_itemMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tbl_item);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGap(0, 9, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(65, 65, 65)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addComponent(i_jml, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel20))
                                    .addComponent(c_item, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(53, 53, 53))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(t_tambah, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(t_hapus, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(48, 48, 48))))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(i_ttl2)
                        .addContainerGap())))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_item, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20)
                    .addComponent(i_jml, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_tambah)
                    .addComponent(t_hapus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_ttl2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(205, 205, 205)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(46, Short.MAX_VALUE)))
        );

        t_simpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan.setText("Simpan");
        t_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpanActionPerformed(evt);
            }
        });

        t_batal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal.setText("Batal");
        t_batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batalActionPerformed(evt);
            }
        });

        jLabel23.setBackground(new java.awt.Color(255, 255, 255));
        jLabel23.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("TOTAL  :");

        i_ttl3.setEditable(false);
        i_ttl3.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        i_ttl3.setText("0");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel_booking, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(i_ttl3)
                        .addGap(111, 111, 111)
                        .addComponent(t_simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_batal, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_booking)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t_simpan)
                        .addComponent(t_batal))
                    .addComponent(i_ttl3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout panelTransparan31Layout = new javax.swing.GroupLayout(panelTransparan31);
        panelTransparan31.setLayout(panelTransparan31Layout);
        panelTransparan31Layout.setHorizontalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        panelTransparan31Layout.setVerticalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(panelTransparan31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 660));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Soccer-Ball-Wallpaper-HD-Desktop-Background-2014-Soccer-Ball-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t_batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batalActionPerformed
        i_id_booking.setText("");
        i_tgl.setText("");
        i_lp.setText("");

        i_idmember.setText("");
        i_nama.setText("");
        i_tlp.setText("");
        i_dp.setText("");
        i_ttl.setText("0");
        i_durasi.setText("");
        i_jml.setText("");
        i_ttl2.setText("0");
        i_ttl3.setText("0");
        i_harga.setText("");
        c_item.setSelectedItem("-Pilih-");
        r_group.clearSelection();
        i_idmember.setEnabled(false);
        r_st = null;

        int baris = tbl_item.getRowCount();
        for (int i = 0; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item.getModel();
            model.removeRow(0);
        }
        c_jam.setEnabled(false);
    }//GEN-LAST:event_t_batalActionPerformed

    private void t_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpanActionPerformed
        String id = i_id_booking.getText(),
                tg = i_tgl.getText(),
                l = i_lp.getText(),
                j = (String) c_jam.getSelectedItem(),
                im = i_idmember.getText(),
                nm = i_nama.getText(),
                tp = i_tlp.getText(),
                d1 = i_dp.getText(),
                tl1 = i_ttl.getText(),
                tl2 = i_ttl2.getText(),
                hrg = i_harga.getText(),
                drs = i_durasi.getText();

        int jumlah_baris = tbl_item.getRowCount();
        int d = Integer.parseInt(d1), tl = Integer.parseInt(tl1), hrg1 = Integer.parseInt(hrg), drs1 = Integer.parseInt(drs);
        idsewa();
        String l1 = null;

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select *  from lapangan where nama_lapangan='" + l + "'");
            while (res.next()) {
                l1 = res.getString("id_lapangan");

            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        if (r_st == "NonMember") {
            if (i_id_booking.equals("") || i_tgl.equals("") || i_lp.equals("") || i_nama.equals("") || i_tlp.equals("") || i_dp.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {

                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();

                    if (jumlah_baris != 0) {
                        stat.executeUpdate("insert into booking values('" + id + "','" + tg + "','" + l1 + "','" + j + "','" + hrg1 + "','" + drs1 + "','" + r_st + "','" + "-" + "','" + nm + "','" + tp + "','" + idsewa + "','" + d + "','" + tl + "','" + "Pending" + "')");
                        stat.executeUpdate("insert into keuangan values('" + tg + "','" + "Sewa Lapangan" + "','" + id + "','" + tl1 + "','" + "0" + "')");
                    } else {
                        stat.executeUpdate("insert into booking values('" + id + "','" + tg + "','" + l1 + "','" + j + "','" + hrg1 + "','" + drs1 + "','" + r_st + "','" + "-" + "','" + nm + "','" + tp + "','" + "-" + "','" + d + "','" + tl + "','" + "Pending" + "')");
                        stat.executeUpdate("insert into keuangan values('" + tg + "','" + "Sewa Lapangan" + "','" + id + "','" + tl1 + "','" + "0" + "')");
                    }

                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                if (jumlah_baris != 0) {
                    String idbr = null;

                    try {
                        //int i = 0;
                        Statement stat = (Statement) koneksi.Getconnection().createStatement();
                        for (int i = 0; i < jumlah_baris; i++) {
                            Statement stt = (Statement) koneksi.Getconnection().createStatement();
                            ResultSet res = stt.executeQuery("select * from barang where nama_barang='" + tbl_item.getValueAt(i, 1).toString() + "'");
                            while (res.next()) {
                                idbr = res.getString("id_barang");
                            }
                            stat.executeUpdate("insert into sewa values("
                                    + "'" + idsewa + "',"
                                    + "'" + idbr + "',"
                                    + "'" + id + "',"
                                    + "'" + Integer.parseInt(tbl_item.getValueAt(i, 2).toString()) + "',"
                                    + "'" + Integer.parseInt(tbl_item.getValueAt(i, 3).toString()) + "',"
                                    + "'" + Integer.parseInt(tbl_item.getValueAt(i, 4).toString()) + "',"
                                    + "'" + tg + "')");
                            stat.executeUpdate("insert into keuangan values('" + tg + "','" + "Sewa Barang" + "','" + idsewa + "','" + tl2 + "','" + "0" + "')");
                        }

                        stat.close();
                        JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                    }
                }
            }
        } else if (r_st == "Member") {
            if (i_id_booking.equals("") || i_tgl.equals("") || i_lp.equals("") || i_nama.equals("") || i_tlp.equals("") || i_dp.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    if (jumlah_baris != 0) {
                        stat.executeUpdate("insert into booking values('" + id + "','" + tg + "','" + l1 + "','" + j + "','" + hrg1 + "','" + drs1 + "','" + r_st + "','" + im + "','" + nm + "','" + tp + "','" + idsewa + "','" + d + "','" + tl + "','" + "Pending" + "')");
                        stat.executeUpdate("insert into keuangan values('" + tg + "','" + "Sewa Lapangan" + "','" + id + "','" + tl1 + "','" + "0" + "')");
                    } else {
                        stat.executeUpdate("insert into booking values('" + id + "','" + tg + "','" + l1 + "','" + j + "','" + hrg1 + "','" + drs1 + "','" + r_st + "','" + im + "','" + nm + "','" + tp + "','" + "-" + "','" + d + "','" + tl + "','" + "Pending" + "')");
                        stat.executeUpdate("insert into keuangan values('" + tg + "','" + "Sewa Lapangan" + "','" + id + "','" + tl1 + "','" + "0" + "')");
                    }

                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                if (jumlah_baris != 0) {
                    String idbr = null;

                    try {
                        //int i = 0;
                        Statement stat = (Statement) koneksi.Getconnection().createStatement();
                        for (int i = 0; i < jumlah_baris; i++) {
                            Statement stt = (Statement) koneksi.Getconnection().createStatement();
                            ResultSet res = stt.executeQuery("select * from barang where nama_barang='" + tbl_item.getValueAt(i, 1).toString() + "'");
                            while (res.next()) {
                                idbr = res.getString("id_barang");
                            }
                            stat.executeUpdate("insert into sewa values("
                                    + "'" + idsewa + "',"
                                    + "'" + idbr + "',"
                                    + "'" + id + "',"
                                    + "'" + Integer.parseInt(tbl_item.getValueAt(i, 2).toString()) + "',"
                                    + "'" + Integer.parseInt(tbl_item.getValueAt(i, 3).toString()) + "',"
                                    + "'" + Integer.parseInt(tbl_item.getValueAt(i, 4).toString()) + "',"
                                    + "'" + tg + "')");
                            stat.executeUpdate("insert into keuangan values('" + tg + "','" + "Sewa Barang" + "','" + idsewa + "','" + tl2 + "','" + "0" + "')");
                        }

                        stat.close();
                        JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
        }

        i_id_booking.setText("");
        i_tgl.setText("");
        i_lp.setText("");
        i_harga.setText("");
        i_durasi.setText("");
        i_ttl.setText("0");
        i_ttl2.setText("0");
        i_ttl3.setText("0");
        i_idmember.setText("");
        i_nama.setText("");
        i_tlp.setText("");
        i_dp.setText("");
        i_jml.setText("");
        r_group.clearSelection();
        c_item.setSelectedItem("-Pilih-");
        i_idmember.setEnabled(false);
        r_st = null;
        getdatajadwal1();
        getdatajadwal2();
        getdatajadwal3();
        getdatajadwal4();
        getdatajadwal5();
        getdatajadwal6();
        getdatajadwal7();
        getdatajadwal8();
        getdatajadwal9();
        int baris = tbl_item.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item.getModel();
            model.removeRow(0);
        }
        c_jam.setEnabled(false);
    }//GEN-LAST:event_t_simpanActionPerformed

    private void i_idmemberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_idmemberActionPerformed
        String ID = i_idmember.getText(), nm = "", tlp = "", st = "";
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from member where id='" + ID + "'");
            while (res.next()) {
                nm = res.getString("nama");
                tlp = res.getString("no_telp");
                st = res.getString("status");

            }
            if (nm.equals("") && tlp.equals("")) {
                JOptionPane.showMessageDialog(null, "Member tidak terdaftar", " ", JOptionPane.ERROR_MESSAGE);
                i_nama.setText("");
                i_tlp.setText("");
            } else if (st.equals("Nonaktif") ) {
                JOptionPane.showMessageDialog(null, "Member NonAktif", " ", JOptionPane.ERROR_MESSAGE);
                i_nama.setText("");
                i_tlp.setText("");
            } else {
                i_nama.setText(nm);
                i_tlp.setText(tlp);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }//GEN-LAST:event_i_idmemberActionPerformed

    private void r_nonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_r_nonActionPerformed
        if (r_non.isSelected()) {
            i_idmember.setEnabled(false);
            r_st = "NonMember";
            i_nama.setEditable(true);
            i_tlp.setEditable(true);
            i_idmember.setText("");
            i_nama.setText("");
            i_tlp.setText("");
        } else {
            i_idmember.setEnabled(true);
            r_st = "Member";
        }
    }//GEN-LAST:event_r_nonActionPerformed

    private void r_memberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_r_memberActionPerformed
        if (r_member.isSelected()) {
            i_idmember.setEnabled(true);
            r_st = "Member";
            i_nama.setEditable(false);
            i_tlp.setEditable(false);
            i_idmember.setText("");
            i_nama.setText("");
            i_tlp.setText("");
        } else {
            i_idmember.setEnabled(false);
            r_st = "NonMember";
        }
    }//GEN-LAST:event_r_memberActionPerformed

    private void t_ok2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok2ActionPerformed
        int row = tbl_2.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_2.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L02'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok2ActionPerformed
    int no = 1;
    private void t_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_tambahActionPerformed
        t_tambah.setBackground(Color.CYAN);
        t_hapus.setBackground(new java.awt.Color(188, 188, 188));

        String item = (String) c_item.getSelectedItem(), jl = i_jml.getText(), hr = null;
        int jml;

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select harga_sewa from item_sewa where nama_barang='" + item + "'");
            while (res.next()) {
                Object[] ob = new Object[1];
                ob[0] = res.getString(1);
                hr = ((String) ob[0]);
            }
            res.close();
            stat.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }

        int hg = Integer.parseInt(hr), qty1 = Integer.parseInt(jl);
        jml = hg * qty1;
        String j = Integer.toString(jml);

        DefaultTableModel model = (DefaultTableModel) tbl_item.getModel();
        tbl_item.getModel();
        List list = new ArrayList<>();
        tbl_item.setAutoCreateColumnsFromModel(true);
        list.add(no);
        list.add(item);
        list.add(hr);
        list.add(jl);
        list.add(j);
        no++;
        model.addRow(list.toArray());
        //getdatapesan();
        c_item.setSelectedItem("-Pilih-");
        i_jml.setText("");
        st = 0;

        int jumlahBaris = tbl_item.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_item.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }
        i_ttl2.setText(String.valueOf(totalBiaya));
        int t = Integer.parseInt(i_ttl.getText()) + Integer.parseInt(i_ttl2.getText());
        i_ttl3.setText(Integer.toString(t));
    }//GEN-LAST:event_t_tambahActionPerformed

    private void t_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hapusActionPerformed
        t_hapus.setBackground(Color.CYAN);
        t_tambah.setBackground(new java.awt.Color(188, 188, 188));
        st = 1;
    }//GEN-LAST:event_t_hapusActionPerformed

    private void tbl_itemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_itemMouseClicked
        GetData_View();
        int jumlahBaris = tbl_item.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_item.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }
        i_ttl2.setText(String.valueOf(totalBiaya));
        int t = Integer.parseInt(i_ttl.getText()) + Integer.parseInt(i_ttl2.getText());
        i_ttl3.setText(Integer.toString(t));
    }//GEN-LAST:event_tbl_itemMouseClicked

    private void i_ttlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_ttlActionPerformed

    }//GEN-LAST:event_i_ttlActionPerformed

    private void i_durasiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_durasiKeyPressed


    }//GEN-LAST:event_i_durasiKeyPressed

    private void i_durasiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_durasiKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_i_durasiKeyTyped

    private void i_durasiFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_i_durasiFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_i_durasiFocusGained

    private void i_durasiComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_i_durasiComponentAdded

    }//GEN-LAST:event_i_durasiComponentAdded

    private void t_hitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hitungActionPerformed
        try {
            int h = Integer.parseInt(i_harga.getText()), d = Integer.parseInt(i_durasi.getText()), j = 0;
            j = h * d;
            i_ttl.setText(Integer.toString(j));
        } catch (Exception ex) {
            i_ttl.setText("0");
        }

        int t = Integer.parseInt(i_ttl.getText()) + Integer.parseInt(i_ttl2.getText());
        i_ttl3.setText(Integer.toString(t));
    }//GEN-LAST:event_t_hitungActionPerformed

    private void t_ok9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok9ActionPerformed
        int row = tbl_9.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_9.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L09'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok9ActionPerformed

    private void t_ok8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok8ActionPerformed
        int row = tbl_8.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_8.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L08'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok8ActionPerformed

    private void t_ok7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok7ActionPerformed
        int row = tbl_7.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_7.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L07'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok7ActionPerformed

    private void t_ok6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok6ActionPerformed
        int row = tbl_6.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_6.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L06'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok6ActionPerformed

    private void t_ok5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok5ActionPerformed
        int row = tbl_5.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_5.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L05'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok5ActionPerformed

    private void t_ok4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok4ActionPerformed
        int row = tbl_4.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_4.getDate()));
        i_lp.setText("4");
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L04'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok4ActionPerformed

    private void t_ok3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok3ActionPerformed
        int row = tbl_3.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_3.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L03'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok3ActionPerformed

    private void kal_1VetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_kal_1VetoableChange

    }//GEN-LAST:event_kal_1VetoableChange

    private void kal_1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_kal_1PropertyChange
        //JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
    }//GEN-LAST:event_kal_1PropertyChange

    private void kal_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kal_1MouseClicked
        /*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String t = sdf.format(kal_1.getDate());
        String jm;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where tanggal='" + t + "'and lapangan ='1'");
            while (res.next()) {
                jm = res.getString("jam");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }*/

        JOptionPane.showMessageDialog(rootPane, "a");
    }//GEN-LAST:event_kal_1MouseClicked

    private void t_ok1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok1ActionPerformed
        int row = tbl_1.getSelectedRow();
        idbooking();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        i_tgl.setText(sdf.format(kal_1.getDate()));
        String hr = null, nm = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where id_lapangan='L01'");
            while (res.next()) {
                hr = res.getString("harga");
                nm = res.getString("nama_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        i_lp.setText(nm);
        i_harga.setText(hr);
        c_jam.setEnabled(true);
    }//GEN-LAST:event_t_ok1ActionPerformed
    String ktfinal = "00";

    public void cek() {
        String jm = (String) c_jam.getSelectedItem(), jam = "", dr = "", lp = "", tgl = i_tgl.getText();
        String[] jdw = null;
        String kt = "00", kt2 = "00", jm2 = "00";
        int kt1, dr1, t;
        int i = 0, j = 0;
        try {
            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan where nama_lapangan='" + i_lp.getText() + "'");
            while (res.next()) {
                lp = res.getString("id_lapangan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_lapangan='" + lp + "'and jam='" + jm + "'and tanggal='" + tgl + "' and status_main='" + "Pending" + "'");
            while (res.next()) {
                //jam = res.getString("jam");
                kt = res.getString("jam").substring(0, 2);
                kt1 = Integer.parseInt(kt);
                //jdw[i] = kt1;
                dr = res.getString("durasi");
                dr1 = Integer.parseInt(dr);
                t = kt1 + dr1;
                if (t > 9) {
                    kt2 = Integer.toString(t);
                } else {
                    kt2 = "0" + Integer.toString(t);
                }
            }
            jm2 = jm.substring(0, 2);
            if (Integer.parseInt(jm2) >= Integer.parseInt(kt) && Integer.parseInt(jm2) <= Integer.parseInt(kt2)) {
                System.out.println(kt);
                System.out.println(kt2);
                System.out.println(dr);
                System.out.println(jm2);
                JOptionPane.showMessageDialog(null, "Jam Sudah Dipesan", " ", JOptionPane.ERROR_MESSAGE);
                c_jam.setSelectedItem("-Pilih-");
            }
            /*if (jm.equals(jdw[k])) {
                JOptionPane.showMessageDialog(null, "Jam Sudah Dipesan", " ", JOptionPane.ERROR_MESSAGE);
                c_jam.setSelectedItem("-Pilih-");
            }*/

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        //i = 0;
    }
    private void c_jamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_jamActionPerformed
        cek();
    }//GEN-LAST:event_c_jamActionPerformed

    private void t_cari7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari7ActionPerformed
        getdatajadwal7();
    }//GEN-LAST:event_t_cari7ActionPerformed

    private void t_cari1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari1ActionPerformed
        getdatajadwal1();
    }//GEN-LAST:event_t_cari1ActionPerformed

    private void t_cari2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari2ActionPerformed
        getdatajadwal2();
    }//GEN-LAST:event_t_cari2ActionPerformed

    private void t_cari3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari3ActionPerformed
        getdatajadwal3();
    }//GEN-LAST:event_t_cari3ActionPerformed

    private void t_cari4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari4ActionPerformed
        getdatajadwal4();
    }//GEN-LAST:event_t_cari4ActionPerformed

    private void t_cari5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari5ActionPerformed
        getdatajadwal5();
    }//GEN-LAST:event_t_cari5ActionPerformed

    private void t_cari6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari6ActionPerformed
        getdatajadwal6();
    }//GEN-LAST:event_t_cari6ActionPerformed

    private void t_cari8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari8ActionPerformed
        getdatajadwal8();
    }//GEN-LAST:event_t_cari8ActionPerformed

    private void t_cari9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari9ActionPerformed
        getdatajadwal9();
    }//GEN-LAST:event_t_cari9ActionPerformed

    String r_st = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(d_booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(d_booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(d_booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(d_booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                d_booking dialog = new d_booking(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> c_item;
    private javax.swing.JComboBox<String> c_jam;
    private javax.swing.JTextField i_dp;
    private javax.swing.JTextField i_durasi;
    private javax.swing.JTextField i_harga;
    private javax.swing.JTextField i_id_booking;
    private javax.swing.JTextField i_idmember;
    private javax.swing.JTextField i_jml;
    private javax.swing.JTextField i_lp;
    private javax.swing.JTextField i_nama;
    private javax.swing.JTextField i_nama5;
    private javax.swing.JTextField i_tgl;
    private javax.swing.JTextField i_tlp;
    private javax.swing.JTextField i_ttl;
    private javax.swing.JTextField i_ttl2;
    private javax.swing.JTextField i_ttl3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private com.toedter.calendar.JDateChooser kal_1;
    private com.toedter.calendar.JDateChooser kal_2;
    private com.toedter.calendar.JDateChooser kal_3;
    private com.toedter.calendar.JDateChooser kal_4;
    private com.toedter.calendar.JDateChooser kal_5;
    private com.toedter.calendar.JDateChooser kal_6;
    private com.toedter.calendar.JDateChooser kal_7;
    private com.toedter.calendar.JDateChooser kal_8;
    private com.toedter.calendar.JDateChooser kal_9;
    private FV.PanelTransparan2 panelTransparan21;
    private FV.PanelTransparan3 panelTransparan31;
    private javax.swing.JPanel panel_bk1;
    private javax.swing.JPanel panel_bk2;
    private javax.swing.JPanel panel_bk3;
    private javax.swing.JPanel panel_bk4;
    private javax.swing.JPanel panel_bk5;
    private javax.swing.JPanel panel_bk6;
    private javax.swing.JPanel panel_bk7;
    private javax.swing.JPanel panel_bk8;
    private javax.swing.JPanel panel_bk9;
    private javax.swing.JTabbedPane panel_booking;
    private javax.swing.ButtonGroup r_group;
    private javax.swing.JRadioButton r_member;
    private javax.swing.JRadioButton r_non;
    private javax.swing.JButton t_batal;
    private javax.swing.JButton t_cari1;
    private javax.swing.JButton t_cari2;
    private javax.swing.JButton t_cari3;
    private javax.swing.JButton t_cari4;
    private javax.swing.JButton t_cari5;
    private javax.swing.JButton t_cari6;
    private javax.swing.JButton t_cari7;
    private javax.swing.JButton t_cari8;
    private javax.swing.JButton t_cari9;
    private javax.swing.JButton t_hapus;
    private javax.swing.JButton t_hitung;
    private javax.swing.JButton t_ok1;
    private javax.swing.JButton t_ok2;
    private javax.swing.JButton t_ok3;
    private javax.swing.JButton t_ok4;
    private javax.swing.JButton t_ok5;
    private javax.swing.JButton t_ok6;
    private javax.swing.JButton t_ok7;
    private javax.swing.JButton t_ok8;
    private javax.swing.JButton t_ok9;
    private javax.swing.JButton t_simpan;
    private javax.swing.JButton t_tambah;
    private javax.swing.JTable tbl_1;
    private javax.swing.JTable tbl_2;
    private javax.swing.JTable tbl_3;
    private javax.swing.JTable tbl_4;
    private javax.swing.JTable tbl_5;
    private javax.swing.JTable tbl_6;
    private javax.swing.JTable tbl_7;
    private javax.swing.JTable tbl_8;
    private javax.swing.JTable tbl_9;
    private javax.swing.JTable tbl_item;
    // End of variables declaration//GEN-END:variables
}
