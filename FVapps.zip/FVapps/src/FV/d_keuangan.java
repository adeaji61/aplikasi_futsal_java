/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

/**
 *
 * @author User
 */
public class d_keuangan extends javax.swing.JDialog {

    /**
     * Creates new form d_akun
     */
    public d_keuangan(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initUI();
        tgl_op.setDateFormatString("dd-MM-yyyy");
        tgl_op3.setDateFormatString("dd-MM-yyyy");
        tgl_op4.setDateFormatString("dd-MM-yyyy");
        idop();
        getdataop();
        getdatauang();
        saldo();
    }

    private void initUI() {
        getContentPane().setBackground(new Color(245, 245, 245));

        Dimension windowSize = getSize();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Point centerPoint = ge.getCenterPoint();
        int dx = centerPoint.x - windowSize.width / 2;
        int dy = centerPoint.y - windowSize.height / 2;
        setLocation(dx, dy);
    }

    public void idop() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_op,6)) as idop from operasional");
            while (res.next()) {
                if (res.first() == false) {
                    i_id_op.setText("OP00001");
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 6 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    i_id_op.setText("OP" + nomor);
                }

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void saldo() {
        String d = "0", k = "0";
        int d1 = 0, k1 = 0, s = 0, d2 = 0, k2 = 0;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select *  from keuangan");
            while (res.next()) {
                d = res.getString("debet");
                k = res.getString("kredit");
                d1 = Integer.parseInt(d);
                k1 = Integer.parseInt(k);
                d2 = d2 + d1;
                k2 = k2 + k1;
                s = s + (d1 - k1);
            }
            i_jumlah_op4.setText(Integer.toString(s));
            i_debet.setText(Integer.toString(d2));
            i_kredit.setText(Integer.toString(k2));
            i_saldo.setText(Integer.toString(s));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdataop() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Operasional");
        model.addColumn("Tanggal");
        model.addColumn("Jumlah");
        model.addColumn("Status");
        model.addColumn("Deskripsi");
        table_op.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from operasional");
            //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_op"),
                    res.getString("tanggal"),
                    res.getString("jumlah"),
                    res.getString("status"),
                    res.getString("deskripsi"),});
                table_op.setModel(model);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatauang() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Tanggal");
        model.addColumn("Sumber Pendapatan");
        model.addColumn("ID");
        model.addColumn("Debet");
        model.addColumn("Kredit");
        tbl_keuangan.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from keuangan");
            //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("tanggal"),
                    res.getString("sumber"),
                    res.getString("id"),
                    res.getString("debet"),
                    res.getString("kredit"),});
                tbl_keuangan.setModel(model);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_keuangan.getRowCount();
        int totaldebet = 0, totalkredit = 0;
        int jumlahdebet, jumlahkredit;
        TableModel tabelModel;
        tabelModel = tbl_keuangan.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahdebet = Integer.parseInt(tabelModel.getValueAt(i, 3).toString());
            totaldebet = totaldebet + jumlahdebet;//(jumlahBarang * hargaBarang);
            jumlahkredit = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalkredit = totalkredit + jumlahkredit;//(jumlahBarang * hargaBarang);
        }

        i_subdebet.setText(String.valueOf(totaldebet));
        i_subkredit.setText(String.valueOf(totalkredit));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        r_group = new javax.swing.ButtonGroup();
        jLabel9 = new javax.swing.JLabel();
        i_nama5 = new javax.swing.JTextField();
        panelTransparan21 = new FV.PanelTransparan2();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelTransparan31 = new FV.PanelTransparan3();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        i_id_op = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        i_jumlah_op = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        c_status_op = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        t_deskripsi_op = new javax.swing.JTextArea();
        t_simpan = new javax.swing.JButton();
        t_batal = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        table_op = new javax.swing.JTable();
        c_cari_op = new javax.swing.JComboBox<>();
        t_cari_op = new javax.swing.JButton();
        t_refresh_op = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        tgl_op1 = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        tgl_op2 = new com.toedter.calendar.JDateChooser();
        tgl_op = new com.toedter.calendar.JDateChooser();
        jLabel16 = new javax.swing.JLabel();
        i_jumlah_op4 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        t_simpan1 = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        i_debet = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_keuangan = new javax.swing.JTable();
        jLabel35 = new javax.swing.JLabel();
        i_kredit = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        i_saldo = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        tgl_op3 = new com.toedter.calendar.JDateChooser();
        jLabel18 = new javax.swing.JLabel();
        tgl_op4 = new com.toedter.calendar.JDateChooser();
        t_cari_op1 = new javax.swing.JButton();
        t_refresh_op1 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        i_subdebet = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        i_subkredit = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Nama");

        i_nama5.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTransparan21.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(11, 108, 151));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Operasional");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(785, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelTransparan21Layout = new javax.swing.GroupLayout(panelTransparan21);
        panelTransparan21.setLayout(panelTransparan21Layout);
        panelTransparan21Layout.setHorizontalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan21Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelTransparan21Layout.setVerticalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan21Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(panelTransparan21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 50));

        panelTransparan31.setBackground(new java.awt.Color(51, 51, 51));

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setText("ID Operasional");

        i_id_op.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_id_op.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_id_opActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setText("Tanggal");

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel8.setText("Jumlah                      Rp. ");

        i_jumlah_op.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_jumlah_op.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_jumlah_opActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel10.setText("Status");

        c_status_op.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        c_status_op.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Pilih - ", "Pemasukan", "Pengeluaran" }));

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel11.setText("Deskripsi");

        t_deskripsi_op.setColumns(20);
        t_deskripsi_op.setRows(5);
        jScrollPane1.setViewportView(t_deskripsi_op);

        t_simpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan.setText("Simpan");
        t_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpanActionPerformed(evt);
            }
        });

        t_batal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal.setText("Batal");
        t_batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batalActionPerformed(evt);
            }
        });

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        table_op.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id Operasional", "Tanggal", "Jumlah", "Status", "Deskripsi"
            }
        ));
        jScrollPane2.setViewportView(table_op);

        c_cari_op.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        c_cari_op.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Pilih - ", "Pemasukan", "Pengeluaran" }));

        t_cari_op.setText("Cari");
        t_cari_op.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari_opActionPerformed(evt);
            }
        });

        t_refresh_op.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        t_refresh_op.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_refresh_opActionPerformed(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel34.setText("Tanggal");

        jLabel12.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("s/d");

        jLabel16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel16.setText("Saldo");

        i_jumlah_op4.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_jumlah_op4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_jumlah_op4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(c_status_op, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(i_jumlah_op, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(70, 70, 70)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(t_simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(t_batal, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(29, 29, 29))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(80, 80, 80)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(i_id_op, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                            .addComponent(tgl_op, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(36, 36, 36)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_cari_op, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tgl_op1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tgl_op2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(t_cari_op, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_refresh_op, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(114, 114, 114)
                        .addComponent(i_jumlah_op4, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(i_id_op, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(tgl_op, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(i_jumlah_op, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(c_status_op, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_simpan)
                    .addComponent(t_batal))
                .addGap(135, 135, 135))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(c_cari_op, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tgl_op1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tgl_op2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(t_cari_op)
                            .addComponent(t_refresh_op, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(i_jumlah_op4)
                            .addComponent(jLabel16)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Operasional", jPanel2);

        t_simpan1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan1.setText("Cetak");
        t_simpan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpan1ActionPerformed(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        jLabel33.setText("Total Debet  ");

        i_debet.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_debet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_debetActionPerformed(evt);
            }
        });

        tbl_keuangan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tbl_keuangan);

        jLabel35.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        jLabel35.setText("Total Kredit");

        i_kredit.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_kredit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_kreditActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        jLabel36.setText("Saldo Akhir");

        i_saldo.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        i_saldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_saldoActionPerformed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel37.setText("Tanggal");

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("s/d");

        t_cari_op1.setText("Cari");
        t_cari_op1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_cari_op1ActionPerformed(evt);
            }
        });

        t_refresh_op1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        t_refresh_op1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_refresh_op1ActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel38.setText("Subtotal Debet :");
        jLabel38.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        i_subdebet.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_subdebet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_subdebetActionPerformed(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel39.setText("Subtotal Kredit :");
        jLabel39.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        i_subkredit.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_subkredit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_subkreditActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel37)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tgl_op3, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tgl_op4, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(t_cari_op1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(t_refresh_op1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(116, 116, 116)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel35)
                            .addComponent(jLabel36)
                            .addComponent(jLabel33)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGap(129, 129, 129)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(i_saldo, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(i_kredit, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(i_debet, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(t_simpan1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 889, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(i_subdebet)
                                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(105, 105, 105)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(i_subkredit)
                                .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE))
                            .addGap(43, 43, 43))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tgl_op3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tgl_op4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(t_cari_op1)
                            .addComponent(t_refresh_op1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(i_debet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel33))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(i_kredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(i_saldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel36))
                        .addGap(18, 18, 18)))
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(i_subkredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addComponent(t_simpan1))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(i_subdebet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(47, 47, 47))
        );

        jTabbedPane1.addTab("Laporan Keuangan", jPanel3);

        javax.swing.GroupLayout panelTransparan31Layout = new javax.swing.GroupLayout(panelTransparan31);
        panelTransparan31.setLayout(panelTransparan31Layout);
        panelTransparan31Layout.setHorizontalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 925, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        panelTransparan31Layout.setVerticalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan31Layout.createSequentialGroup()
                .addContainerGap(77, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        getContentPane().add(panelTransparan31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 660));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Soccer-Ball-Wallpaper-HD-Desktop-Background-2014-Soccer-Ball-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t_refresh_opActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_refresh_opActionPerformed
        i_id_op.setText("");
        tgl_op.setDate(null);
        tgl_op1.setDate(null);
        tgl_op2.setDate(null);
        i_jumlah_op.setText("");
        c_status_op.setSelectedItem("- Pilih -");
        c_cari_op.setSelectedItem("- Pilih -");
        t_deskripsi_op.setText("");
        idop();
        getdataop();
    }//GEN-LAST:event_t_refresh_opActionPerformed

    private void t_cari_opActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari_opActionPerformed
        String t = null, t1 = null, kt = (String) c_cari_op.getSelectedItem();

        if (tgl_op1.getDate() != null && tgl_op2.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_op1.getDate());
            t1 = format.format(tgl_op2.getDate());
        }
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Operasional");
        model.addColumn("Tanggal");
        model.addColumn("Jumlah");
        model.addColumn("Status");
        model.addColumn("Deskripsi");
        table_op.setModel(model);

        if (kt.equals("Pemasukan") /*&& t.equals(null) && t1.equals(null)*/) {
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select * from operasional where status='Pemasukan'");
                //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

                while (res.next()) {

                    model.addRow(new Object[]{
                        res.getString("id_op"),
                        res.getString("tanggal"),
                        res.getString("jumlah"),
                        res.getString("status"),
                        res.getString("deskripsi"),});
                    table_op.setModel(model);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(rootPane, e.getMessage());
            }
        } else if (kt.equals("Pengeluaran") /*&& t.equals(null) && t1.equals(null)*/) {
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select * from operasional where status='Pengeluaran'");
                //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

                while (res.next()) {

                    model.addRow(new Object[]{
                        res.getString("id_op"),
                        res.getString("tanggal"),
                        res.getString("jumlah"),
                        res.getString("status"),
                        res.getString("deskripsi"),});
                    table_op.setModel(model);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(rootPane, e.getMessage());
            }
        } else if (/*kt.equals("- Pilih -") &&*/!t.equals(null) && !t1.equals(null)) {
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select * from operasional where tanggal between '" + t + "'and'" + t1 + "'");
                //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

                while (res.next()) {

                    model.addRow(new Object[]{
                        res.getString("id_op"),
                        res.getString("tanggal"),
                        res.getString("jumlah"),
                        res.getString("status"),
                        res.getString("deskripsi"),});
                    table_op.setModel(model);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(rootPane, e.getMessage());
            }
        }
    }//GEN-LAST:event_t_cari_opActionPerformed

    private void t_batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batalActionPerformed
        i_id_op.setText("");
        tgl_op.setDate(null);
        i_jumlah_op.setText("");
        c_status_op.setSelectedItem("- Pilih -");
        t_deskripsi_op.setText("");
        getdataop();
    }//GEN-LAST:event_t_batalActionPerformed

    private void t_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpanActionPerformed
        String t = null, sl = i_jumlah_op4.getText();
        int sl1 = 0;
        sl1 = Integer.parseInt(sl);
        if (tgl_op.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_op.getDate());

        }
        String id = i_id_op.getText(),
                status = (String) c_status_op.getSelectedItem(),
                jumlah = i_jumlah_op.getText(),
                des = t_deskripsi_op.getText();
        int jl1 = 0;
        jl1 = Integer.parseInt(jumlah);

        if (id.equals("") || jumlah.equals("") || status.equals("-Pilih-") || des.equals("")) {
            JOptionPane.showMessageDialog(null, "Masukan Data Dengan Benar", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
        } else {

            if (status.equals("Pemasukan")) {
                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();

                    stat.executeUpdate("insert into operasional values('" + id + "','" + t + "','" + jumlah + "','" + status + "','" + des + "')");
                    stat.executeUpdate("insert into keuangan values('" + t + "','" + "Pemasukan Operasional" + "','" + id + "','" + jumlah + "','" + "0" + "')");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            } else if (status.equals("Pengeluaran")) {
                if (jl1 > sl1) {
                    JOptionPane.showMessageDialog(null, "Saldo Tidak Mencukupi", "", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        //int i = 0;
                        Statement stat = (Statement) koneksi.Getconnection().createStatement();

                        stat.executeUpdate("insert into operasional values('" + id + "','" + t + "','" + jumlah + "','" + status + "','" + des + "')");
                        stat.executeUpdate("insert into keuangan values('" + t + "','" + "Pengeluaran Operasional" + "','" + id + "','" + "0" + "','" + jumlah + "')");
                        stat.close();
                        JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                    }
                }
            }

        }

        i_id_op.setText("");
        tgl_op.setDate(null);
        i_jumlah_op.setText("");
        c_status_op.setSelectedItem("- Pilih -");
        t_deskripsi_op.setText("");
        idop();
        getdataop();
        saldo();
    }//GEN-LAST:event_t_simpanActionPerformed

    private void i_jumlah_opActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_jumlah_opActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_jumlah_opActionPerformed

    private void i_id_opActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_id_opActionPerformed
        /*
        getdatabooking();
        int baris = tbl_item1.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            model.removeRow(0);
        }
        i_sub.setText("0");
        i_total.setText("0");
        i_kembalian.setText("0");
        i_bayar.setText("0");
         */
    }//GEN-LAST:event_i_id_opActionPerformed

    private void i_debetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_debetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_debetActionPerformed

    private void t_simpan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpan1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_simpan1ActionPerformed

    private void i_kreditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_kreditActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_kreditActionPerformed

    private void i_saldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_saldoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_saldoActionPerformed

    private void t_cari_op1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_cari_op1ActionPerformed
        String t = null, t1 = null;

        if (tgl_op3.getDate() != null && tgl_op4.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            t = format.format(tgl_op3.getDate());
            t1 = format.format(tgl_op4.getDate());
        }
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model.addColumn("Tanggal");
        model.addColumn("Sumber Pendapatan");
        model.addColumn("ID");
        model.addColumn("Debet");
        model.addColumn("Kredit");
        tbl_keuangan.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from keuangan where tanggal between '" + t + "'and'" + t1 + "'");
            //ResultSet res1 = stat.executeQuery("select * from sewa,booking where sewa.id_booking=booking.id_booking and booking.status_main='Lunas'");

            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("tanggal"),
                    res.getString("sumber"),
                    res.getString("id"),
                    res.getString("debet"),
                    res.getString("kredit"),});
                tbl_keuangan.setModel(model);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_keuangan.getRowCount();
        int totaldebet = 0, totalkredit = 0;
        int jumlahdebet, jumlahkredit;
        TableModel tabelModel;
        tabelModel = tbl_keuangan.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahdebet = Integer.parseInt(tabelModel.getValueAt(i, 3).toString());
            totaldebet = totaldebet + jumlahdebet;//(jumlahBarang * hargaBarang);
            jumlahkredit = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalkredit = totalkredit + jumlahkredit;//(jumlahBarang * hargaBarang);
        }

        i_subdebet.setText(String.valueOf(totaldebet));
        i_subkredit.setText(String.valueOf(totalkredit));
    }//GEN-LAST:event_t_cari_op1ActionPerformed

    private void t_refresh_op1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_refresh_op1ActionPerformed
        idop();
        getdataop();
        getdatauang();
        saldo();
    }//GEN-LAST:event_t_refresh_op1ActionPerformed

    private void i_subdebetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_subdebetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_subdebetActionPerformed

    private void i_subkreditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_subkreditActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_subkreditActionPerformed

    private void i_jumlah_op4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_jumlah_op4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_jumlah_op4ActionPerformed
    int no = 1;
    String r_st = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(d_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(d_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(d_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(d_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                d_keuangan dialog = new d_keuangan(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> c_cari_op;
    private javax.swing.JComboBox<String> c_status_op;
    private javax.swing.JTextField i_debet;
    private javax.swing.JTextField i_id_op;
    private javax.swing.JTextField i_jumlah_op;
    private javax.swing.JTextField i_jumlah_op4;
    private javax.swing.JTextField i_kredit;
    private javax.swing.JTextField i_nama5;
    private javax.swing.JTextField i_saldo;
    private javax.swing.JTextField i_subdebet;
    private javax.swing.JTextField i_subkredit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private FV.PanelTransparan2 panelTransparan21;
    private FV.PanelTransparan3 panelTransparan31;
    private javax.swing.ButtonGroup r_group;
    private javax.swing.JButton t_batal;
    private javax.swing.JButton t_cari_op;
    private javax.swing.JButton t_cari_op1;
    private javax.swing.JTextArea t_deskripsi_op;
    private javax.swing.JButton t_refresh_op;
    private javax.swing.JButton t_refresh_op1;
    private javax.swing.JButton t_simpan;
    private javax.swing.JButton t_simpan1;
    private javax.swing.JTable table_op;
    private javax.swing.JTable tbl_keuangan;
    private com.toedter.calendar.JDateChooser tgl_op;
    private com.toedter.calendar.JDateChooser tgl_op1;
    private com.toedter.calendar.JDateChooser tgl_op2;
    private com.toedter.calendar.JDateChooser tgl_op3;
    private com.toedter.calendar.JDateChooser tgl_op4;
    // End of variables declaration//GEN-END:variables
}
