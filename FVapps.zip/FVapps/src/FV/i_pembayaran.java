/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author DwiY
 */
public class i_pembayaran extends javax.swing.JInternalFrame {

    /**
     * Creates new form i_pembayaran
     */
    int tahun, bulan, hari;

    public i_pembayaran() {
        initComponents();
        getdatabooking0();
        new Thread() {
            public void run() {
                while (true) {
                    Calendar kl = new GregorianCalendar();
                    tahun = kl.get(Calendar.YEAR);
                    bulan = kl.get(Calendar.MONTH) + 1;
                    hari = kl.get(Calendar.DAY_OF_MONTH);
                }
            }
        }.start();
    }

    String row_id;

    private void GetData_main() {
        int row = tbl_0.getSelectedRow();
        row_id = (tbl_0.getModel().getValueAt(row, 0).toString());
        i_idbook.setText(row_id);
    }
    int ttl=0;
    public void total() {
        int jumlahBaris = tbl_item1.getRowCount();
        int jumlahBaris1 = tbl_0.getSelectedRow();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang; //ttl;

        TableModel tabelModel;
        TableModel tabelModel1;
        tabelModel = tbl_item1.getModel();
        tabelModel1 = tbl_0.getModel();
        ttl = Integer.parseInt(tabelModel1.getValueAt(jumlahBaris1, 11).toString());
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            hargaBarang = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalBiaya = totalBiaya + hargaBarang;//(jumlahBarang * hargaBarang);
        }
        if (totalBiaya == 0) {
            i_total.setText(String.valueOf(ttl));
        } else {
            i_total.setText(String.valueOf(totalBiaya + ttl));
        }
    }

    public void getdatabooking0() {
        DefaultTableModel model0 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model0.addColumn("Id Booking");
        model0.addColumn("Tanggal");
        model0.addColumn("Lapangan");
        model0.addColumn("Jam");
        model0.addColumn("Durasi");
        model0.addColumn("Status");
        model0.addColumn("Id Member");
        model0.addColumn("Nama");
        model0.addColumn("Id Sewa");
        model0.addColumn("Status Main");
        model0.addColumn("Total");
        model0.addColumn("Uang Muka");
        model0.addColumn("Sisa Bayar");
        tbl_0.setModel(model0);
        String idbook = i_idbook.getText(), ttl = "0", dp = "0";
        int sb = 0;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking,lapangan where status_main='" + "Selesai" + "' and booking.id_lapangan=lapangan.id_lapangan");
            while (res.next()) {
                ttl = res.getString("total");
                dp = res.getString("dp");
                sb = Integer.parseInt(ttl) - Integer.parseInt(dp);
                model0.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("nama_lapangan"),
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),
                    res.getString("id_member"),
                    res.getString("nama"),
                    res.getString("id_sewa"),
                    res.getString("status_main"),
                    res.getString("total"),
                    res.getString("dp"),
                    Integer.toString(sb)
                });
                tbl_0.setModel(model0);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking() {
        DefaultTableModel model0 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model0.addColumn("Id Booking");
        model0.addColumn("Tanggal");
        model0.addColumn("Lapangan");
        model0.addColumn("Jam");
        model0.addColumn("Durasi");
        model0.addColumn("Status");
        model0.addColumn("Id Member");
        model0.addColumn("Nama");
        model0.addColumn("Id Sewa");
        model0.addColumn("Status Main");
        model0.addColumn("Total");
        model0.addColumn("Uang Muka");
        model0.addColumn("Sisa Bayar");
        tbl_0.setModel(model0);
        String idbook = i_idbook.getText(), ttl = "0", dp = "0";
        int sb = 0;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking,lapangan where id_booking='" + idbook + "'and booking.id_lapangan=lapangan.id_lapangan");
            while (res.next()) {
                ttl = res.getString("total");
                dp = res.getString("dp");
                sb = Integer.parseInt(ttl) - Integer.parseInt(dp);
                model0.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("nama_lapangan"),
                    res.getString("jam"),
                    res.getString("durasi"),
                    res.getString("status"),
                    res.getString("id_member"),
                    res.getString("nama"),
                    res.getString("id_sewa"),
                    res.getString("status_main"),
                    res.getString("total"),
                    res.getString("dp"),
                    Integer.toString(sb)
                });
                tbl_0.setModel(model0);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    private void jumlah() {
        int t, b, t1;
        t = Integer.parseInt(i_total.getText());
        b = Integer.parseInt(i_bayar.getText());
        t1 = t - b;
        i_kembalian.setText(Integer.toString(t1));
        if (t1 >= t) {
            //t_simpan.setEnabled(true);
        } else if (t1 < t) {
            //t_simpan.setEnabled(false);
        }
    }

    public void getdatasewa() {
        DefaultTableModel model1 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        String idbook = i_idbook.getText();
        int no = 1;
        String sw = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from sewa where id_booking='" + idbook + "'");
            while (res.next()) {
                sw = res.getString("id_sewa");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        model1.addColumn("No");
        model1.addColumn("Barang");
        model1.addColumn("Harga");
        model1.addColumn("Jumlah");
        model1.addColumn("Total");
        tbl_item1.setModel(model1);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from sewa,barang where sewa.id_sewa='" + sw + "' and barang.id_barang=sewa.id_barang");
            while (res.next()) {

                model1.addRow(new Object[]{
                    no,
                    res.getString("nama_barang"),
                    res.getString("harga"),
                    res.getString("qty"),
                    res.getString("jumlah")
                });
                no++;
                tbl_item1.setModel(model1);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        int jumlahBaris = tbl_item1.getRowCount();
        int totalBiaya = 0;
        int jumlahBarang, hargaBarang;
        TableModel tabelModel;
        tabelModel = tbl_item1.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalBiaya = totalBiaya + jumlahBarang;//(jumlahBarang * hargaBarang);
        }

        i_sub.setText(String.valueOf(totalBiaya));
    }
    String idbyr = null;

    public void idbayar() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_pembayaran,6)) as idbayar from pembayaran");
            while (res.next()) {
                if (res.first() == false) {
                    idbyr = "BY00001";
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 6 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    idbyr = "BY" + nomor;
                }

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        i_idbook = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_0 = new javax.swing.JTable();
        panelGlass6 = new usu.widget.glass.PanelGlass();
        jScrollPane8 = new javax.swing.JScrollPane();
        tbl_item1 = new javax.swing.JTable();
        jLabel24 = new javax.swing.JLabel();
        panelGlass8 = new usu.widget.glass.PanelGlass();
        LKoma2 = new usu.widget.Label();
        label5 = new usu.widget.Label();
        i_bayar = new usu.widget.TextBox();
        panelGlass2 = new usu.widget.glass.PanelGlass();
        LKoma1 = new usu.widget.Label();
        label2 = new usu.widget.Label();
        i_total = new usu.widget.TextBox();
        panelGlass10 = new usu.widget.glass.PanelGlass();
        LKoma3 = new usu.widget.Label();
        label7 = new usu.widget.Label();
        i_kembalian = new usu.widget.TextBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        t_simpan = new javax.swing.JButton();
        t_batal = new javax.swing.JButton();
        i_sub = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setTitle("Pembayaran");
        setPreferredSize(new java.awt.Dimension(1150, 540));
        setRequestFocusEnabled(false);

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setText("Cari Kode Boking :");

        i_idbook.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_idbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_idbookActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        tbl_0.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Booking", "Tanggal", "Lapangan", "Jam", "Status", "Id Member", "Nama", "Status Main", "Total"
            }
        ));
        tbl_0.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_0MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_0);

        panelGlass6.setWarna(new java.awt.Color(255, 255, 51));

        tbl_item1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Barang", "Harga", "Jumlah", "Total"
            }
        ));
        tbl_item1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_item1MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(tbl_item1);

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("DAFTAR SEWA BARANG");

        panelGlass8.setBackgroundImageType(usu.widget.constan.BackgroundConstan.BACKGROUND_IMAGE_CENTER_TOP);
        panelGlass8.setOpaqueGradient(true);
        panelGlass8.setOpaqueImage(false);
        panelGlass8.setRound(false);
        panelGlass8.setWarna(new java.awt.Color(0, 204, 0));

        LKoma2.setForeground(new java.awt.Color(255, 255, 255));
        LKoma2.setText(",-");
        LKoma2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        label5.setForeground(new java.awt.Color(255, 255, 255));
        label5.setText("Rp.");
        label5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        i_bayar.setBackground(new java.awt.Color(255, 255, 255));
        i_bayar.setForeground(new java.awt.Color(0, 0, 0));
        i_bayar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        i_bayar.setText("0");
        i_bayar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        i_bayar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                i_bayarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                i_bayarFocusLost(evt);
            }
        });
        i_bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_bayarActionPerformed(evt);
            }
        });
        i_bayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                i_bayarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout panelGlass8Layout = new javax.swing.GroupLayout(panelGlass8);
        panelGlass8.setLayout(panelGlass8Layout);
        panelGlass8Layout.setHorizontalGroup(
            panelGlass8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(i_bayar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LKoma2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        panelGlass8Layout.setVerticalGroup(
            panelGlass8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelGlass8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LKoma2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelGlass2.setBackgroundImageType(usu.widget.constan.BackgroundConstan.BACKGROUND_IMAGE_CENTER_TOP);
        panelGlass2.setOpaqueGradient(true);
        panelGlass2.setOpaqueImage(false);
        panelGlass2.setRound(false);
        panelGlass2.setWarna(new java.awt.Color(0, 204, 0));

        LKoma1.setForeground(new java.awt.Color(255, 255, 255));
        LKoma1.setText(",-");
        LKoma1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        label2.setForeground(new java.awt.Color(255, 255, 255));
        label2.setText("Rp.");
        label2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        i_total.setEditable(false);
        i_total.setBackground(new java.awt.Color(255, 255, 255));
        i_total.setForeground(new java.awt.Color(0, 0, 0));
        i_total.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        i_total.setText("0");
        i_total.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        i_total.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                i_totalKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout panelGlass2Layout = new javax.swing.GroupLayout(panelGlass2);
        panelGlass2.setLayout(panelGlass2Layout);
        panelGlass2Layout.setHorizontalGroup(
            panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass2Layout.createSequentialGroup()
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(i_total, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LKoma1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        panelGlass2Layout.setVerticalGroup(
            panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LKoma1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelGlass10.setBackgroundImageType(usu.widget.constan.BackgroundConstan.BACKGROUND_IMAGE_CENTER_TOP);
        panelGlass10.setOpaqueGradient(true);
        panelGlass10.setOpaqueImage(false);
        panelGlass10.setRound(false);
        panelGlass10.setWarna(new java.awt.Color(0, 204, 0));

        LKoma3.setForeground(new java.awt.Color(255, 255, 255));
        LKoma3.setText(",-");
        LKoma3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        label7.setForeground(new java.awt.Color(255, 255, 255));
        label7.setText("Rp.");
        label7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        i_kembalian.setEditable(false);
        i_kembalian.setBackground(new java.awt.Color(255, 255, 255));
        i_kembalian.setForeground(java.awt.Color.red);
        i_kembalian.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        i_kembalian.setText("0");
        i_kembalian.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        javax.swing.GroupLayout panelGlass10Layout = new javax.swing.GroupLayout(panelGlass10);
        panelGlass10.setLayout(panelGlass10Layout);
        panelGlass10Layout.setHorizontalGroup(
            panelGlass10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(i_kembalian, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LKoma3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        panelGlass10Layout.setVerticalGroup(
            panelGlass10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelGlass10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LKoma3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelGlass10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(i_kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(label7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Kembalian");

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Dibayar");

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Total");

        t_simpan.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        t_simpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan.setText("Simpan");
        t_simpan.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                t_simpanMouseMoved(evt);
            }
        });
        t_simpan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                t_simpanMouseExited(evt);
            }
        });
        t_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpanActionPerformed(evt);
            }
        });

        t_batal.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        t_batal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal.setText("Batal");
        t_batal.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                t_batalMouseMoved(evt);
            }
        });
        t_batal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                t_batalMouseExited(evt);
            }
        });
        t_batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batalActionPerformed(evt);
            }
        });

        i_sub.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        i_sub.setText("0");

        jLabel3.setText("SubTotal");

        javax.swing.GroupLayout panelGlass6Layout = new javax.swing.GroupLayout(panelGlass6);
        panelGlass6.setLayout(panelGlass6Layout);
        panelGlass6Layout.setHorizontalGroup(
            panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass6Layout.createSequentialGroup()
                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelGlass6Layout.createSequentialGroup()
                        .addGap(213, 213, 213)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelGlass6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(i_sub, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelGlass6Layout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelGlass10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelGlass8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelGlass6Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelGlass2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(44, 44, 44)
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(t_simpan)
                            .addComponent(t_batal, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        panelGlass6Layout.setVerticalGroup(
            panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(panelGlass6Layout.createSequentialGroup()
                            .addComponent(t_simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(t_batal, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(panelGlass6Layout.createSequentialGroup()
                            .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(panelGlass2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(panelGlass8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(panelGlass10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(i_sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 1128, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(i_idbook, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelGlass6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(i_idbook, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                        .addComponent(jLabel6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelGlass6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(74, 74, 74))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        getdatabooking0();
        int baris = tbl_item1.getRowCount();
        for (int i = 0; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            model.removeRow(0);
        }
        i_total.setText("0");
        i_bayar.setText("0");
        i_kembalian.setText("0");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tbl_0MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_0MouseClicked
        idbayar();
        GetData_main();
        getdatasewa();
        total();
    }//GEN-LAST:event_tbl_0MouseClicked

    private void tbl_item1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_item1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_item1MouseClicked

    private void i_bayarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_i_bayarFocusGained
        i_bayar.setText("");
    }//GEN-LAST:event_i_bayarFocusGained

    private void i_bayarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_i_bayarFocusLost

    }//GEN-LAST:event_i_bayarFocusLost

    private void i_bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_bayarActionPerformed
        int k, b = (Integer.parseInt(i_bayar.getText())), t = (Integer.parseInt(i_total.getText()));
        k = b - t;
        if (k < 0) {
            i_kembalian.setForeground(Color.red);
            i_kembalian.setText(Integer.toString(k));
        } else {
            i_kembalian.setForeground(Color.black);
            i_kembalian.setText(Integer.toString(k));
        }
    }//GEN-LAST:event_i_bayarActionPerformed

    private void i_bayarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_bayarKeyReleased

    }//GEN-LAST:event_i_bayarKeyReleased

    private void i_totalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i_totalKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_i_totalKeyReleased

    private void t_simpanMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t_simpanMouseMoved
        t_simpan.setBackground(Color.CYAN);
    }//GEN-LAST:event_t_simpanMouseMoved

    private void t_simpanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t_simpanMouseExited
        t_simpan.setBackground(new java.awt.Color(188, 188, 188));
    }//GEN-LAST:event_t_simpanMouseExited

    private void t_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpanActionPerformed
        int t = Integer.parseInt(i_total.getText());
        String idb;
        int k = Integer.parseInt(i_kembalian.getText());

        if (t == 0) {
            JOptionPane.showMessageDialog(null, "Data Tidak Ada", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            i_bayar.setText("0");
            i_kembalian.setText("0");
            i_kembalian.setForeground(Color.red);
        } else {
            int row = tbl_0.getSelectedRow();
            idb = (tbl_0.getModel().getValueAt(row, 0).toString());
            if (k < 0) {
                JOptionPane.showMessageDialog(null, "Jumlah Uang Yang Dibayar Kurang", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
                i_bayar.setText("0");
                i_kembalian.setText("0");
                i_kembalian.setForeground(Color.red);
            } else if (i_bayar.getText().equals("0")) {
                JOptionPane.showMessageDialog(null, "Transakasi Belum Dibayar", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
                i_bayar.setText("0");
                i_kembalian.setText("0");
                i_kembalian.setForeground(Color.red);
            } else {
                String sw = "-", tgl = Integer.toString(tahun) + "-" + Integer.toString(bulan) + "-" + Integer.toString(hari);
                try {

                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    ResultSet res = stat.executeQuery("select * from sewa where id_booking='" + idb + "'");
                    while (res.next()) {
                        sw = res.getString("id_sewa");
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(rootPane, e.getMessage());
                }
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='Lunas' where id_booking='" + i_idbook.getText() + "'");
                    stat.executeUpdate("insert into pembayaran values('" + idbyr + "','" + idb + "','" + sw + "','" + tgl + "','" + t + "')");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }

                i_total.setText("0");
                i_bayar.setText("0");
                i_kembalian.setText("0");
                tbl_0.clearSelection();
                i_idbook.setText("");
                i_kembalian.setForeground(Color.red);
                int baris = tbl_item1.getRowCount();
                for (int i = 1; i <= baris; i++) {
                    DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
                    model.removeRow(0);
                }
            }
        }
        getdatabooking0();
    }//GEN-LAST:event_t_simpanActionPerformed

    private void t_batalMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t_batalMouseMoved
        t_batal.setBackground(Color.CYAN);
    }//GEN-LAST:event_t_batalMouseMoved

    private void t_batalMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t_batalMouseExited
        t_batal.setBackground(new java.awt.Color(188, 188, 188));
    }//GEN-LAST:event_t_batalMouseExited

    private void t_batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batalActionPerformed
        i_total.setText("0");
        i_bayar.setText("0");
        i_kembalian.setText("0");
        tbl_0.clearSelection();
        i_idbook.setText("");
        i_kembalian.setForeground(Color.red);
        int baris = tbl_item1.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            model.removeRow(0);
        }
    }//GEN-LAST:event_t_batalActionPerformed

    private void i_idbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_idbookActionPerformed
        getdatabooking();
        int baris = tbl_item1.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            model.removeRow(0);
        }
        i_sub.setText("0");
        i_total.setText("0");
        i_kembalian.setText("0");
        i_bayar.setText("0");
    }//GEN-LAST:event_i_idbookActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private usu.widget.Label LKoma1;
    private usu.widget.Label LKoma2;
    private usu.widget.Label LKoma3;
    private usu.widget.TextBox i_bayar;
    private javax.swing.JTextField i_idbook;
    private usu.widget.TextBox i_kembalian;
    private javax.swing.JTextField i_sub;
    private usu.widget.TextBox i_total;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane8;
    private usu.widget.Label label2;
    private usu.widget.Label label5;
    private usu.widget.Label label7;
    private usu.widget.glass.PanelGlass panelGlass10;
    private usu.widget.glass.PanelGlass panelGlass2;
    private usu.widget.glass.PanelGlass panelGlass6;
    private usu.widget.glass.PanelGlass panelGlass8;
    private javax.swing.JButton t_batal;
    private javax.swing.JButton t_simpan;
    private javax.swing.JTable tbl_0;
    private javax.swing.JTable tbl_item1;
    // End of variables declaration//GEN-END:variables
}
