/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import galtox.Time.TimeScan;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class f_futsal extends javax.swing.JFrame {

    /**
     * Creates new form main
     */
    private int s = 0, m = 0, h = 0;

    public f_futsal() {
        initComponents();
        home();
        initMulai1();
        initMulai2();
        initMulai3();
        initMulai4();
        initMulai5();
        initMulai6();
        initMulai7();
        initMulai8();
        initMulai9();
        namalapangan();
        getdatabooking1();
        getdatabooking2();
        getdatabooking3();
        getdatabooking4();
        getdatabooking5();
        getdatabooking6();
        getdatabooking7();
        getdatabooking8();
        getdatabooking9();
        t_.setEnabled(false);
        tanggal.setForeground(Color.black);
        halaman();
        panel_lp1_2.setVisible(false);
        panel_lp2_2.setVisible(false);
        panel_lp3_2.setVisible(false);
        panel_lp4_2.setVisible(false);
        panel_lp5_2.setVisible(false);
        panel_lp6_2.setVisible(false);
        panel_lp7_2.setVisible(false);
        panel_lp8_2.setVisible(false);
        panel_lp9_2.setVisible(false);
        panelTransparan11.setVisible(true);
        panelTransparan12.setVisible(false);
        panelTransparan13.setVisible(false);
        new Thread() {
            public void run() {
                while (true) {
                    Calendar kal = new GregorianCalendar();
                    int tahun = kal.get(Calendar.YEAR);
                    int bulan = kal.get(Calendar.MONTH) + 1;
                    int hari = kal.get(Calendar.DAY_OF_MONTH);
                    int jam = kal.get(Calendar.HOUR_OF_DAY);
                    int menit = kal.get(Calendar.MINUTE);
                    int detik = kal.get(Calendar.SECOND);
                    String tgl = hari + "-" + bulan + "-" + tahun + "   " + jam + ":" + menit + ":" + detik;
                    tanggal.setText(tgl);
                }
            }
        }.start();

        btnhome.setHorizontalTextPosition(SwingConstants.CENTER);
        btnhome.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnsewa.setHorizontalTextPosition(SwingConstants.CENTER);
        btnsewa.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnkonfirm.setHorizontalTextPosition(SwingConstants.CENTER);
        btnkonfirm.setVerticalTextPosition(SwingConstants.BOTTOM);
        btntransaksi.setHorizontalTextPosition(SwingConstants.CENTER);
        btntransaksi.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnkeluar.setHorizontalTextPosition(SwingConstants.CENTER);
        btnkeluar.setVerticalTextPosition(SwingConstants.BOTTOM);
    }

    private void home() {
        namalapangan();
        getdatabooking1();
        getdatabooking2();
        getdatabooking3();
        getdatabooking4();
        getdatabooking5();
        getdatabooking6();
        getdatabooking7();
        getdatabooking8();
        getdatabooking9();
        t_.setEnabled(false);
        halaman();
    }

    private Timer timer1, timer2, timer3, timer4, timer5, timer6, timer7, timer8, timer9;
    private int seconds1 = 0, minutes1 = 0, hours1 = 0,
            seconds2 = 0, minutes2 = 0, hours2 = 0,
            seconds3 = 0, minutes3 = 0, hours3 = 0,
            seconds4 = 0, minutes4 = 0, hours4 = 0,
            seconds5 = 0, minutes5 = 0, hours5 = 0,
            seconds6 = 0, minutes6 = 0, hours6 = 0,
            seconds7 = 0, minutes7 = 0, hours7 = 0,
            seconds8 = 0, minutes8 = 0, hours8 = 0,
            seconds9 = 0, minutes9 = 0, hours9 = 0;
    private int interval1 = 1000, interval2 = 1000, interval3 = 1000, interval4 = 1000, interval5 = 1000, interval6 = 1000,
            interval7 = 1000, interval8 = 1000, interval9 = 1000;

    private void initMulai1() {
        timer1 = new Timer(interval1, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds1 == 0 && (minutes1 > 0 || hours1 > 0)) {
                    seconds1 = 59;
                    minutes1--;
                } else {
                    seconds1--;
                }
                if (minutes1 == 0 && hours1 > 0) {
                    minutes1 = 59;
                    hours1--;
                }
                if (seconds1 == 0 && minutes1 == 0 && hours1 == 0) {
                    timer1.stop();
                    seconds1 = minutes1 = hours1 = 0;
                    stp_1.setText("Selesai !");
                    initSelesai1();
                    hapustbl1();
                    getdatabooking1();
                }
                TimeScan ts = new TimeScan(seconds1, minutes1, hours1);
                if (minutes1 >= 0 && hours1 > 0 && seconds1 >= 0) {
                    stp_1.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes1 > 0 && seconds1 >= 0 && hours1 <= 0) {
                    stp_1.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes1 == 0 && hours1 == 0 && seconds1 > 0) {
                    if (seconds1 > 10) {
                        stp_1.setText(ts.getSeconds());
                    } else {
                        stp_1.setText(String.valueOf(seconds1));
                        stp_1.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai2() {
        timer2 = new Timer(interval2, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds2 == 0 && (minutes2 > 0 || hours2 > 0)) {
                    seconds2 = 59;
                    minutes2--;
                } else {
                    seconds2--;
                }
                if (minutes2 == 0 && hours2 > 0) {
                    minutes2 = 59;
                    hours2--;
                }
                if (seconds2 == 0 && minutes2 == 0 && hours2 == 0) {
                    timer2.stop();
                    seconds2 = minutes2 = hours2 = 0;
                    stp_2.setText("Selesai !");
                    initSelesai2();
                    hapustbl2();
                    getdatabooking2();
                }
                TimeScan ts = new TimeScan(seconds2, minutes2, hours2);
                if (minutes2 >= 0 && hours2 > 0 && seconds2 >= 0) {
                    stp_2.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes2 > 0 && seconds2 >= 0 && hours2 <= 0) {
                    stp_2.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes2 == 0 && hours2 == 0 && seconds2 > 0) {
                    if (seconds2 > 10) {
                        stp_2.setText(ts.getSeconds());
                    } else {
                        stp_2.setText(String.valueOf(seconds2));
                        stp_2.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai3() {
        timer3 = new Timer(interval3, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds3 == 0 && (minutes3 > 0 || hours3 > 0)) {
                    seconds3 = 59;
                    minutes3--;
                } else {
                    seconds3--;
                }
                if (minutes3 == 0 && hours3 > 0) {
                    minutes3 = 59;
                    hours3--;
                }
                if (seconds3 == 0 && minutes3 == 0 && hours3 == 0) {
                    timer3.stop();
                    seconds3 = minutes3 = hours3 = 0;
                    stp_3.setText("Selesai !");
                    initSelesai3();
                    hapustbl3();
                    getdatabooking3();
                }
                TimeScan ts = new TimeScan(seconds3, minutes3, hours3);
                if (minutes3 >= 0 && hours3 > 0 && seconds3 >= 0) {
                    stp_3.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes3 > 0 && seconds3 >= 0 && hours3 <= 0) {
                    stp_3.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes3 == 0 && hours3 == 0 && seconds3 > 0) {
                    if (seconds3 > 10) {
                        stp_3.setText(ts.getSeconds());
                    } else {
                        stp_3.setText(String.valueOf(seconds3));
                        stp_3.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai4() {
        timer4 = new Timer(interval4, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds4 == 0 && (minutes4 > 0 || hours4 > 0)) {
                    seconds4 = 59;
                    minutes4--;
                } else {
                    seconds4--;
                }
                if (minutes4 == 0 && hours4 > 0) {
                    minutes4 = 59;
                    hours4--;
                }
                if (seconds4 == 0 && minutes4 == 0 && hours4 == 0) {
                    timer4.stop();
                    seconds4 = minutes4 = hours4 = 0;
                    stp_4.setText("Selesai !");
                    initSelesai4();
                    hapustbl4();
                    getdatabooking4();
                }
                TimeScan ts = new TimeScan(seconds4, minutes4, hours4);
                if (minutes4 >= 0 && hours4 > 0 && seconds4 >= 0) {
                    stp_4.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes4 > 0 && seconds4 >= 0 && hours4 <= 0) {
                    stp_4.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes4 == 0 && hours4 == 0 && seconds4 > 0) {
                    if (seconds4 > 10) {
                        stp_4.setText(ts.getSeconds());
                    } else {
                        stp_4.setText(String.valueOf(seconds4));
                        stp_4.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai5() {
        timer5 = new Timer(interval5, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds5 == 0 && (minutes5 > 0 || hours5 > 0)) {
                    seconds5 = 59;
                    minutes5--;
                } else {
                    seconds5--;
                }
                if (minutes5 == 0 && hours5 > 0) {
                    minutes5 = 59;
                    hours5--;
                }
                if (seconds5 == 0 && minutes5 == 0 && hours5 == 0) {
                    timer5.stop();
                    seconds5 = minutes5 = hours5 = 0;
                    stp_5.setText("Selesai !");
                    initSelesai5();
                    hapustbl5();
                    getdatabooking5();
                }
                TimeScan ts = new TimeScan(seconds5, minutes5, hours5);
                if (minutes5 >= 0 && hours5 > 0 && seconds5 >= 0) {
                    stp_5.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes5 > 0 && seconds5 >= 0 && hours5 <= 0) {
                    stp_5.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes5 == 0 && hours5 == 0 && seconds5 > 0) {
                    if (seconds5 > 10) {
                        stp_5.setText(ts.getSeconds());
                    } else {
                        stp_5.setText(String.valueOf(seconds5));
                        stp_5.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai6() {
        timer6 = new Timer(interval6, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds6 == 0 && (minutes6 > 0 || hours6 > 0)) {
                    seconds6 = 59;
                    minutes6--;
                } else {
                    seconds6--;
                }
                if (minutes6 == 0 && hours6 > 0) {
                    minutes6 = 59;
                    hours6--;
                }
                if (seconds6 == 0 && minutes6 == 0 && hours6 == 0) {
                    timer6.stop();
                    seconds6 = minutes6 = hours6 = 0;
                    stp_6.setText("Selesai !");
                    initSelesai6();
                    hapustbl6();
                    getdatabooking6();
                }
                TimeScan ts = new TimeScan(seconds6, minutes6, hours6);
                if (minutes6 >= 0 && hours6 > 0 && seconds6 >= 0) {
                    stp_6.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes6 > 0 && seconds6 >= 0 && hours6 <= 0) {
                    stp_6.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes6 == 0 && hours6 == 0 && seconds6 > 0) {
                    if (seconds6 > 10) {
                        stp_6.setText(ts.getSeconds());
                    } else {
                        stp_6.setText(String.valueOf(seconds6));
                        stp_6.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai7() {
        timer7 = new Timer(interval7, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds7 == 0 && (minutes7 > 0 || hours7 > 0)) {
                    seconds7 = 59;
                    minutes7--;
                } else {
                    seconds7--;
                }
                if (minutes7 == 0 && hours7 > 0) {
                    minutes7 = 59;
                    hours7--;
                }
                if (seconds7 == 0 && minutes7 == 0 && hours7 == 0) {
                    timer7.stop();
                    seconds7 = minutes7 = hours7 = 0;
                    stp_7.setText("Selesai !");
                    initSelesai7();
                    hapustbl7();
                    getdatabooking7();
                }
                TimeScan ts = new TimeScan(seconds7, minutes7, hours7);
                if (minutes7 >= 0 && hours7 > 0 && seconds7 >= 0) {
                    stp_7.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes7 > 0 && seconds7 >= 0 && hours7 <= 0) {
                    stp_7.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes7 == 0 && hours7 == 0 && seconds7 > 0) {
                    if (seconds7 > 10) {
                        stp_7.setText(ts.getSeconds());
                    } else {
                        stp_7.setText(String.valueOf(seconds7));
                        stp_7.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai8() {
        timer8 = new Timer(interval8, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds8 == 0 && (minutes8 > 0 || hours8 > 0)) {
                    seconds8 = 59;
                    minutes8--;
                } else {
                    seconds8--;
                }
                if (minutes8 == 0 && hours8 > 0) {
                    minutes8 = 59;
                    hours8--;
                }
                if (seconds8 == 0 && minutes8 == 0 && hours8 == 0) {
                    timer8.stop();
                    seconds8 = minutes8 = hours8 = 0;
                    stp_8.setText("Selesai !");
                    initSelesai8();
                    hapustbl8();
                    getdatabooking8();
                }
                TimeScan ts = new TimeScan(seconds8, minutes8, hours8);
                if (minutes8 >= 0 && hours8 > 0 && seconds8 >= 0) {
                    stp_8.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes8 > 0 && seconds8 >= 0 && hours8 <= 0) {
                    stp_8.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes8 == 0 && hours8 == 0 && seconds8 > 0) {
                    if (seconds8 > 10) {
                        stp_8.setText(ts.getSeconds());
                    } else {
                        stp_8.setText(String.valueOf(seconds8));
                        stp_8.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initMulai9() {
        timer9 = new Timer(interval9, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (seconds9 == 0 && (minutes9 > 0 || hours9 > 0)) {
                    seconds9 = 59;
                    minutes9--;
                } else {
                    seconds9--;
                }
                if (minutes9 == 0 && hours9 > 0) {
                    minutes9 = 59;
                    hours9--;
                }
                if (seconds9 == 0 && minutes9 == 0 && hours9 == 0) {
                    timer9.stop();
                    seconds9 = minutes9 = hours9 = 0;
                    stp_9.setText("Selesai !");
                    initSelesai9();
                    hapustbl9();
                    getdatabooking9();
                }
                TimeScan ts = new TimeScan(seconds9, minutes9, hours9);
                if (minutes9 >= 0 && hours9 > 0 && seconds9 >= 0) {
                    stp_9.setText(ts.getHours() + ":" + ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes9 > 0 && seconds9 >= 0 && hours9 <= 0) {
                    stp_9.setText(ts.getMinutes() + ":" + ts.getSeconds());
                } else if (minutes9 == 0 && hours9 == 0 && seconds9 > 0) {
                    if (seconds9 > 10) {
                        stp_9.setText(ts.getSeconds());
                    } else {
                        stp_9.setText(String.valueOf(seconds9));
                        stp_9.setForeground(Color.red);
                    }
                }
            }
        });
    }

    private void initSelesai1() {
        String idb = l_id_1.getText(), t = stp_1.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok1.setEnabled(true);
            }
        }
    }

    private void initSelesai2() {
        String idb = l_id_2.getText(), t = stp_2.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok2.setEnabled(true);
            }
        }
    }

    private void initSelesai3() {
        String idb = l_id_3.getText(), t = stp_3.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok3.setEnabled(true);
            }
        }
    }

    private void initSelesai4() {
        String idb = l_id_4.getText(), t = stp_4.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok4.setEnabled(true);
            }
        }
    }

    private void initSelesai5() {
        String idb = l_id_5.getText(), t = stp_5.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok5.setEnabled(true);
            }
        }
    }

    private void initSelesai6() {
        String idb = l_id_6.getText(), t = stp_6.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok6.setEnabled(true);
            }
        }
    }

    private void initSelesai7() {
        String idb = l_id_7.getText(), t = stp_7.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok7.setEnabled(true);
            }
        }
    }

    private void initSelesai8() {
        String idb = l_id_8.getText(), t = stp_8.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok8.setEnabled(true);
            }
        }
    }

    private void initSelesai9() {
        String idb = l_id_9.getText(), t = stp_9.getText();
        if (!idb.equals("")) {
            if (t.equals("Selesai !")) {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + idb + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
                t_ok9.setEnabled(true);
            }
        }
    }

    private void hapustbl1() {
        int baris = tbl_1.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_1.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl2() {
        int baris = tbl_2.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_2.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl3() {
        int baris = tbl_3.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_3.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl4() {
        int baris = tbl_4.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_4.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl5() {
        int baris = tbl_5.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_5.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl6() {
        int baris = tbl_6.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_6.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl7() {
        int baris = tbl_7.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_7.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl8() {
        int baris = tbl_8.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_8.getModel();
            model.removeRow(0);
        }
    }

    private void hapustbl9() {
        int baris = tbl_9.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_9.getModel();
            model.removeRow(0);
        }
    }

    private void halaman() {
        int hal = Integer.parseInt(i_hal.getText());
        if (hal == 1) {
            t_.setEnabled(false);
            t_next.setEnabled(true);
            panelTransparan11.setVisible(true);
            panelTransparan12.setVisible(false);
            panelTransparan13.setVisible(false);
        } else if (hal == 2) {
            t_.setEnabled(true);
            t_next.setEnabled(true);
            panelTransparan11.setVisible(false);
            panelTransparan12.setVisible(true);
            panelTransparan13.setVisible(false);
        } else if (hal == 3) {
            t_.setEnabled(true);
            t_next.setEnabled(false);
            panelTransparan11.setVisible(false);
            panelTransparan12.setVisible(false);
            panelTransparan13.setVisible(true);
        }

    }

    private void namalapangan() {
        int i = 1;
        String nm;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan");
            while (res.next()) {
                nm = res.getString("nama_lapangan");
                if (i == 1) {
                    l_lp1.setText(nm);
                } else if (i == 2) {
                    l_lp2.setText(nm);
                } else if (i == 3) {
                    l_lp3.setText(nm);
                } else if (i == 4) {
                    l_lp4.setText(nm);
                } else if (i == 5) {
                    l_lp5.setText(nm);
                } else if (i == 6) {
                    l_lp6.setText(nm);
                } else if (i == 7) {
                    l_lp7.setText(nm);
                } else if (i == 8) {
                    l_lp8.setText(nm);
                } else if (i == 9) {
                    l_lp9.setText(nm);
                }

                i++;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    private void getIndex1() {
        int j = Integer.parseInt(l_durasi_1.getText());
        if (j == 1) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 1;
        } else if (j == 2) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 2;
        } else if (j == 3) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 3;
        } else if (j == 4) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 4;
        } else if (j == 5) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 5;
        } else if (j == 6) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 6;
        } else if (j == 7) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 7;
        } else if (j == 8) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 8;
        } else if (j == 9) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 9;
        } else if (j == 10) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 10;
        } else if (j == 11) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 11;
        } else if (j == 12) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 12;
        } else if (j == 13) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 13;
        } else if (j == 14) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 14;
        } else if (j == 15) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 15;
        } else if (j == 16) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 16;
        } else if (j == 17) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 17;
        } else if (j == 18) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 18;
        } else if (j == 19) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 19;
        } else if (j == 20) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 20;
        } else if (j == 21) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 21;
        } else if (j == 22) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 22;
        } else if (j == 23) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 23;
        } else if (j == 24) {
            seconds1 = 60;
            minutes1 = 0;
            hours1 = 24;
        }

    }

    private void getIndex2() {
        int j = Integer.parseInt(l_durasi_2.getText());
        if (j == 1) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 1;
        } else if (j == 2) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 2;
        } else if (j == 3) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 3;
        } else if (j == 4) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 4;
        } else if (j == 5) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 5;
        } else if (j == 6) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 6;
        } else if (j == 7) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 7;
        } else if (j == 8) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 8;
        } else if (j == 9) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 9;
        } else if (j == 10) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 10;
        } else if (j == 11) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 11;
        } else if (j == 12) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 12;
        } else if (j == 13) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 13;
        } else if (j == 14) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 14;
        } else if (j == 15) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 15;
        } else if (j == 16) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 16;
        } else if (j == 17) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 17;
        } else if (j == 18) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 18;
        } else if (j == 19) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 19;
        } else if (j == 20) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 20;
        } else if (j == 21) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 21;
        } else if (j == 22) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 22;
        } else if (j == 23) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 23;
        } else if (j == 24) {
            seconds2 = 60;
            minutes2 = 0;
            hours2 = 24;
        }
    }

    private void getIndex3() {
        int j = Integer.parseInt(l_durasi_3.getText());
        if (j == 1) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 1;
        } else if (j == 2) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 2;
        } else if (j == 3) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 3;
        } else if (j == 4) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 4;
        } else if (j == 5) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 5;
        } else if (j == 6) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 6;
        } else if (j == 7) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 7;
        } else if (j == 8) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 8;
        } else if (j == 9) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 9;
        } else if (j == 10) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 10;
        } else if (j == 11) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 11;
        } else if (j == 12) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 12;
        } else if (j == 13) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 13;
        } else if (j == 14) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 14;
        } else if (j == 15) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 15;
        } else if (j == 16) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 16;
        } else if (j == 17) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 17;
        } else if (j == 18) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 18;
        } else if (j == 19) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 19;
        } else if (j == 20) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 20;
        } else if (j == 21) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 21;
        } else if (j == 22) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 22;
        } else if (j == 23) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 23;
        } else if (j == 24) {
            seconds3 = 60;
            minutes3 = 0;
            hours3 = 24;
        }
    }

    private void getIndex4() {
        int j = Integer.parseInt(l_durasi_4.getText());
        if (j == 1) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 1;
        } else if (j == 2) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 2;
        } else if (j == 3) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 3;
        } else if (j == 4) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 4;
        } else if (j == 5) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 5;
        } else if (j == 6) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 6;
        } else if (j == 7) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 7;
        } else if (j == 8) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 8;
        } else if (j == 9) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 9;
        } else if (j == 10) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 10;
        } else if (j == 11) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 11;
        } else if (j == 12) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 12;
        } else if (j == 13) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 13;
        } else if (j == 14) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 14;
        } else if (j == 15) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 15;
        } else if (j == 16) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 16;
        } else if (j == 17) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 17;
        } else if (j == 18) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 18;
        } else if (j == 19) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 19;
        } else if (j == 20) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 20;
        } else if (j == 21) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 21;
        } else if (j == 22) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 22;
        } else if (j == 23) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 23;
        } else if (j == 24) {
            seconds4 = 60;
            minutes4 = 0;
            hours4 = 24;
        }
    }

    private void getIndex5() {
        int j = Integer.parseInt(l_durasi_5.getText());
        if (j == 1) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 1;
        } else if (j == 2) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 2;
        } else if (j == 3) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 3;
        } else if (j == 4) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 4;
        } else if (j == 5) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 5;
        } else if (j == 6) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 6;
        } else if (j == 7) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 7;
        } else if (j == 8) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 8;
        } else if (j == 9) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 9;
        } else if (j == 10) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 10;
        } else if (j == 11) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 11;
        } else if (j == 12) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 12;
        } else if (j == 13) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 13;
        } else if (j == 14) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 14;
        } else if (j == 15) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 15;
        } else if (j == 16) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 16;
        } else if (j == 17) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 17;
        } else if (j == 18) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 18;
        } else if (j == 19) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 19;
        } else if (j == 20) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 20;
        } else if (j == 21) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 21;
        } else if (j == 22) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 22;
        } else if (j == 23) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 23;
        } else if (j == 24) {
            seconds5 = 60;
            minutes5 = 0;
            hours5 = 24;
        }
    }

    private void getIndex6() {
        int j = Integer.parseInt(l_durasi_6.getText());
        if (j == 1) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 1;
        } else if (j == 2) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 2;
        } else if (j == 3) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 3;
        } else if (j == 4) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 4;
        } else if (j == 5) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 5;
        } else if (j == 6) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 6;
        } else if (j == 7) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 7;
        } else if (j == 8) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 8;
        } else if (j == 9) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 9;
        } else if (j == 10) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 10;
        } else if (j == 11) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 11;
        } else if (j == 12) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 12;
        } else if (j == 13) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 13;
        } else if (j == 14) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 14;
        } else if (j == 15) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 15;
        } else if (j == 16) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 16;
        } else if (j == 17) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 17;
        } else if (j == 18) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 18;
        } else if (j == 19) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 19;
        } else if (j == 20) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 20;
        } else if (j == 21) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 21;
        } else if (j == 22) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 22;
        } else if (j == 23) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 23;
        } else if (j == 24) {
            seconds6 = 60;
            minutes6 = 0;
            hours6 = 24;
        }
    }

    private void getIndex7() {
        int j = Integer.parseInt(l_durasi_7.getText());
        if (j == 1) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 1;
        } else if (j == 2) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 2;
        } else if (j == 3) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 3;
        } else if (j == 4) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 4;
        } else if (j == 5) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 5;
        } else if (j == 6) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 6;
        } else if (j == 7) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 7;
        } else if (j == 8) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 8;
        } else if (j == 9) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 9;
        } else if (j == 10) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 10;
        } else if (j == 11) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 11;
        } else if (j == 12) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 12;
        } else if (j == 13) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 13;
        } else if (j == 14) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 14;
        } else if (j == 15) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 15;
        } else if (j == 16) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 16;
        } else if (j == 17) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 17;
        } else if (j == 18) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 18;
        } else if (j == 19) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 19;
        } else if (j == 20) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 20;
        } else if (j == 21) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 21;
        } else if (j == 22) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 22;
        } else if (j == 23) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 23;
        } else if (j == 24) {
            seconds7 = 60;
            minutes7 = 0;
            hours7 = 24;
        }
    }

    private void getIndex8() {
        int j = Integer.parseInt(l_durasi_8.getText());
        if (j == 1) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 1;
        } else if (j == 2) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 2;
        } else if (j == 3) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 3;
        } else if (j == 4) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 4;
        } else if (j == 5) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 5;
        } else if (j == 6) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 6;
        } else if (j == 7) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 7;
        } else if (j == 8) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 8;
        } else if (j == 9) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 9;
        } else if (j == 10) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 10;
        } else if (j == 11) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 11;
        } else if (j == 12) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 12;
        } else if (j == 13) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 13;
        } else if (j == 14) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 14;
        } else if (j == 15) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 15;
        } else if (j == 16) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 16;
        } else if (j == 17) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 17;
        } else if (j == 18) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 18;
        } else if (j == 19) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 19;
        } else if (j == 20) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 20;
        } else if (j == 21) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 21;
        } else if (j == 22) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 22;
        } else if (j == 23) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 23;
        } else if (j == 24) {
            seconds8 = 60;
            minutes8 = 0;
            hours8 = 24;
        }
    }

    private void getIndex9() {
        int j = Integer.parseInt(l_durasi_9.getText());
        if (j == 1) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 1;
        } else if (j == 2) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 2;
        } else if (j == 3) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 3;
        } else if (j == 4) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 4;
        } else if (j == 5) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 5;
        } else if (j == 6) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 6;
        } else if (j == 7) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 7;
        } else if (j == 8) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 8;
        } else if (j == 9) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 9;
        } else if (j == 10) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 10;
        } else if (j == 11) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 11;
        } else if (j == 12) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 12;
        } else if (j == 13) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 13;
        } else if (j == 14) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 14;
        } else if (j == 15) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 15;
        } else if (j == 16) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 16;
        } else if (j == 17) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 17;
        } else if (j == 18) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 18;
        } else if (j == 19) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 19;
        } else if (j == 20) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 20;
        } else if (j == 21) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 21;
        } else if (j == 22) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 22;
        } else if (j == 23) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 23;
        } else if (j == 24) {
            seconds9 = 60;
            minutes9 = 0;
            hours9 = 24;
        }
    }

    public void getdatabooking1() {
        DefaultTableModel model1 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model1.addColumn("Id Booking");
        model1.addColumn("Jam");
        model1.addColumn("Nama");

        tbl_1.setModel(model1);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L01'");
            while (res.next()) {

                model1.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_1.setModel(model1);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatabooking2() {
        DefaultTableModel model2 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model2.addColumn("Id Booking");
        model2.addColumn("Jam");
        model2.addColumn("Nama");

        tbl_2.setModel(model2);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L02'");
            while (res.next()) {

                model2.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_2.setModel(model2);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking3() {
        DefaultTableModel model3 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model3.addColumn("Id Booking");
        model3.addColumn("Jam");
        model3.addColumn("Nama");

        tbl_3.setModel(model3);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L03'");
            while (res.next()) {

                model3.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_3.setModel(model3);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking4() {
        DefaultTableModel model4 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model4.addColumn("Id Booking");
        model4.addColumn("Jam");
        model4.addColumn("Nama");

        tbl_4.setModel(model4);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L04'");
            while (res.next()) {

                model4.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_4.setModel(model4);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking5() {
        DefaultTableModel model5 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model5.addColumn("Id Booking");
        model5.addColumn("Jam");
        model5.addColumn("Nama");

        tbl_5.setModel(model5);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L05'");
            while (res.next()) {

                model5.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_5.setModel(model5);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking6() {
        DefaultTableModel model6 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model6.addColumn("Id Booking");
        model6.addColumn("Jam");
        model6.addColumn("Nama");

        tbl_6.setModel(model6);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L06'");
            while (res.next()) {

                model6.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_6.setModel(model6);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking7() {
        DefaultTableModel model7 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model7.addColumn("Id Booking");
        model7.addColumn("Jam");
        model7.addColumn("Nama");

        tbl_7.setModel(model7);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L07'");
            while (res.next()) {

                model7.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_7.setModel(model7);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking8() {
        DefaultTableModel model8 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model8.addColumn("Id Booking");
        model8.addColumn("Jam");
        model8.addColumn("Nama");

        tbl_8.setModel(model8);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L08'");
            while (res.next()) {

                model8.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_8.setModel(model8);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabooking9() {
        DefaultTableModel model9 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model9.addColumn("Id Booking");
        model9.addColumn("Jam");
        model9.addColumn("Nama");

        tbl_9.setModel(model9);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where status_main='" + "Main" + "' and id_lapangan='L09'");
            while (res.next()) {

                model9.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("jam"),
                    res.getString("nama"),});
                tbl_9.setModel(model9);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    String row_id1, row_id2, row_id3, row_id4, row_id5, row_id6, row_id7, row_id8, row_id9;

    private void GetData_antri1() {
        int row = tbl_1.getSelectedRow();
        row_id1 = (tbl_1.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri2() {
        int row = tbl_2.getSelectedRow();
        row_id2 = (tbl_2.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri3() {
        int row = tbl_3.getSelectedRow();
        row_id3 = (tbl_3.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri4() {
        int row = tbl_4.getSelectedRow();
        row_id4 = (tbl_4.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri5() {
        int row = tbl_5.getSelectedRow();
        row_id5 = (tbl_5.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri6() {
        int row = tbl_6.getSelectedRow();
        row_id6 = (tbl_6.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri7() {
        int row = tbl_7.getSelectedRow();
        row_id7 = (tbl_7.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri8() {
        int row = tbl_8.getSelectedRow();
        row_id8 = (tbl_8.getModel().getValueAt(row, 0).toString());
    }

    private void GetData_antri9() {
        int row = tbl_9.getSelectedRow();
        row_id9 = (tbl_9.getModel().getValueAt(row, 0).toString());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel_utama = new FV.PanelTransparan1();
        home = new javax.swing.JLabel();
        panelTransparan14 = new FV.PanelTransparan1();
        panelTransparan11 = new FV.PanelTransparan1();
        panel_lp1 = new FV.PanelTransparan();
        jPanel1 = new javax.swing.JPanel();
        l_lp1 = new javax.swing.JLabel();
        panel_lp1_1 = new FV.PanelTransparan1();
        stp_1 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        t_mulai_1 = new javax.swing.JButton();
        t_stop_1 = new javax.swing.JButton();
        t_antrian_1 = new javax.swing.JButton();
        l_durasi_1 = new javax.swing.JLabel();
        l_nama_1 = new javax.swing.JLabel();
        l_id_1 = new javax.swing.JLabel();
        lbgambar4 = new javax.swing.JLabel();
        panel_lp1_2 = new FV.PanelTransparan1();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_1 = new javax.swing.JTable();
        t_ok1 = new javax.swing.JButton();
        t_kembali1 = new javax.swing.JButton();
        panel_lp2 = new FV.PanelTransparan();
        jPanel2 = new javax.swing.JPanel();
        l_lp2 = new javax.swing.JLabel();
        panel_lp2_1 = new FV.PanelTransparan1();
        stp_2 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        t_mulai_2 = new javax.swing.JButton();
        t_stop_2 = new javax.swing.JButton();
        t_antrian_2 = new javax.swing.JButton();
        l_durasi_2 = new javax.swing.JLabel();
        l_nama_2 = new javax.swing.JLabel();
        l_id_2 = new javax.swing.JLabel();
        lbgambar3 = new javax.swing.JLabel();
        panel_lp2_2 = new FV.PanelTransparan1();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_2 = new javax.swing.JTable();
        t_ok2 = new javax.swing.JButton();
        t_kembali2 = new javax.swing.JButton();
        panel_lp3 = new FV.PanelTransparan();
        jPanel3 = new javax.swing.JPanel();
        l_lp3 = new javax.swing.JLabel();
        panel_lp3_1 = new FV.PanelTransparan1();
        stp_3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        t_mulai_3 = new javax.swing.JButton();
        t_stop_3 = new javax.swing.JButton();
        t_antrian_3 = new javax.swing.JButton();
        l_durasi_3 = new javax.swing.JLabel();
        l_nama_3 = new javax.swing.JLabel();
        l_id_3 = new javax.swing.JLabel();
        lbgambar2 = new javax.swing.JLabel();
        panel_lp3_2 = new FV.PanelTransparan1();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_3 = new javax.swing.JTable();
        t_kembali3 = new javax.swing.JButton();
        t_ok3 = new javax.swing.JButton();
        panelTransparan12 = new FV.PanelTransparan1();
        panel_lp4 = new FV.PanelTransparan();
        jPanel4 = new javax.swing.JPanel();
        l_lp4 = new javax.swing.JLabel();
        panel_lp4_1 = new FV.PanelTransparan1();
        stp_4 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        t_mulai_4 = new javax.swing.JButton();
        t_stop_4 = new javax.swing.JButton();
        t_antrian_4 = new javax.swing.JButton();
        l_durasi_4 = new javax.swing.JLabel();
        l_nama_4 = new javax.swing.JLabel();
        l_id_4 = new javax.swing.JLabel();
        lbgambar5 = new javax.swing.JLabel();
        panel_lp4_2 = new FV.PanelTransparan1();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_4 = new javax.swing.JTable();
        t_ok4 = new javax.swing.JButton();
        t_kembali4 = new javax.swing.JButton();
        panel_lp5 = new FV.PanelTransparan();
        jPanel5 = new javax.swing.JPanel();
        l_lp5 = new javax.swing.JLabel();
        panel_lp5_1 = new FV.PanelTransparan1();
        stp_5 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        t_mulai_5 = new javax.swing.JButton();
        t_stop_5 = new javax.swing.JButton();
        t_antrian_5 = new javax.swing.JButton();
        l_durasi_5 = new javax.swing.JLabel();
        l_nama_5 = new javax.swing.JLabel();
        l_id_5 = new javax.swing.JLabel();
        lbgambar6 = new javax.swing.JLabel();
        panel_lp5_2 = new FV.PanelTransparan1();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbl_5 = new javax.swing.JTable();
        t_ok5 = new javax.swing.JButton();
        t_kembali5 = new javax.swing.JButton();
        panel_lp6 = new FV.PanelTransparan();
        jPanel6 = new javax.swing.JPanel();
        l_lp6 = new javax.swing.JLabel();
        panel_lp6_1 = new FV.PanelTransparan1();
        stp_6 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        t_mulai_6 = new javax.swing.JButton();
        t_stop_6 = new javax.swing.JButton();
        t_antrian_6 = new javax.swing.JButton();
        l_durasi_6 = new javax.swing.JLabel();
        l_nama_6 = new javax.swing.JLabel();
        l_id_6 = new javax.swing.JLabel();
        lbgambar7 = new javax.swing.JLabel();
        panel_lp6_2 = new FV.PanelTransparan1();
        jScrollPane6 = new javax.swing.JScrollPane();
        tbl_6 = new javax.swing.JTable();
        t_kembali6 = new javax.swing.JButton();
        t_ok6 = new javax.swing.JButton();
        panelTransparan13 = new FV.PanelTransparan1();
        panel_lp7 = new FV.PanelTransparan();
        jPanel7 = new javax.swing.JPanel();
        l_lp7 = new javax.swing.JLabel();
        panel_lp7_1 = new FV.PanelTransparan1();
        stp_7 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        t_mulai_7 = new javax.swing.JButton();
        t_stop_7 = new javax.swing.JButton();
        t_antrian_7 = new javax.swing.JButton();
        l_durasi_7 = new javax.swing.JLabel();
        l_nama_7 = new javax.swing.JLabel();
        l_id_7 = new javax.swing.JLabel();
        lbgambar8 = new javax.swing.JLabel();
        panel_lp7_2 = new FV.PanelTransparan1();
        jScrollPane7 = new javax.swing.JScrollPane();
        tbl_7 = new javax.swing.JTable();
        t_ok7 = new javax.swing.JButton();
        t_kembali7 = new javax.swing.JButton();
        panel_lp8 = new FV.PanelTransparan();
        jPanel8 = new javax.swing.JPanel();
        l_lp8 = new javax.swing.JLabel();
        panel_lp8_1 = new FV.PanelTransparan1();
        stp_8 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        t_mulai_8 = new javax.swing.JButton();
        t_stop_8 = new javax.swing.JButton();
        t_antrian_8 = new javax.swing.JButton();
        l_durasi_8 = new javax.swing.JLabel();
        l_nama_8 = new javax.swing.JLabel();
        l_id_8 = new javax.swing.JLabel();
        lbgambar9 = new javax.swing.JLabel();
        panel_lp8_2 = new FV.PanelTransparan1();
        jScrollPane8 = new javax.swing.JScrollPane();
        tbl_8 = new javax.swing.JTable();
        t_ok8 = new javax.swing.JButton();
        t_kembali8 = new javax.swing.JButton();
        panel_lp9 = new FV.PanelTransparan();
        jPanel9 = new javax.swing.JPanel();
        l_lp9 = new javax.swing.JLabel();
        panel_lp9_1 = new FV.PanelTransparan1();
        stp_9 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        t_mulai_9 = new javax.swing.JButton();
        t_stop_9 = new javax.swing.JButton();
        t_antrian_9 = new javax.swing.JButton();
        l_durasi_9 = new javax.swing.JLabel();
        l_nama_9 = new javax.swing.JLabel();
        l_id_9 = new javax.swing.JLabel();
        lbgambar10 = new javax.swing.JLabel();
        panel_lp9_2 = new FV.PanelTransparan1();
        jScrollPane9 = new javax.swing.JScrollPane();
        tbl_9 = new javax.swing.JTable();
        t_kembali9 = new javax.swing.JButton();
        t_ok9 = new javax.swing.JButton();
        panelTransparan41 = new FV.PanelTransparan4();
        i_hal = new javax.swing.JLabel();
        t_ = new javax.swing.JButton();
        t_next = new javax.swing.JButton();
        panelTransparan1 = new FV.PanelTransparan();
        btnkonfirm = new javax.swing.JButton();
        btnhome = new javax.swing.JButton();
        btntransaksi = new javax.swing.JButton();
        btnkeluar = new javax.swing.JButton();
        btnsewa = new javax.swing.JButton();
        tanggal = new javax.swing.JLabel();
        tanggal1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplikasi Futsal & Store Fantastic V");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_utama.setToolTipText("");

        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Logo Beranda PNG.png"))); // NOI18N
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        l_lp1.setBackground(new java.awt.Color(0, 51, 51));
        l_lp1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp1.setForeground(new java.awt.Color(255, 255, 255));
        l_lp1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp1.setText("Lapangan 1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_1.setText("00:00:00");

        jLabel23.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel23.setText("Id          :");

        jLabel24.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel24.setText("Nama   :");

        jLabel25.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel25.setText("Durasi  :");

        t_mulai_1.setText("Mulai");
        t_mulai_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_1ActionPerformed(evt);
            }
        });

        t_stop_1.setText("Stop");
        t_stop_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_1ActionPerformed(evt);
            }
        });

        t_antrian_1.setText("Antrian");
        t_antrian_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_1ActionPerformed(evt);
            }
        });

        l_durasi_1.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_1.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_1.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp1_1Layout = new javax.swing.GroupLayout(panel_lp1_1);
        panel_lp1_1.setLayout(panel_lp1_1Layout);
        panel_lp1_1Layout.setHorizontalGroup(
            panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp1_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp1_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp1_1Layout.createSequentialGroup()
                        .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp1_1Layout.createSequentialGroup()
                                .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp1_1Layout.createSequentialGroup()
                    .addComponent(lbgambar4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp1_1Layout.setVerticalGroup(
            panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp1_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp1_1Layout.createSequentialGroup()
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp1_1Layout.createSequentialGroup()
                        .addComponent(l_id_1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_1)
                    .addComponent(t_stop_1)
                    .addComponent(t_antrian_1))
                .addContainerGap())
            .addGroup(panel_lp1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp1_1Layout.createSequentialGroup()
                    .addComponent(lbgambar4, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp1_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                tbl_1MouseMoved(evt);
            }
        });
        tbl_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_1);

        panel_lp1_2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_ok1.setText("OK");
        t_ok1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok1ActionPerformed(evt);
            }
        });
        panel_lp1_2.add(t_ok1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        t_kembali1.setText("Kembali");
        t_kembali1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali1ActionPerformed(evt);
            }
        });
        panel_lp1_2.add(t_kembali1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        javax.swing.GroupLayout panel_lp1Layout = new javax.swing.GroupLayout(panel_lp1);
        panel_lp1.setLayout(panel_lp1Layout);
        panel_lp1Layout.setHorizontalGroup(
            panel_lp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp1Layout.createSequentialGroup()
                    .addComponent(panel_lp1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp1_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp1Layout.setVerticalGroup(
            panel_lp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp1Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(359, Short.MAX_VALUE))
            .addGroup(panel_lp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp1Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp1_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp1Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        l_lp2.setBackground(new java.awt.Color(0, 51, 51));
        l_lp2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp2.setForeground(new java.awt.Color(255, 255, 255));
        l_lp2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp2.setText("Lapangan 2");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_2.setText("00:00:00");

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel18.setText("Id          :");

        jLabel19.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel19.setText("Nama   :");

        jLabel20.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel20.setText("Durasi  :");

        t_mulai_2.setText("Mulai");
        t_mulai_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_2ActionPerformed(evt);
            }
        });

        t_stop_2.setText("Stop");
        t_stop_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_2ActionPerformed(evt);
            }
        });

        t_antrian_2.setText("Antrian");
        t_antrian_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_2ActionPerformed(evt);
            }
        });

        l_durasi_2.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_2.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_2.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp2_1Layout = new javax.swing.GroupLayout(panel_lp2_1);
        panel_lp2_1.setLayout(panel_lp2_1Layout);
        panel_lp2_1Layout.setHorizontalGroup(
            panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp2_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp2_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp2_1Layout.createSequentialGroup()
                        .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp2_1Layout.createSequentialGroup()
                                .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp2_1Layout.createSequentialGroup()
                    .addComponent(lbgambar3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp2_1Layout.setVerticalGroup(
            panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp2_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp2_1Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp2_1Layout.createSequentialGroup()
                        .addComponent(l_id_2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_2)
                    .addComponent(t_stop_2)
                    .addComponent(t_antrian_2))
                .addContainerGap())
            .addGroup(panel_lp2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp2_1Layout.createSequentialGroup()
                    .addComponent(lbgambar3, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp2_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_2);

        panel_lp2_2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_ok2.setText("OK");
        t_ok2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok2ActionPerformed(evt);
            }
        });
        panel_lp2_2.add(t_ok2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        t_kembali2.setText("Kembali");
        t_kembali2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali2ActionPerformed(evt);
            }
        });
        panel_lp2_2.add(t_kembali2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        javax.swing.GroupLayout panel_lp2Layout = new javax.swing.GroupLayout(panel_lp2);
        panel_lp2.setLayout(panel_lp2Layout);
        panel_lp2Layout.setHorizontalGroup(
            panel_lp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp2Layout.createSequentialGroup()
                    .addComponent(panel_lp2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp2_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp2Layout.setVerticalGroup(
            panel_lp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp2Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel_lp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp2Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp2_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp2Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        l_lp3.setBackground(new java.awt.Color(0, 51, 51));
        l_lp3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp3.setForeground(new java.awt.Color(255, 255, 255));
        l_lp3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp3.setText("Lapangan 3");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_3.setText("00:00:00");

        jLabel15.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel15.setText("Id          :");

        jLabel16.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel16.setText("Nama   :");

        jLabel17.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel17.setText("Durasi  :");

        t_mulai_3.setText("Mulai");
        t_mulai_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_3ActionPerformed(evt);
            }
        });

        t_stop_3.setText("Stop");
        t_stop_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_3ActionPerformed(evt);
            }
        });

        t_antrian_3.setText("Antrian");
        t_antrian_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_3ActionPerformed(evt);
            }
        });

        l_durasi_3.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_3.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_3.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp3_1Layout = new javax.swing.GroupLayout(panel_lp3_1);
        panel_lp3_1.setLayout(panel_lp3_1Layout);
        panel_lp3_1Layout.setHorizontalGroup(
            panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp3_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp3_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp3_1Layout.createSequentialGroup()
                        .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp3_1Layout.createSequentialGroup()
                                .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp3_1Layout.createSequentialGroup()
                    .addComponent(lbgambar2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp3_1Layout.setVerticalGroup(
            panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp3_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp3_1Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp3_1Layout.createSequentialGroup()
                        .addComponent(l_id_3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_3)
                    .addComponent(t_stop_3)
                    .addComponent(t_antrian_3))
                .addContainerGap())
            .addGroup(panel_lp3_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp3_1Layout.createSequentialGroup()
                    .addComponent(lbgambar2, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp3_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_3MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_3);

        panel_lp3_2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_kembali3.setText("Kembali");
        t_kembali3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali3ActionPerformed(evt);
            }
        });
        panel_lp3_2.add(t_kembali3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        t_ok3.setText("OK");
        t_ok3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok3ActionPerformed(evt);
            }
        });
        panel_lp3_2.add(t_ok3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        javax.swing.GroupLayout panel_lp3Layout = new javax.swing.GroupLayout(panel_lp3);
        panel_lp3.setLayout(panel_lp3Layout);
        panel_lp3Layout.setHorizontalGroup(
            panel_lp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp3Layout.createSequentialGroup()
                    .addComponent(panel_lp3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp3_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp3Layout.setVerticalGroup(
            panel_lp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp3Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel_lp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp3Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp3_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp3Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout panelTransparan11Layout = new javax.swing.GroupLayout(panelTransparan11);
        panelTransparan11.setLayout(panelTransparan11Layout);
        panelTransparan11Layout.setHorizontalGroup(
            panelTransparan11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panel_lp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panel_lp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(panel_lp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelTransparan11Layout.setVerticalGroup(
            panelTransparan11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTransparan11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panel_lp3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_lp2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_lp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));

        l_lp4.setBackground(new java.awt.Color(0, 51, 51));
        l_lp4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp4.setForeground(new java.awt.Color(255, 255, 255));
        l_lp4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp4.setText("Lapangan 4");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_4.setText("00:00:00");

        jLabel26.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel26.setText("Id          :");

        jLabel27.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel27.setText("Nama   :");

        jLabel28.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel28.setText("Durasi  :");

        t_mulai_4.setText("Mulai");
        t_mulai_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_4ActionPerformed(evt);
            }
        });

        t_stop_4.setText("Stop");
        t_stop_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_4ActionPerformed(evt);
            }
        });

        t_antrian_4.setText("Antrian");
        t_antrian_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_4ActionPerformed(evt);
            }
        });

        l_durasi_4.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_4.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_4.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp4_1Layout = new javax.swing.GroupLayout(panel_lp4_1);
        panel_lp4_1.setLayout(panel_lp4_1Layout);
        panel_lp4_1Layout.setHorizontalGroup(
            panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp4_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp4_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp4_1Layout.createSequentialGroup()
                        .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp4_1Layout.createSequentialGroup()
                                .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp4_1Layout.createSequentialGroup()
                    .addComponent(lbgambar5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp4_1Layout.setVerticalGroup(
            panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp4_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp4_1Layout.createSequentialGroup()
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp4_1Layout.createSequentialGroup()
                        .addComponent(l_id_4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_4)
                    .addComponent(t_stop_4)
                    .addComponent(t_antrian_4))
                .addContainerGap())
            .addGroup(panel_lp4_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp4_1Layout.createSequentialGroup()
                    .addComponent(lbgambar5, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp4_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_4MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_4);

        panel_lp4_2.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_ok4.setText("OK");
        t_ok4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok4ActionPerformed(evt);
            }
        });
        panel_lp4_2.add(t_ok4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        t_kembali4.setText("Kembali");
        t_kembali4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali4ActionPerformed(evt);
            }
        });
        panel_lp4_2.add(t_kembali4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        javax.swing.GroupLayout panel_lp4Layout = new javax.swing.GroupLayout(panel_lp4);
        panel_lp4.setLayout(panel_lp4Layout);
        panel_lp4Layout.setHorizontalGroup(
            panel_lp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp4Layout.createSequentialGroup()
                    .addComponent(panel_lp4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp4_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp4Layout.setVerticalGroup(
            panel_lp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp4Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(359, Short.MAX_VALUE))
            .addGroup(panel_lp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp4Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp4_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp4Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));

        l_lp5.setBackground(new java.awt.Color(0, 51, 51));
        l_lp5.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp5.setForeground(new java.awt.Color(255, 255, 255));
        l_lp5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp5.setText("Lapangan 5");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_5.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_5.setText("00:00:00");

        jLabel21.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel21.setText("Id          :");

        jLabel22.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel22.setText("Nama   :");

        jLabel29.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel29.setText("Durasi  :");

        t_mulai_5.setText("Mulai");
        t_mulai_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_5ActionPerformed(evt);
            }
        });

        t_stop_5.setText("Stop");
        t_stop_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_5ActionPerformed(evt);
            }
        });

        t_antrian_5.setText("Antrian");
        t_antrian_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_5ActionPerformed(evt);
            }
        });

        l_durasi_5.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_5.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_5.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp5_1Layout = new javax.swing.GroupLayout(panel_lp5_1);
        panel_lp5_1.setLayout(panel_lp5_1Layout);
        panel_lp5_1Layout.setHorizontalGroup(
            panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp5_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp5_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp5_1Layout.createSequentialGroup()
                        .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp5_1Layout.createSequentialGroup()
                                .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp5_1Layout.createSequentialGroup()
                    .addComponent(lbgambar6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp5_1Layout.setVerticalGroup(
            panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp5_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp5_1Layout.createSequentialGroup()
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp5_1Layout.createSequentialGroup()
                        .addComponent(l_id_5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_5)
                    .addComponent(t_stop_5)
                    .addComponent(t_antrian_5))
                .addContainerGap())
            .addGroup(panel_lp5_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp5_1Layout.createSequentialGroup()
                    .addComponent(lbgambar6, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp5_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_5MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tbl_5);

        panel_lp5_2.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_ok5.setText("OK");
        t_ok5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok5ActionPerformed(evt);
            }
        });
        panel_lp5_2.add(t_ok5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        t_kembali5.setText("Kembali");
        t_kembali5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali5ActionPerformed(evt);
            }
        });
        panel_lp5_2.add(t_kembali5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        javax.swing.GroupLayout panel_lp5Layout = new javax.swing.GroupLayout(panel_lp5);
        panel_lp5.setLayout(panel_lp5Layout);
        panel_lp5Layout.setHorizontalGroup(
            panel_lp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp5Layout.createSequentialGroup()
                    .addComponent(panel_lp5_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp5_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp5Layout.setVerticalGroup(
            panel_lp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp5Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel_lp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp5Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp5_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp5Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp5_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));

        l_lp6.setBackground(new java.awt.Color(0, 51, 51));
        l_lp6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp6.setForeground(new java.awt.Color(255, 255, 255));
        l_lp6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp6.setText("Lapangan 6");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp6, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_6.setText("00:00:00");

        jLabel30.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel30.setText("Id          :");

        jLabel31.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel31.setText("Nama   :");

        jLabel32.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel32.setText("Durasi  :");

        t_mulai_6.setText("Mulai");
        t_mulai_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_6ActionPerformed(evt);
            }
        });

        t_stop_6.setText("Stop");
        t_stop_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_6ActionPerformed(evt);
            }
        });

        t_antrian_6.setText("Antrian");
        t_antrian_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_6ActionPerformed(evt);
            }
        });

        l_durasi_6.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_6.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_6.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp6_1Layout = new javax.swing.GroupLayout(panel_lp6_1);
        panel_lp6_1.setLayout(panel_lp6_1Layout);
        panel_lp6_1Layout.setHorizontalGroup(
            panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp6_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp6_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_6, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_6, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp6_1Layout.createSequentialGroup()
                        .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp6_1Layout.createSequentialGroup()
                                .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp6_1Layout.createSequentialGroup()
                    .addComponent(lbgambar7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp6_1Layout.setVerticalGroup(
            panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp6_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp6_1Layout.createSequentialGroup()
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp6_1Layout.createSequentialGroup()
                        .addComponent(l_id_6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_6)
                    .addComponent(t_stop_6)
                    .addComponent(t_antrian_6))
                .addContainerGap())
            .addGroup(panel_lp6_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp6_1Layout.createSequentialGroup()
                    .addComponent(lbgambar7, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp6_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_6MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tbl_6);

        panel_lp6_2.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_kembali6.setText("Kembali");
        t_kembali6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali6ActionPerformed(evt);
            }
        });
        panel_lp6_2.add(t_kembali6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        t_ok6.setText("OK");
        t_ok6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok6ActionPerformed(evt);
            }
        });
        panel_lp6_2.add(t_ok6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        javax.swing.GroupLayout panel_lp6Layout = new javax.swing.GroupLayout(panel_lp6);
        panel_lp6.setLayout(panel_lp6Layout);
        panel_lp6Layout.setHorizontalGroup(
            panel_lp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp6Layout.createSequentialGroup()
                    .addComponent(panel_lp6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp6_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp6Layout.setVerticalGroup(
            panel_lp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp6Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel_lp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp6Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp6_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp6Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout panelTransparan12Layout = new javax.swing.GroupLayout(panelTransparan12);
        panelTransparan12.setLayout(panelTransparan12Layout);
        panelTransparan12Layout.setHorizontalGroup(
            panelTransparan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panel_lp4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panel_lp5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(panel_lp6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelTransparan12Layout.setVerticalGroup(
            panelTransparan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTransparan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panel_lp6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_lp5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_lp4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));

        l_lp7.setBackground(new java.awt.Color(0, 51, 51));
        l_lp7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp7.setForeground(new java.awt.Color(255, 255, 255));
        l_lp7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp7.setText("Lapangan 7");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp7, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_7.setText("00:00:00");

        jLabel33.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel33.setText("Id          :");

        jLabel34.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel34.setText("Nama   :");

        jLabel35.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel35.setText("Durasi  :");

        t_mulai_7.setText("Mulai");
        t_mulai_7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_7ActionPerformed(evt);
            }
        });

        t_stop_7.setText("Stop");
        t_stop_7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_7ActionPerformed(evt);
            }
        });

        t_antrian_7.setText("Antrian");
        t_antrian_7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_7ActionPerformed(evt);
            }
        });

        l_durasi_7.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_7.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_7.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp7_1Layout = new javax.swing.GroupLayout(panel_lp7_1);
        panel_lp7_1.setLayout(panel_lp7_1Layout);
        panel_lp7_1Layout.setHorizontalGroup(
            panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp7_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp7_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_7, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_7, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_7, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp7_1Layout.createSequentialGroup()
                        .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp7_1Layout.createSequentialGroup()
                                .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp7_1Layout.createSequentialGroup()
                    .addComponent(lbgambar8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp7_1Layout.setVerticalGroup(
            panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp7_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp7_1Layout.createSequentialGroup()
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp7_1Layout.createSequentialGroup()
                        .addComponent(l_id_7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_7)
                    .addComponent(t_stop_7)
                    .addComponent(t_antrian_7))
                .addContainerGap())
            .addGroup(panel_lp7_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp7_1Layout.createSequentialGroup()
                    .addComponent(lbgambar8, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp7_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_7MouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tbl_7);

        panel_lp7_2.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_ok7.setText("OK");
        t_ok7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok7ActionPerformed(evt);
            }
        });
        panel_lp7_2.add(t_ok7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        t_kembali7.setText("Kembali");
        t_kembali7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali7ActionPerformed(evt);
            }
        });
        panel_lp7_2.add(t_kembali7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        javax.swing.GroupLayout panel_lp7Layout = new javax.swing.GroupLayout(panel_lp7);
        panel_lp7.setLayout(panel_lp7Layout);
        panel_lp7Layout.setHorizontalGroup(
            panel_lp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp7Layout.createSequentialGroup()
                    .addComponent(panel_lp7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp7_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp7Layout.setVerticalGroup(
            panel_lp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp7Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(359, Short.MAX_VALUE))
            .addGroup(panel_lp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp7Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp7_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp7Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp7_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));

        l_lp8.setBackground(new java.awt.Color(0, 51, 51));
        l_lp8.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp8.setForeground(new java.awt.Color(255, 255, 255));
        l_lp8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp8.setText("Lapangan 8");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp8, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_8.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_8.setText("00:00:00");

        jLabel36.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel36.setText("Id          :");

        jLabel37.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel37.setText("Nama   :");

        jLabel38.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel38.setText("Durasi  :");

        t_mulai_8.setText("Mulai");
        t_mulai_8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_8ActionPerformed(evt);
            }
        });

        t_stop_8.setText("Stop");
        t_stop_8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_8ActionPerformed(evt);
            }
        });

        t_antrian_8.setText("Antrian");
        t_antrian_8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_8ActionPerformed(evt);
            }
        });

        l_durasi_8.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_8.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_8.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp8_1Layout = new javax.swing.GroupLayout(panel_lp8_1);
        panel_lp8_1.setLayout(panel_lp8_1Layout);
        panel_lp8_1Layout.setHorizontalGroup(
            panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp8_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp8_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_8, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_8, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp8_1Layout.createSequentialGroup()
                        .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp8_1Layout.createSequentialGroup()
                                .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp8_1Layout.createSequentialGroup()
                    .addComponent(lbgambar9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp8_1Layout.setVerticalGroup(
            panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp8_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp8_1Layout.createSequentialGroup()
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp8_1Layout.createSequentialGroup()
                        .addComponent(l_id_8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_8)
                    .addComponent(t_stop_8)
                    .addComponent(t_antrian_8))
                .addContainerGap())
            .addGroup(panel_lp8_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp8_1Layout.createSequentialGroup()
                    .addComponent(lbgambar9, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp8_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_8MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(tbl_8);

        panel_lp8_2.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_ok8.setText("OK");
        t_ok8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok8ActionPerformed(evt);
            }
        });
        panel_lp8_2.add(t_ok8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        t_kembali8.setText("Kembali");
        t_kembali8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali8ActionPerformed(evt);
            }
        });
        panel_lp8_2.add(t_kembali8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        javax.swing.GroupLayout panel_lp8Layout = new javax.swing.GroupLayout(panel_lp8);
        panel_lp8.setLayout(panel_lp8Layout);
        panel_lp8Layout.setHorizontalGroup(
            panel_lp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp8Layout.createSequentialGroup()
                    .addComponent(panel_lp8_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp8_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp8Layout.setVerticalGroup(
            panel_lp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp8Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel_lp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp8Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp8_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp8Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));

        l_lp9.setBackground(new java.awt.Color(0, 51, 51));
        l_lp9.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        l_lp9.setForeground(new java.awt.Color(255, 255, 255));
        l_lp9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l_lp9.setText("Lapangan 9");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(l_lp9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        stp_9.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stp_9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stp_9.setText("00:00:00");

        jLabel39.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel39.setText("Id          :");

        jLabel40.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel40.setText("Nama   :");

        jLabel41.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel41.setText("Durasi  :");

        t_mulai_9.setText("Mulai");
        t_mulai_9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mulai_9ActionPerformed(evt);
            }
        });

        t_stop_9.setText("Stop");
        t_stop_9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_stop_9ActionPerformed(evt);
            }
        });

        t_antrian_9.setText("Antrian");
        t_antrian_9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_antrian_9ActionPerformed(evt);
            }
        });

        l_durasi_9.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_nama_9.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        l_id_9.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N

        lbgambar10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/rsz_f1.png"))); // NOI18N

        javax.swing.GroupLayout panel_lp9_1Layout = new javax.swing.GroupLayout(panel_lp9_1);
        panel_lp9_1.setLayout(panel_lp9_1Layout);
        panel_lp9_1Layout.setHorizontalGroup(
            panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp9_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_lp9_1Layout.createSequentialGroup()
                        .addComponent(t_mulai_9, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_stop_9, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_antrian_9, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_lp9_1Layout.createSequentialGroup()
                        .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stp_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel_lp9_1Layout.createSequentialGroup()
                                .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(l_nama_9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_durasi_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(l_id_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())))
            .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp9_1Layout.createSequentialGroup()
                    .addComponent(lbgambar10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel_lp9_1Layout.setVerticalGroup(
            panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp9_1Layout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(stp_9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_lp9_1Layout.createSequentialGroup()
                        .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_lp9_1Layout.createSequentialGroup()
                        .addComponent(l_id_9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_nama_9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(l_durasi_9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_mulai_9)
                    .addComponent(t_stop_9)
                    .addComponent(t_antrian_9))
                .addContainerGap())
            .addGroup(panel_lp9_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp9_1Layout.createSequentialGroup()
                    .addComponent(lbgambar10, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 191, Short.MAX_VALUE)))
        );

        panel_lp9_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_9.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Jam", "Id", "Nama"
            }
        ));
        tbl_9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_9MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(tbl_9);

        panel_lp9_2.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 242, 310));

        t_kembali9.setText("Kembali");
        t_kembali9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_kembali9ActionPerformed(evt);
            }
        });
        panel_lp9_2.add(t_kembali9, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 80, -1));

        t_ok9.setText("OK");
        t_ok9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ok9ActionPerformed(evt);
            }
        });
        panel_lp9_2.add(t_ok9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 80, -1));

        javax.swing.GroupLayout panel_lp9Layout = new javax.swing.GroupLayout(panel_lp9);
        panel_lp9.setLayout(panel_lp9Layout);
        panel_lp9Layout.setHorizontalGroup(
            panel_lp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_lp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel_lp9Layout.createSequentialGroup()
                    .addComponent(panel_lp9_1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panel_lp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panel_lp9_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_lp9Layout.setVerticalGroup(
            panel_lp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_lp9Layout.createSequentialGroup()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel_lp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp9Layout.createSequentialGroup()
                    .addGap(0, 34, Short.MAX_VALUE)
                    .addComponent(panel_lp9_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(panel_lp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_lp9Layout.createSequentialGroup()
                    .addGap(0, 35, Short.MAX_VALUE)
                    .addComponent(panel_lp9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout panelTransparan13Layout = new javax.swing.GroupLayout(panelTransparan13);
        panelTransparan13.setLayout(panelTransparan13Layout);
        panelTransparan13Layout.setHorizontalGroup(
            panelTransparan13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panel_lp7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panel_lp8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(panel_lp9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelTransparan13Layout.setVerticalGroup(
            panelTransparan13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTransparan13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panel_lp9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_lp8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_lp7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelTransparan41.setBackground(new java.awt.Color(102, 102, 102));

        i_hal.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        i_hal.setForeground(new java.awt.Color(0, 0, 0));
        i_hal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        i_hal.setText("1");

        t_.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Previous/Previous_24x24.png"))); // NOI18N
        t_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ActionPerformed(evt);
            }
        });

        t_next.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Next/Next_24x24.png"))); // NOI18N
        t_next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_nextActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelTransparan41Layout = new javax.swing.GroupLayout(panelTransparan41);
        panelTransparan41.setLayout(panelTransparan41Layout);
        panelTransparan41Layout.setHorizontalGroup(
            panelTransparan41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan41Layout.createSequentialGroup()
                .addComponent(t_)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(i_hal, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(t_next))
        );
        panelTransparan41Layout.setVerticalGroup(
            panelTransparan41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(t_, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addComponent(t_next, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addComponent(i_hal, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelTransparan14Layout = new javax.swing.GroupLayout(panelTransparan14);
        panelTransparan14.setLayout(panelTransparan14Layout);
        panelTransparan14Layout.setHorizontalGroup(
            panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan14Layout.createSequentialGroup()
                .addContainerGap(764, Short.MAX_VALUE)
                .addComponent(panelTransparan41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelTransparan14Layout.createSequentialGroup()
                    .addGap(0, 0, 0)
                    .addComponent(panelTransparan13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelTransparan14Layout.createSequentialGroup()
                    .addGap(0, 0, 0)
                    .addComponent(panelTransparan12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelTransparan14Layout.createSequentialGroup()
                    .addGap(0, 0, 0)
                    .addComponent(panelTransparan11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        panelTransparan14Layout.setVerticalGroup(
            panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan14Layout.createSequentialGroup()
                .addContainerGap(359, Short.MAX_VALUE)
                .addComponent(panelTransparan41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelTransparan14Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelTransparan13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelTransparan14Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelTransparan12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(panelTransparan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelTransparan14Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelTransparan11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        btnkonfirm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Icon - Konfirmasi Lap.png"))); // NOI18N
        btnkonfirm.setText("Konfirmasi");
        btnkonfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkonfirmActionPerformed(evt);
            }
        });

        btnhome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Icon - Home.png"))); // NOI18N
        btnhome.setText("Home");
        btnhome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhomeActionPerformed(evt);
            }
        });

        btntransaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Icon - Transaksi.png"))); // NOI18N
        btntransaksi.setText("Transaksi");
        btntransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntransaksiActionPerformed(evt);
            }
        });

        btnkeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Icon - Logout.png"))); // NOI18N
        btnkeluar.setText("Keluar");
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });

        btnsewa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Icon - Booking.png"))); // NOI18N
        btnsewa.setText("Sewa Lapangan");
        btnsewa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsewaActionPerformed(evt);
            }
        });

        tanggal.setFont(new java.awt.Font("Calisto MT", 1, 36)); // NOI18N
        tanggal.setForeground(new java.awt.Color(255, 255, 255));
        tanggal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tanggal.setText("tgl");

        javax.swing.GroupLayout panelTransparan1Layout = new javax.swing.GroupLayout(panelTransparan1);
        panelTransparan1.setLayout(panelTransparan1Layout);
        panelTransparan1Layout.setHorizontalGroup(
            panelTransparan1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnhome, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnsewa, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnkonfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btntransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnkeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        panelTransparan1Layout.setVerticalGroup(
            panelTransparan1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTransparan1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnkonfirm, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                    .addComponent(btnhome)
                    .addComponent(btntransaksi, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                    .addComponent(btnkeluar, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                    .addComponent(btnsewa))
                .addContainerGap())
            .addGroup(panelTransparan1Layout.createSequentialGroup()
                .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tanggal1.setFont(new java.awt.Font("Comic Sans MS", 1, 32)); // NOI18N
        tanggal1.setForeground(new java.awt.Color(255, 255, 255));
        tanggal1.setText("Fantastic V Futsal");

        javax.swing.GroupLayout panel_utamaLayout = new javax.swing.GroupLayout(panel_utama);
        panel_utama.setLayout(panel_utamaLayout);
        panel_utamaLayout.setHorizontalGroup(
            panel_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelTransparan1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel_utamaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(home)
                .addGap(18, 18, 18)
                .addGroup(panel_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tanggal1, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelTransparan14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(264, Short.MAX_VALUE))
        );
        panel_utamaLayout.setVerticalGroup(
            panel_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_utamaLayout.createSequentialGroup()
                .addComponent(panelTransparan1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_utamaLayout.createSequentialGroup()
                        .addComponent(tanggal1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(panelTransparan14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(panel_utamaLayout.createSequentialGroup()
                        .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(417, 417, 417))))
        );

        getContentPane().add(panel_utama, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1350, 690));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Soccer-Ball-Wallpaper-HD-Desktop-Background-2014-Soccer-Ball-Wallpaper.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1350, 690));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t_mulai_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_3ActionPerformed
        if (!l_id_3.getText().equals("") && !l_nama_3.getText().equals("") && !l_durasi_3.getText().equals("")) {
            getIndex3();
            timer3.start();
            stp_3.setForeground(Color.black);
            t_ok3.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_3ActionPerformed

    private void t_stop_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_3ActionPerformed
        timer3.stop();
        stp_3.setText("Selesai !");
        stp_3.setForeground(Color.black);
        t_ok3.setEnabled(true);
    }//GEN-LAST:event_t_stop_3ActionPerformed

    private void t_antrian_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_3ActionPerformed
        panel_lp3_1.setVisible(false);
        panel_lp3_2.setVisible(true);
        hapustbl3();
        getdatabooking3();
    }//GEN-LAST:event_t_antrian_3ActionPerformed

    private void t_kembali3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali3ActionPerformed
        panel_lp3_1.setVisible(true);
        panel_lp3_2.setVisible(false);
    }//GEN-LAST:event_t_kembali3ActionPerformed

    private void t_mulai_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_2ActionPerformed
        if (!l_id_2.getText().equals("") && !l_nama_2.getText().equals("") && !l_durasi_2.getText().equals("")) {
            getIndex2();
            timer2.start();
            stp_2.setForeground(Color.black);
            t_ok2.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_2ActionPerformed

    private void t_stop_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_2ActionPerformed
        timer2.stop();
        stp_2.setText("Selesai !");
        stp_2.setForeground(Color.black);
        t_ok2.setEnabled(true);
    }//GEN-LAST:event_t_stop_2ActionPerformed

    private void t_antrian_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_2ActionPerformed
        panel_lp2_1.setVisible(false);
        panel_lp2_2.setVisible(true);
        hapustbl2();
        getdatabooking2();
    }//GEN-LAST:event_t_antrian_2ActionPerformed

    private void t_mulai_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_1ActionPerformed
        if (!l_id_1.getText().equals("") && !l_nama_1.getText().equals("") && !l_durasi_1.getText().equals("")) {
            getIndex1();
            timer1.start();
            stp_1.setForeground(Color.black);
            t_ok1.setEnabled(false);
        }

    }//GEN-LAST:event_t_mulai_1ActionPerformed

    private void t_stop_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_1ActionPerformed
        timer1.stop();
        stp_1.setText("Selesai !");
        stp_1.setForeground(Color.black);
        initSelesai1();
        t_ok1.setEnabled(true);
    }//GEN-LAST:event_t_stop_1ActionPerformed

    private void t_antrian_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_1ActionPerformed
        panel_lp1_1.setVisible(false);
        panel_lp1_2.setVisible(true);
        hapustbl1();
        getdatabooking1();
    }//GEN-LAST:event_t_antrian_1ActionPerformed

    private void t_ok3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok3ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id3 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_3.setText(idb);
        l_nama_3.setText(nm);
        l_durasi_3.setText(drs);
        panel_lp3_1.setVisible(true);
        panel_lp3_2.setVisible(false);
    }//GEN-LAST:event_t_ok3ActionPerformed

    private void t_ok2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok2ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id2 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_2.setText(idb);
        l_nama_2.setText(nm);
        l_durasi_2.setText(drs);
        panel_lp2_1.setVisible(true);
        panel_lp2_2.setVisible(false);
    }//GEN-LAST:event_t_ok2ActionPerformed

    private void t_kembali2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali2ActionPerformed
        panel_lp2_1.setVisible(true);
        panel_lp2_2.setVisible(false);
    }//GEN-LAST:event_t_kembali2ActionPerformed

    private void t_ok1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok1ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id1 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_1.setText(idb);
        l_nama_1.setText(nm);
        l_durasi_1.setText(drs);
        panel_lp1_1.setVisible(true);
        panel_lp1_2.setVisible(false);
    }//GEN-LAST:event_t_ok1ActionPerformed

    private void t_kembali1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali1ActionPerformed
        panel_lp1_1.setVisible(true);
        panel_lp1_2.setVisible(false);
    }//GEN-LAST:event_t_kembali1ActionPerformed

    private void tbl_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_1MouseClicked
        GetData_antri1();
    }//GEN-LAST:event_tbl_1MouseClicked

    private void t_mulai_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_4ActionPerformed
        if (!l_id_4.getText().equals("") && !l_nama_4.getText().equals("") && !l_durasi_4.getText().equals("")) {
            getIndex4();
            timer4.start();
            stp_4.setForeground(Color.black);
            t_ok4.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_4ActionPerformed

    private void t_stop_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_4ActionPerformed
        timer4.stop();
        stp_4.setText("Selesai !");
        stp_4.setForeground(Color.black);
        initSelesai4();
        t_ok4.setEnabled(true);
    }//GEN-LAST:event_t_stop_4ActionPerformed

    private void t_antrian_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_4ActionPerformed
        panel_lp4_1.setVisible(false);
        panel_lp4_2.setVisible(true);
        hapustbl4();
        getdatabooking4();
    }//GEN-LAST:event_t_antrian_4ActionPerformed

    private void tbl_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_4MouseClicked
        GetData_antri4();
    }//GEN-LAST:event_tbl_4MouseClicked

    private void t_ok4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok4ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id4 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_4.setText(idb);
        l_nama_4.setText(nm);
        l_durasi_4.setText(drs);
        panel_lp4_1.setVisible(true);
        panel_lp4_2.setVisible(false);
    }//GEN-LAST:event_t_ok4ActionPerformed

    private void t_kembali4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali4ActionPerformed
        panel_lp4_1.setVisible(true);
        panel_lp4_2.setVisible(false);
    }//GEN-LAST:event_t_kembali4ActionPerformed

    private void t_mulai_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_5ActionPerformed
        if (!l_id_5.getText().equals("") && !l_nama_5.getText().equals("") && !l_durasi_5.getText().equals("")) {
            getIndex5();
            timer5.start();
            stp_5.setForeground(Color.black);
            t_ok5.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_5ActionPerformed

    private void t_stop_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_5ActionPerformed
        timer5.stop();
        stp_5.setText("Selesai !");
        stp_5.setForeground(Color.black);
        initSelesai5();
        t_ok5.setEnabled(true);
    }//GEN-LAST:event_t_stop_5ActionPerformed

    private void t_antrian_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_5ActionPerformed
        panel_lp5_1.setVisible(false);
        panel_lp5_2.setVisible(true);
        hapustbl5();
        getdatabooking5();
    }//GEN-LAST:event_t_antrian_5ActionPerformed

    private void t_ok5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok5ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id5 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_5.setText(idb);
        l_nama_5.setText(nm);
        l_durasi_5.setText(drs);
        panel_lp5_1.setVisible(true);
        panel_lp5_2.setVisible(false);
    }//GEN-LAST:event_t_ok5ActionPerformed

    private void t_kembali5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali5ActionPerformed
        panel_lp5_1.setVisible(true);
        panel_lp5_2.setVisible(false);
    }//GEN-LAST:event_t_kembali5ActionPerformed

    private void t_mulai_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_6ActionPerformed
        if (!l_id_6.getText().equals("") && !l_nama_6.getText().equals("") && !l_durasi_6.getText().equals("")) {
            getIndex6();
            timer6.start();
            stp_6.setForeground(Color.black);
            t_ok6.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_6ActionPerformed

    private void t_stop_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_6ActionPerformed
        timer6.stop();
        stp_6.setText("Selesai !");
        stp_6.setForeground(Color.black);
        initSelesai6();
        t_ok6.setEnabled(true);
    }//GEN-LAST:event_t_stop_6ActionPerformed

    private void t_antrian_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_6ActionPerformed
        panel_lp6_1.setVisible(false);
        panel_lp6_2.setVisible(true);
        hapustbl6();
        getdatabooking6();
    }//GEN-LAST:event_t_antrian_6ActionPerformed

    private void t_kembali6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali6ActionPerformed
        panel_lp6_1.setVisible(true);
        panel_lp6_2.setVisible(false);
    }//GEN-LAST:event_t_kembali6ActionPerformed

    private void t_ok6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok6ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id6 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_6.setText(idb);
        l_nama_6.setText(nm);
        l_durasi_6.setText(drs);
        panel_lp6_1.setVisible(true);
        panel_lp6_2.setVisible(false);
    }//GEN-LAST:event_t_ok6ActionPerformed

    private void t_mulai_7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_7ActionPerformed
        if (!l_id_7.getText().equals("") && !l_nama_7.getText().equals("") && !l_durasi_7.getText().equals("")) {
            getIndex7();
            timer7.start();
            stp_7.setForeground(Color.black);
            t_ok7.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_7ActionPerformed

    private void t_stop_7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_7ActionPerformed
        timer7.stop();
        stp_7.setText("Selesai !");
        stp_7.setForeground(Color.black);
        initSelesai7();
        t_ok7.setEnabled(true);
    }//GEN-LAST:event_t_stop_7ActionPerformed

    private void t_antrian_7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_7ActionPerformed
        panel_lp7_1.setVisible(false);
        panel_lp7_2.setVisible(true);
        hapustbl7();
        getdatabooking7();
    }//GEN-LAST:event_t_antrian_7ActionPerformed

    private void tbl_7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_7MouseClicked
        GetData_antri7();
    }//GEN-LAST:event_tbl_7MouseClicked

    private void t_ok7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok7ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id7 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_7.setText(idb);
        l_nama_7.setText(nm);
        l_durasi_7.setText(drs);
        panel_lp7_1.setVisible(true);
        panel_lp7_2.setVisible(false);
    }//GEN-LAST:event_t_ok7ActionPerformed

    private void t_kembali7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali7ActionPerformed
        panel_lp7_1.setVisible(true);
        panel_lp7_2.setVisible(false);
    }//GEN-LAST:event_t_kembali7ActionPerformed

    private void t_mulai_8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_8ActionPerformed
        if (!l_id_8.getText().equals("") && !l_nama_8.getText().equals("") && !l_durasi_8.getText().equals("")) {
            getIndex8();
            timer8.start();
            stp_8.setForeground(Color.black);
            t_ok8.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_8ActionPerformed

    private void t_stop_8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_8ActionPerformed
        timer8.stop();
        stp_8.setText("Selesai !");
        stp_8.setForeground(Color.black);
        initSelesai8();
        t_ok8.setEnabled(true);
    }//GEN-LAST:event_t_stop_8ActionPerformed

    private void t_antrian_8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_8ActionPerformed
        panel_lp8_1.setVisible(false);
        panel_lp8_2.setVisible(true);
        hapustbl8();
        getdatabooking8();
    }//GEN-LAST:event_t_antrian_8ActionPerformed

    private void t_ok8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok8ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id8 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_8.setText(idb);
        l_nama_8.setText(nm);
        l_durasi_8.setText(drs);
        panel_lp8_1.setVisible(true);
        panel_lp8_2.setVisible(false);
    }//GEN-LAST:event_t_ok8ActionPerformed

    private void t_kembali8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali8ActionPerformed
        panel_lp8_1.setVisible(true);
        panel_lp8_2.setVisible(false);
    }//GEN-LAST:event_t_kembali8ActionPerformed

    private void t_mulai_9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mulai_9ActionPerformed
        if (!l_id_9.getText().equals("") && !l_nama_9.getText().equals("") && !l_durasi_9.getText().equals("")) {
            getIndex9();
            timer9.start();
            stp_9.setForeground(Color.black);
            t_ok9.setEnabled(false);
        }
    }//GEN-LAST:event_t_mulai_9ActionPerformed

    private void t_stop_9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_stop_9ActionPerformed
        timer9.stop();
        stp_9.setText("Selesai !");
        stp_9.setForeground(Color.black);
        initSelesai9();
        t_ok9.setEnabled(true);
    }//GEN-LAST:event_t_stop_9ActionPerformed

    private void t_antrian_9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_antrian_9ActionPerformed
        panel_lp9_1.setVisible(false);
        panel_lp9_2.setVisible(true);
        hapustbl9();
        getdatabooking9();
    }//GEN-LAST:event_t_antrian_9ActionPerformed

    private void t_kembali9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_kembali9ActionPerformed
        panel_lp9_1.setVisible(true);
        panel_lp9_2.setVisible(false);
    }//GEN-LAST:event_t_kembali9ActionPerformed

    private void t_ok9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ok9ActionPerformed
        String idb = null, nm = null, drs = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id9 + "'");
            while (res.next()) {
                idb = res.getString("id_booking");
                nm = res.getString("nama");
                drs = res.getString("durasi");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        l_id_9.setText(idb);
        l_nama_9.setText(nm);
        l_durasi_9.setText(drs);
        panel_lp9_1.setVisible(true);
        panel_lp9_2.setVisible(false);
    }//GEN-LAST:event_t_ok9ActionPerformed

    private void t_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ActionPerformed
        int hal = Integer.parseInt(i_hal.getText());
        hal = hal - 1;
        if (hal >= 1) {
            i_hal.setText(Integer.toString(hal));
            halaman();
        }
        home();
    }//GEN-LAST:event_t_ActionPerformed

    private void t_nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_nextActionPerformed
        int hal = Integer.parseInt(i_hal.getText());
        hal = hal + 1;
        if (hal <= 3) {
            i_hal.setText(Integer.toString(hal));
            halaman();
        }
        home();
    }//GEN-LAST:event_t_nextActionPerformed

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        home();
    }//GEN-LAST:event_homeMouseClicked

    private void tbl_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_2MouseClicked
        GetData_antri2();
    }//GEN-LAST:event_tbl_2MouseClicked

    private void tbl_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_3MouseClicked
        GetData_antri3();
    }//GEN-LAST:event_tbl_3MouseClicked

    private void tbl_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_5MouseClicked
        GetData_antri5();
    }//GEN-LAST:event_tbl_5MouseClicked

    private void tbl_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_6MouseClicked
        GetData_antri6();
    }//GEN-LAST:event_tbl_6MouseClicked

    private void tbl_8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_8MouseClicked
        GetData_antri8();
    }//GEN-LAST:event_tbl_8MouseClicked

    private void tbl_9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_9MouseClicked
        GetData_antri9();
    }//GEN-LAST:event_tbl_9MouseClicked

    private void tbl_1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_1MouseMoved

    }//GEN-LAST:event_tbl_1MouseMoved

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
        String ObjButtons[] = {"Yes", "No"};
        int pilihan = JOptionPane.showOptionDialog(null, "Apakah Anda Yakin Ingin Keluar Dari Aplikasi Fantastic V Futsal ?", "Message", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, ObjButtons, ObjButtons[1]);
        if (pilihan == 0) {
            this.dispose();
            //System.exit(0);
            new d_login(this, rootPaneCheckingEnabled).show();

        }
    }//GEN-LAST:event_btnkeluarActionPerformed

    private void btnsewaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsewaActionPerformed
        new d_booking(this, rootPaneCheckingEnabled).show();
    }//GEN-LAST:event_btnsewaActionPerformed

    private void btnkonfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkonfirmActionPerformed
        new d_konfirmasi(this, rootPaneCheckingEnabled).show();
    }//GEN-LAST:event_btnkonfirmActionPerformed

    private void btnhomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhomeActionPerformed
        home();
    }//GEN-LAST:event_btnhomeActionPerformed

    private void btntransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntransaksiActionPerformed
        new d_transaksi_futsal(this, rootPaneCheckingEnabled).show();
    }//GEN-LAST:event_btntransaksiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(f_futsal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(f_futsal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(f_futsal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(f_futsal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new f_futsal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnhome;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnkonfirm;
    private javax.swing.JButton btnsewa;
    private javax.swing.JButton btntransaksi;
    private javax.swing.JLabel home;
    private javax.swing.JLabel i_hal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel l_durasi_1;
    private javax.swing.JLabel l_durasi_2;
    private javax.swing.JLabel l_durasi_3;
    private javax.swing.JLabel l_durasi_4;
    private javax.swing.JLabel l_durasi_5;
    private javax.swing.JLabel l_durasi_6;
    private javax.swing.JLabel l_durasi_7;
    private javax.swing.JLabel l_durasi_8;
    private javax.swing.JLabel l_durasi_9;
    private javax.swing.JLabel l_id_1;
    private javax.swing.JLabel l_id_2;
    private javax.swing.JLabel l_id_3;
    private javax.swing.JLabel l_id_4;
    private javax.swing.JLabel l_id_5;
    private javax.swing.JLabel l_id_6;
    private javax.swing.JLabel l_id_7;
    private javax.swing.JLabel l_id_8;
    private javax.swing.JLabel l_id_9;
    private javax.swing.JLabel l_lp1;
    private javax.swing.JLabel l_lp2;
    private javax.swing.JLabel l_lp3;
    private javax.swing.JLabel l_lp4;
    private javax.swing.JLabel l_lp5;
    private javax.swing.JLabel l_lp6;
    private javax.swing.JLabel l_lp7;
    private javax.swing.JLabel l_lp8;
    private javax.swing.JLabel l_lp9;
    private javax.swing.JLabel l_nama_1;
    private javax.swing.JLabel l_nama_2;
    private javax.swing.JLabel l_nama_3;
    private javax.swing.JLabel l_nama_4;
    private javax.swing.JLabel l_nama_5;
    private javax.swing.JLabel l_nama_6;
    private javax.swing.JLabel l_nama_7;
    private javax.swing.JLabel l_nama_8;
    private javax.swing.JLabel l_nama_9;
    private javax.swing.JLabel lbgambar10;
    private javax.swing.JLabel lbgambar2;
    private javax.swing.JLabel lbgambar3;
    private javax.swing.JLabel lbgambar4;
    private javax.swing.JLabel lbgambar5;
    private javax.swing.JLabel lbgambar6;
    private javax.swing.JLabel lbgambar7;
    private javax.swing.JLabel lbgambar8;
    private javax.swing.JLabel lbgambar9;
    private FV.PanelTransparan panelTransparan1;
    private FV.PanelTransparan1 panelTransparan11;
    private FV.PanelTransparan1 panelTransparan12;
    private FV.PanelTransparan1 panelTransparan13;
    private FV.PanelTransparan1 panelTransparan14;
    private FV.PanelTransparan4 panelTransparan41;
    private FV.PanelTransparan panel_lp1;
    private FV.PanelTransparan1 panel_lp1_1;
    private FV.PanelTransparan1 panel_lp1_2;
    private FV.PanelTransparan panel_lp2;
    private FV.PanelTransparan1 panel_lp2_1;
    private FV.PanelTransparan1 panel_lp2_2;
    private FV.PanelTransparan panel_lp3;
    private FV.PanelTransparan1 panel_lp3_1;
    private FV.PanelTransparan1 panel_lp3_2;
    private FV.PanelTransparan panel_lp4;
    private FV.PanelTransparan1 panel_lp4_1;
    private FV.PanelTransparan1 panel_lp4_2;
    private FV.PanelTransparan panel_lp5;
    private FV.PanelTransparan1 panel_lp5_1;
    private FV.PanelTransparan1 panel_lp5_2;
    private FV.PanelTransparan panel_lp6;
    private FV.PanelTransparan1 panel_lp6_1;
    private FV.PanelTransparan1 panel_lp6_2;
    private FV.PanelTransparan panel_lp7;
    private FV.PanelTransparan1 panel_lp7_1;
    private FV.PanelTransparan1 panel_lp7_2;
    private FV.PanelTransparan panel_lp8;
    private FV.PanelTransparan1 panel_lp8_1;
    private FV.PanelTransparan1 panel_lp8_2;
    private FV.PanelTransparan panel_lp9;
    private FV.PanelTransparan1 panel_lp9_1;
    private FV.PanelTransparan1 panel_lp9_2;
    private FV.PanelTransparan1 panel_utama;
    private javax.swing.JLabel stp_1;
    private javax.swing.JLabel stp_2;
    private javax.swing.JLabel stp_3;
    private javax.swing.JLabel stp_4;
    private javax.swing.JLabel stp_5;
    private javax.swing.JLabel stp_6;
    private javax.swing.JLabel stp_7;
    private javax.swing.JLabel stp_8;
    private javax.swing.JLabel stp_9;
    private javax.swing.JButton t_;
    private javax.swing.JButton t_antrian_1;
    private javax.swing.JButton t_antrian_2;
    private javax.swing.JButton t_antrian_3;
    private javax.swing.JButton t_antrian_4;
    private javax.swing.JButton t_antrian_5;
    private javax.swing.JButton t_antrian_6;
    private javax.swing.JButton t_antrian_7;
    private javax.swing.JButton t_antrian_8;
    private javax.swing.JButton t_antrian_9;
    private javax.swing.JButton t_kembali1;
    private javax.swing.JButton t_kembali2;
    private javax.swing.JButton t_kembali3;
    private javax.swing.JButton t_kembali4;
    private javax.swing.JButton t_kembali5;
    private javax.swing.JButton t_kembali6;
    private javax.swing.JButton t_kembali7;
    private javax.swing.JButton t_kembali8;
    private javax.swing.JButton t_kembali9;
    private javax.swing.JButton t_mulai_1;
    private javax.swing.JButton t_mulai_2;
    private javax.swing.JButton t_mulai_3;
    private javax.swing.JButton t_mulai_4;
    private javax.swing.JButton t_mulai_5;
    private javax.swing.JButton t_mulai_6;
    private javax.swing.JButton t_mulai_7;
    private javax.swing.JButton t_mulai_8;
    private javax.swing.JButton t_mulai_9;
    private javax.swing.JButton t_next;
    private javax.swing.JButton t_ok1;
    private javax.swing.JButton t_ok2;
    private javax.swing.JButton t_ok3;
    private javax.swing.JButton t_ok4;
    private javax.swing.JButton t_ok5;
    private javax.swing.JButton t_ok6;
    private javax.swing.JButton t_ok7;
    private javax.swing.JButton t_ok8;
    private javax.swing.JButton t_ok9;
    private javax.swing.JButton t_stop_1;
    private javax.swing.JButton t_stop_2;
    private javax.swing.JButton t_stop_3;
    private javax.swing.JButton t_stop_4;
    private javax.swing.JButton t_stop_5;
    private javax.swing.JButton t_stop_6;
    private javax.swing.JButton t_stop_7;
    private javax.swing.JButton t_stop_8;
    private javax.swing.JButton t_stop_9;
    private javax.swing.JLabel tanggal;
    private javax.swing.JLabel tanggal1;
    private javax.swing.JTable tbl_1;
    private javax.swing.JTable tbl_2;
    private javax.swing.JTable tbl_3;
    private javax.swing.JTable tbl_4;
    private javax.swing.JTable tbl_5;
    private javax.swing.JTable tbl_6;
    private javax.swing.JTable tbl_7;
    private javax.swing.JTable tbl_8;
    private javax.swing.JTable tbl_9;
    // End of variables declaration//GEN-END:variables

}
