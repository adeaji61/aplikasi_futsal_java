/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author User
 */
public class d_konfirmasi extends javax.swing.JDialog {

    /**
     * Creates new form d_akun
     */
    public d_konfirmasi(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initUI();
        c_tampil_barang();
        Date date = new Date();

        getdatabooking0();

    }

    private void initUI() {
        getContentPane().setBackground(new Color(245, 245, 245));

        Dimension windowSize = getSize();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Point centerPoint = ge.getCenterPoint();
        int dx = centerPoint.x - windowSize.width / 2;
        int dy = centerPoint.y - windowSize.height / 2;
        setLocation(dx, dy);
    }

    String idsewa = null;

    public void idsewa() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_booking,5)) as idsewa from sewa");
            while (res.next()) {
                if (res.first() == false) {
                    idsewa = "S00001";
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 5 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    idsewa = "S" + nomor;
                }

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void total() {
        int jumlahBaris = tbl_item1.getRowCount();
        int totalBiaya = 0, totalBiaya2 = 0, totalBiaya3 = 0;
        int jumlahBarang, hargaBarang;
        String total = "0";
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking where id_booking='" + row_id + "'");
            while (res.next()) {
                total = res.getString("total");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        TableModel tabelModel;
        tabelModel = tbl_item1.getModel();
        for (int i = 0; i < jumlahBaris; i++) {
            //jumlahBarang = Integer.parseInt(tabelModel.getValueAt(i, 0).toString());
            hargaBarang = Integer.parseInt(tabelModel.getValueAt(i, 4).toString());
            totalBiaya = totalBiaya + hargaBarang;//(jumlahBarang * hargaBarang);
        }
        totalBiaya2 = Integer.parseInt(total);
        totalBiaya3 = totalBiaya + totalBiaya2;
        i_ttl4.setText(String.valueOf(totalBiaya3));
    }

    public void c_tampil_barang() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select nama_barang from item_sewa");

            c_item1.addItem("-Barang-");
            while (res.next()) {
                c_item1.addItem(res.getString("nama_barang"));
            }
        } catch (Exception ex) {

        }
    }

    public void getdatabooking0() {
        DefaultTableModel model0 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model0.addColumn("Id Booking");
        model0.addColumn("Tanggal");
        model0.addColumn("Lapangan");
        model0.addColumn("Jam");
        model0.addColumn("Status");
        model0.addColumn("Id Member");
        model0.addColumn("Nama");
        model0.addColumn("Id Sewa");
        model0.addColumn("Status Main");
        tbl_0.setModel(model0);
        String idbook = i_idbook.getText();
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking,lapangan where status_main='" + "Pending" + "' and booking.id_lapangan=lapangan.id_lapangan");
            while (res.next()) {

                model0.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("nama_lapangan"),
                    res.getString("jam"),
                    res.getString("status"),
                    res.getString("id_member"),
                    res.getString("nama"),
                    res.getString("id_sewa"),
                    res.getString("status_main")
                });
                tbl_0.setModel(model0);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatabooking() {
        DefaultTableModel model0 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model0.addColumn("Id Booking");
        model0.addColumn("Tanggal");
        model0.addColumn("Lapangan");
        model0.addColumn("Jam");
        model0.addColumn("Status");
        model0.addColumn("Id Member");
        model0.addColumn("Nama");
        model0.addColumn("Id Sewa");
        model0.addColumn("Status Main");
        tbl_0.setModel(model0);
        String idbook = i_idbook.getText();
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from booking lapangan where id_booking='" + idbook + "' and booking.id_lapangan=lapangan.id_lapangan and status_main='Pending'");
            while (res.next()) {

                model0.addRow(new Object[]{
                    res.getString("id_booking"),
                    res.getString("tanggal"),
                    res.getString("nama_lapangan"),
                    res.getString("jam"),
                    res.getString("status"),
                    res.getString("id_member"),
                    res.getString("nama"),
                    res.getString("id_sewa"),
                    res.getString("status_main")
                });
                tbl_0.setModel(model0);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

    }

    public void getdatasewa() {
        DefaultTableModel model1 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        String idbook = i_idbook.getText();
        int no = 1;
        String sw = null;
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from sewa where id_booking='" + idbook + "'");
            while (res.next()) {
                sw = res.getString("id_sewa");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        model1.addColumn("No");
        model1.addColumn("Barang");
        model1.addColumn("Harga");
        model1.addColumn("Qty");
        model1.addColumn("Jumlah");
        tbl_item1.setModel(model1);

        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from sewa,barang where sewa.id_sewa='" + sw + "' and barang.id_barang=sewa.id_barang");
            while (res.next()) {

                model1.addRow(new Object[]{
                    no,
                    res.getString("nama_barang"),
                    res.getString("harga"),
                    res.getString("qty"),
                    res.getString("jumlah")
                });
                no++;
                tbl_item1.setModel(model1);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        i_idsewa.setText(sw);
    }

    String row_id;

    private void GetData_main() {
        int row = tbl_0.getSelectedRow();
        row_id = (tbl_0.getModel().getValueAt(row, 0).toString());
        i_idbook.setText(row_id);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        r_group = new javax.swing.ButtonGroup();
        panelTransparan21 = new FV.PanelTransparan2();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelTransparan31 = new FV.PanelTransparan3();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_0 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        i_idbook = new javax.swing.JTextField();
        t_main = new javax.swing.JButton();
        t_batal1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        c_item1 = new javax.swing.JComboBox<>();
        jLabel26 = new javax.swing.JLabel();
        i_idsewa = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        t_tambah1 = new javax.swing.JButton();
        t_hapus1 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        tbl_item1 = new javax.swing.JTable();
        jLabel28 = new javax.swing.JLabel();
        i_ttl4 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        i_jml2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTransparan21.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(11, 108, 151));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Konfirmasi Lapangan");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(702, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelTransparan21Layout = new javax.swing.GroupLayout(panelTransparan21);
        panelTransparan21.setLayout(panelTransparan21Layout);
        panelTransparan21Layout.setHorizontalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelTransparan21Layout.setVerticalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan21Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(panelTransparan21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 50));

        panelTransparan31.setBackground(new java.awt.Color(51, 51, 51));

        tbl_0.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Booking", "Tanggal", "Lapangan", "Jam", "Status", "Id Member", "Nama", "Status Main"
            }
        ));
        tbl_0.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_0MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_0);

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setText("Cari Kode Boking :");

        i_idbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_idbookActionPerformed(evt);
            }
        });

        t_main.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_main.setText("Main");
        t_main.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_mainActionPerformed(evt);
            }
        });

        t_batal1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal1.setText("Batalkan Booking");
        t_batal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batal1ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reload.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("SEWA BARANG");

        jLabel25.setBackground(new java.awt.Color(255, 255, 255));
        jLabel25.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("Barang ");

        jLabel26.setBackground(new java.awt.Color(255, 255, 255));
        jLabel26.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("Qty");

        i_idsewa.setEditable(false);
        i_idsewa.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel27.setText("Pcs");

        t_tambah1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_tambah1.setText("Tambah");
        t_tambah1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_tambah1ActionPerformed(evt);
            }
        });

        t_hapus1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_hapus1.setText("Hapus");
        t_hapus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hapus1ActionPerformed(evt);
            }
        });

        tbl_item1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Barang", "Harga", "Jumlah", "Total"
            }
        ));
        tbl_item1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_item1MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(tbl_item1);

        jLabel28.setBackground(new java.awt.Color(255, 255, 255));
        jLabel28.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setText("Total");

        i_ttl4.setEditable(false);
        i_ttl4.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        i_ttl4.setText("0");

        jLabel29.setBackground(new java.awt.Color(255, 255, 255));
        jLabel29.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 0, 0));
        jLabel29.setText("ID Sewa");

        i_jml2.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(c_item1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(i_jml2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE))
                            .addComponent(i_idsewa)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(t_tambah1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_hapus1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(41, 41, 41)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(i_ttl4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_ttl4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i_idsewa, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c_item1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(i_jml2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t_hapus1)
                            .addComponent(t_tambah1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(t_main, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_batal1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(i_idbook, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(i_idbook, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                        .addComponent(jLabel6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_main)
                    .addComponent(t_batal1))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout panelTransparan31Layout = new javax.swing.GroupLayout(panelTransparan31);
        panelTransparan31.setLayout(panelTransparan31Layout);
        panelTransparan31Layout.setHorizontalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        panelTransparan31Layout.setVerticalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan31Layout.createSequentialGroup()
                .addContainerGap(69, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        getContentPane().add(panelTransparan31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 650));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Soccer-Ball-Wallpaper-HD-Desktop-Background-2014-Soccer-Ball-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    String r_st = null;
    private void t_mainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_mainActionPerformed
        String idbr = null, ids = i_idsewa.getText(), idb = i_idbook.getText();
        int jumlah_baris = tbl_item1.getRowCount();

        if (!ids.equals("")) {
            try {
                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                stat.execute("delete from sewa where id_sewa ='" + ids + "'");
                stat.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Error : " + e.getMessage());
            }

            try {
                //int i = 0;
                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                for (int i = 0; i < jumlah_baris; i++) {
                    Statement stt = (Statement) koneksi.Getconnection().createStatement();
                    ResultSet res = stt.executeQuery("select * from barang where nama_barang='" + tbl_item1.getValueAt(i, 1).toString() + "'");
                    while (res.next()) {
                        idbr = res.getString("id_barang");
                    }
                    stat.executeUpdate("insert into sewa values("
                            + "'" + ids + "',"
                            + "'" + idbr + "',"
                            + "'" + idb + "',"
                            + "'" + Integer.parseInt(tbl_item1.getValueAt(i, 2).toString()) + "',"
                            + "'" + Integer.parseInt(tbl_item1.getValueAt(i, 3).toString()) + "',"
                            + "'" + Integer.parseInt(tbl_item1.getValueAt(i, 4).toString()) + "')");
                }

                stat.close();
                JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
            }
        }

        try {
            //int i = 0;
            Statement stat = (Statement) koneksi.Getconnection().createStatement();

            stat.executeUpdate("update booking set status_main='" + "Main" + "' where id_booking='" + idb + "'");

            stat.close();
            JOptionPane.showMessageDialog(rootPane, "Lanjut Bermain!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
        }
        getdatabooking0();
        i_idbook.setText("");
        int baris = tbl_item1.getRowCount();
        for (int i = 1; i <= baris; i++) {
            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            model.removeRow(0);
        }
    }//GEN-LAST:event_t_mainActionPerformed

    private void t_batal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batal1ActionPerformed
        try {
            //int i = 0;
            Statement stat = (Statement) koneksi.Getconnection().createStatement();

            stat.executeUpdate("update booking set status_main='" + "Selesai" + "' where id_booking='" + row_id + "'");

            stat.close();
            JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
        }
        getdatabooking0();
        i_idbook.setText("");
    }//GEN-LAST:event_t_batal1ActionPerformed

    private void i_idbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_idbookActionPerformed
        getdatabooking();

    }//GEN-LAST:event_i_idbookActionPerformed

    private void tbl_0MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_0MouseClicked
        GetData_main();
        getdatasewa();
        total();
    }//GEN-LAST:event_tbl_0MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        getdatabooking0();
    }//GEN-LAST:event_jButton3ActionPerformed
    int st1 = 0;
    private void t_tambah1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_tambah1ActionPerformed
        int no = tbl_item1.getRowCount();
        no++;
        t_tambah1.setBackground(Color.CYAN);
        t_hapus1.setBackground(new java.awt.Color(188, 188, 188));

        String item = (String) c_item1.getSelectedItem(), jl = i_jml2.getText(), hr = null;
        int jml;
        String i = i_idsewa.getText();
        if (i.equals("")) {
            JOptionPane.showMessageDialog(null, "Data Tidak Terpilih", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
        } else {
            try {

                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                ResultSet res = stat.executeQuery("select harga_jual from barang where nama_barang='" + item + "'");
                while (res.next()) {
                    Object[] ob = new Object[1];
                    ob[0] = res.getString(1);
                    hr = ((String) ob[0]);
                }
                res.close();
                stat.close();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, ex.getMessage());
            }

            int hg = Integer.parseInt(hr), qty1 = Integer.parseInt(jl);
            jml = hg * qty1;
            String j = Integer.toString(jml);

            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            tbl_item1.getModel();
            List list = new ArrayList<>();
            tbl_item1.setAutoCreateColumnsFromModel(true);
            list.add(no);
            list.add(item);
            list.add(hr);
            list.add(jl);
            list.add(j);

            model.addRow(list.toArray());
            //getdatapesan();
            c_item1.setSelectedItem("-Pilih-");
            i_jml2.setText("");
            st1 = 0;
            total();
        }
    }//GEN-LAST:event_t_tambah1ActionPerformed

    private void t_hapus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hapus1ActionPerformed
        t_hapus1.setBackground(Color.CYAN);
        t_tambah1.setBackground(new java.awt.Color(188, 188, 188));
        st1 = 1;
    }//GEN-LAST:event_t_hapus1ActionPerformed

    private void GetData_View1() {
        int row = tbl_item1.getSelectedRow();
        if (st1 == 1) {
            DefaultTableModel model = (DefaultTableModel) tbl_item1.getModel();
            model.removeRow(row);
        }
    }

    private void tbl_item1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_item1MouseClicked
        GetData_View1();
        total();
    }//GEN-LAST:event_tbl_item1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(d_konfirmasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(d_konfirmasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(d_konfirmasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(d_konfirmasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                d_konfirmasi dialog = new d_konfirmasi(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> c_item1;
    private javax.swing.JTextField i_idbook;
    private javax.swing.JTextField i_idsewa;
    private javax.swing.JTextField i_jml2;
    private javax.swing.JTextField i_ttl4;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane8;
    private FV.PanelTransparan2 panelTransparan21;
    private FV.PanelTransparan3 panelTransparan31;
    private javax.swing.ButtonGroup r_group;
    private javax.swing.JButton t_batal1;
    private javax.swing.JButton t_hapus1;
    private javax.swing.JButton t_main;
    private javax.swing.JButton t_tambah1;
    private javax.swing.JTable tbl_0;
    private javax.swing.JTable tbl_item1;
    // End of variables declaration//GEN-END:variables
}
