/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FV;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DwiY
 */
public class i_png_umum extends javax.swing.JInternalFrame {

    /**
     * Creates new form i_png_umum
     */
    public i_png_umum() {
        initComponents();
        getdatajenis();
        getdatabarang();
        getdataitem();
        getdatalapangan();
        hapus_c_jenis();
        hapus_c_jenis2();
        hapus_c_jenis3();
        c_tampil_jenis();
        c_tampil_jenis2();
        c_tampil_jenis3();
        idjenis();
        idbarang();
        iditem();
        t_tambah2.setBackground(Color.CYAN);
        t_ubah2.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus2.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan2.setText("Simpan");

        t_tambah3.setBackground(Color.CYAN);
        t_ubah3.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus3.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan3.setText("Simpan");

        t_tambah4.setBackground(Color.CYAN);
        t_ubah4.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus4.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan4.setText("Simpan");
    }

    int st2 = 0, st3 = 0, st4 = 0, st5 = 0;

    public void idjenis() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_jenis,2)) as idjenis from jenis_barang");
            while (res.next()) {
                if (res.first() == false) {
                    i_id_jenis.setText("J01");
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 2 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    i_id_jenis.setText("J" + nomor);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void idbarang() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_barang,5)) as idbarang from barang");
            while (res.next()) {
                if (res.first() == false) {
                    i_id_barang.setText("BR00001");
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 5 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    i_id_barang.setText("BR" + nomor);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }
    String idis;

    public void iditem() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select max(right(id_item,3)) as iditem from item_sewa");
            while (res.next()) {
                if (res.first() == false) {
                    idis = "IS001";
                } else {
                    res.last();
                    int autoid = res.getInt(1) + 1;
                    String nomor = String.valueOf(autoid);
                    int nolong = nomor.length();
                    for (int i = 0; i < 3 - nolong; i++) {
                        nomor = "0" + nomor;
                    }
                    idis = "IS" + nomor;
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void hapus_c_jenis() {
        int itemCount = c_jenis_barang.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            c_jenis_barang.removeItemAt(0);
        }
    }

    public void c_tampil_jenis() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select nama_jenis from jenis_barang");

            c_jenis_barang.addItem("-Jenis Barang-");
            while (res.next()) {
                c_jenis_barang.addItem(res.getString("nama_jenis"));
            }
        } catch (Exception ex) {

        }
    }

    public void hapus_c_jenis2() {
        int itemCount = c_jenis_barang4.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            c_jenis_barang4.removeItemAt(0);
        }
    }

    public void c_tampil_jenis2() {
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select nama_jenis from jenis_barang");

            c_jenis_barang4.addItem("-Jenis Barang-");
            while (res.next()) {
                c_jenis_barang4.addItem(res.getString("nama_jenis"));
            }
        } catch (Exception ex) {

        }
    }

    public void hapus_c_jenis3() {
        int itemCount = c_nama_barang4.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            c_nama_barang4.removeItemAt(0);
        }
    }

    public void c_tampil_jenis3() {
        String jenis_barang = (String) c_jenis_barang4.getSelectedItem(), nm_js = null;
        try {
            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select id_jenis from jenis_barang where jenis_barang.nama_jenis='" + jenis_barang + "'");
            while (res.next()) {
                nm_js = res.getString("id_jenis");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select nama_barang from barang where barang.id_jenis='" + nm_js + "'");

            c_nama_barang4.addItem("-Nama Barang-");
            while (res.next()) {
                c_nama_barang4.addItem(res.getString("nama_barang"));
            }
        } catch (Exception ex) {

        }
    }

    public void getdatajenis() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Jenis");
        model.addColumn("Nama Jenis");
        tbl_jenis.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from jenis_barang");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_jenis"),
                    res.getString("nama_jenis"),});
                tbl_jenis.setModel(model);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatabarang() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Satuan");
        model.addColumn("Harga");
        model.addColumn("Min Stok");
        tbl_barang.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from barang,jenis_barang where barang.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_barang"),
                    res.getString("nama_barang"),
                    res.getString("nama_jenis"),
                    res.getString("satuan"),
                    res.getString("harga_jual"),
                    res.getString("min_stok")
                });
                tbl_barang.setModel(model);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdataitem() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Item");
        model.addColumn("Jenis Barang");
        model.addColumn("Nama Barang");
        model.addColumn("Harga Sewa");
        tbl_item_sewa.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from item_sewa,jenis_barang where item_sewa.id_jenis=jenis_barang.id_jenis");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_item"),
                    res.getString("nama_jenis"),
                    res.getString("nama_barang"),
                    res.getString("harga_sewa")
                });
                tbl_item_sewa.setModel(model);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    public void getdatalapangan() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.addColumn("Id Lapangan");
        model.addColumn("Nama Lapangan");
        model.addColumn("Harga");
        model.addColumn("Status");
        tbl_lapangan.setModel(model);
        try {

            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select * from lapangan");
            while (res.next()) {

                model.addRow(new Object[]{
                    res.getString("id_lapangan"),
                    res.getString("nama_lapangan"),
                    res.getString("harga"),
                    res.getString("status")
                });
                tbl_lapangan.setModel(model);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }

    String row_id, row_nama;
    String row_id3, row_nama3, row_jenis3, row_satuan3, row_harga3, row_stok3;
    String row_id4, row_jenis4, row_nama4, row_harga4;
    String row_id5, row_nama5, row_harga5, row_status5;

    private void GetData_View2() {
        int row = tbl_jenis.getSelectedRow();
        row_id = (tbl_jenis.getModel().getValueAt(row, 0).toString());
        row_nama = (tbl_jenis.getModel().getValueAt(row, 1).toString());

        if (st2 == 1) {
            i_id_jenis.setText(row_id);
            i_nama_jenis.setText(row_nama);
        } else if (st2 == 2) {
            i_id_jenis.setText(row_id);
            i_nama_jenis.setText(row_nama);
            t_simpan2.setText("Hapus");
        }

    }

    private void GetData_View3() {
        int row = tbl_barang.getSelectedRow();
        row_id3 = (tbl_barang.getModel().getValueAt(row, 0).toString());
        row_nama3 = (tbl_barang.getModel().getValueAt(row, 1).toString());
        row_jenis3 = (tbl_barang.getModel().getValueAt(row, 2).toString());
        row_satuan3 = (tbl_barang.getModel().getValueAt(row, 3).toString());
        row_harga3 = (tbl_barang.getModel().getValueAt(row, 4).toString());
        row_stok3 = (tbl_barang.getModel().getValueAt(row, 5).toString());

        if (st3 == 1) {
            i_id_barang.setText(row_id3);
            i_nama_barang.setText(row_nama3);
            c_jenis_barang.setSelectedItem(row_jenis3);
            i_satuan_barang.setText(row_satuan3);
            i_harga_barang.setText(row_harga3);
            i_min_stok.setText(row_stok3);
        } else if (st3 == 2) {
            i_id_barang.setText(row_id3);
            i_nama_barang.setText(row_nama3);
            c_jenis_barang.setSelectedItem(row_jenis3);
            i_satuan_barang.setText(row_satuan3);
            i_harga_barang.setText(row_harga3);
            i_min_stok.setText(row_stok3);
            t_simpan3.setText("Hapus");
        }
    }

    private void GetData_View4() {
        int row = tbl_item_sewa.getSelectedRow();
        row_id4 = (tbl_item_sewa.getModel().getValueAt(row, 0).toString());
        row_jenis4 = (tbl_item_sewa.getModel().getValueAt(row, 1).toString());
        row_nama4 = (tbl_item_sewa.getModel().getValueAt(row, 2).toString());
        row_harga4 = (tbl_item_sewa.getModel().getValueAt(row, 3).toString());

        if (st4 == 1) {
            c_jenis_barang4.setSelectedItem(row_jenis4);
            c_nama_barang4.setSelectedItem(row_nama4);
            i_harga_sewa.setText(row_harga4);
        } else if (st4 == 2) {
            c_jenis_barang4.setSelectedItem(row_jenis4);
            c_nama_barang4.setSelectedItem(row_nama4);
            i_harga_sewa.setText(row_harga4);
            t_simpan4.setText("Hapus");
        }
    }

    private void GetData_View5() {
        int row = tbl_lapangan.getSelectedRow();
        row_id5 = (tbl_lapangan.getModel().getValueAt(row, 0).toString());
        row_nama5 = (tbl_lapangan.getModel().getValueAt(row, 1).toString());
        row_harga5 = (tbl_lapangan.getModel().getValueAt(row, 2).toString());
        row_status5 = (tbl_lapangan.getModel().getValueAt(row, 3).toString());

        i_id_lapangan.setText(row_id5);
        i_nama_lapangan.setText(row_nama5);
        i_harga_lapangan.setText(row_harga5);
        c_status_lapangan.setSelectedItem(row_status5);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTransparan21 = new FV.PanelTransparan2();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelTransparan31 = new FV.PanelTransparan3();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        p_jenis_barang = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_jenis = new javax.swing.JTable();
        t_tambah2 = new javax.swing.JButton();
        t_ubah2 = new javax.swing.JButton();
        t_hapus2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        i_id_jenis = new javax.swing.JTextField();
        i_nama_jenis = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        t_simpan2 = new javax.swing.JButton();
        t_batal2 = new javax.swing.JButton();
        l_ubah = new javax.swing.JLabel();
        p_tambah_barang = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tbl_barang = new javax.swing.JTable();
        t_tambah3 = new javax.swing.JButton();
        t_ubah3 = new javax.swing.JButton();
        t_hapus3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        i_id_barang = new javax.swing.JTextField();
        i_nama_barang = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        t_simpan3 = new javax.swing.JButton();
        t_batal3 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        c_jenis_barang = new javax.swing.JComboBox<>();
        i_harga_barang = new javax.swing.JTextField();
        i_satuan_barang = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        i_min_stok = new javax.swing.JTextField();
        l_ubah1 = new javax.swing.JLabel();
        p_item_sewa = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_item_sewa = new javax.swing.JTable();
        t_tambah4 = new javax.swing.JButton();
        t_ubah4 = new javax.swing.JButton();
        t_hapus4 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        t_simpan4 = new javax.swing.JButton();
        t_batal4 = new javax.swing.JButton();
        c_jenis_barang4 = new javax.swing.JComboBox<>();
        c_nama_barang4 = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        i_harga_sewa = new javax.swing.JTextField();
        l_ubah2 = new javax.swing.JLabel();
        p_item_sewa1 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tbl_lapangan = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        t_simpan5 = new javax.swing.JButton();
        t_batal5 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        i_id_lapangan = new javax.swing.JTextField();
        i_nama_lapangan = new javax.swing.JTextField();
        i_harga_lapangan = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        c_status_lapangan = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setTitle("Pengaturan Umum");
        setPreferredSize(new java.awt.Dimension(910, 530));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTransparan21.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(11, 108, 151));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Pengaturan");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(802, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelTransparan21Layout = new javax.swing.GroupLayout(panelTransparan21);
        panelTransparan21.setLayout(panelTransparan21Layout);
        panelTransparan21Layout.setHorizontalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelTransparan21Layout.setVerticalGroup(
            panelTransparan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan21Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(panelTransparan21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 50));

        panelTransparan31.setBackground(new java.awt.Color(51, 51, 51));

        tbl_jenis.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Jenis", "Nama Jenis"
            }
        ));
        tbl_jenis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_jenisMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_jenis);

        t_tambah2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        t_tambah2.setText("Tambah");
        t_tambah2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_tambah2ActionPerformed(evt);
            }
        });

        t_ubah2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/edit.png"))); // NOI18N
        t_ubah2.setText("Ubah");
        t_ubah2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ubah2ActionPerformed(evt);
            }
        });

        t_hapus2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_hapus2.setText("Hapus");
        t_hapus2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hapus2ActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel3.setText("Id Jenis");

        i_id_jenis.setEditable(false);
        i_id_jenis.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_nama_jenis.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel5.setText("Nama Jenis");

        t_simpan2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan2.setText("Simpan");
        t_simpan2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpan2ActionPerformed(evt);
            }
        });

        t_batal2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal2.setText("Batal");
        t_batal2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batal2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_id_jenis, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_nama_jenis))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(t_simpan2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_batal2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_id_jenis, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_nama_jenis, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_batal2)
                    .addComponent(t_simpan2))
                .addContainerGap())
        );

        l_ubah.setBackground(new java.awt.Color(255, 255, 255));
        l_ubah.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        l_ubah.setText("Tambah Jenis Barang");

        javax.swing.GroupLayout p_jenis_barangLayout = new javax.swing.GroupLayout(p_jenis_barang);
        p_jenis_barang.setLayout(p_jenis_barangLayout);
        p_jenis_barangLayout.setHorizontalGroup(
            p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_jenis_barangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(p_jenis_barangLayout.createSequentialGroup()
                        .addComponent(t_tambah2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_ubah2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_hapus2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(l_ubah, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        p_jenis_barangLayout.setVerticalGroup(
            p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_jenis_barangLayout.createSequentialGroup()
                .addGroup(p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(p_jenis_barangLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t_tambah2)
                            .addComponent(t_ubah2)
                            .addComponent(t_hapus2)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p_jenis_barangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(l_ubah)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(p_jenis_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Jenis Barang", p_jenis_barang);

        tbl_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Jenis", "Nama Jenis"
            }
        ));
        tbl_barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_barangMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tbl_barang);

        t_tambah3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        t_tambah3.setText("Tambah");
        t_tambah3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_tambah3ActionPerformed(evt);
            }
        });

        t_ubah3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/edit.png"))); // NOI18N
        t_ubah3.setText("Ubah");
        t_ubah3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ubah3ActionPerformed(evt);
            }
        });

        t_hapus3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_hapus3.setText("Hapus");
        t_hapus3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hapus3ActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel8.setText("Id Barang");

        i_id_barang.setEditable(false);
        i_id_barang.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_nama_barang.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel10.setText("Nama Barang");

        t_simpan3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan3.setText("Simpan");
        t_simpan3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpan3ActionPerformed(evt);
            }
        });

        t_batal3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal3.setText("Batal");
        t_batal3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batal3ActionPerformed(evt);
            }
        });

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel16.setText("Jenis Barang");

        i_harga_barang.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_satuan_barang.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel17.setBackground(new java.awt.Color(255, 255, 255));
        jLabel17.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel17.setText("Satuan");

        jLabel19.setBackground(new java.awt.Color(255, 255, 255));
        jLabel19.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel19.setText("Harga Jual");

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel20.setText("Minimum Stok");

        i_min_stok.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_id_barang))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_nama_barang))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 152, Short.MAX_VALUE)
                        .addComponent(t_simpan3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_batal3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(c_jenis_barang, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_satuan_barang))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_harga_barang))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_min_stok)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_id_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_nama_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_jenis_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_satuan_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_harga_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_min_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_batal3)
                    .addComponent(t_simpan3))
                .addContainerGap())
        );

        l_ubah1.setBackground(new java.awt.Color(255, 255, 255));
        l_ubah1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        l_ubah1.setText("Tambah Jenis Barang");

        javax.swing.GroupLayout p_tambah_barangLayout = new javax.swing.GroupLayout(p_tambah_barang);
        p_tambah_barang.setLayout(p_tambah_barangLayout);
        p_tambah_barangLayout.setHorizontalGroup(
            p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_tambah_barangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 473, Short.MAX_VALUE)
                    .addGroup(p_tambah_barangLayout.createSequentialGroup()
                        .addComponent(t_tambah3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_ubah3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_hapus3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l_ubah1, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        p_tambah_barangLayout.setVerticalGroup(
            p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_tambah_barangLayout.createSequentialGroup()
                .addGroup(p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(p_tambah_barangLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t_tambah3)
                            .addComponent(t_ubah3)
                            .addComponent(t_hapus3)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p_tambah_barangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(l_ubah1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(p_tambah_barangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Tambah Barang", p_tambah_barang);

        tbl_item_sewa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Jenis", "Nama Jenis"
            }
        ));
        tbl_item_sewa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_item_sewaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tbl_item_sewaMouseEntered(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_item_sewa);

        t_tambah4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        t_tambah4.setText("Tambah");
        t_tambah4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_tambah4ActionPerformed(evt);
            }
        });

        t_ubah4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/edit.png"))); // NOI18N
        t_ubah4.setText("Ubah");
        t_ubah4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_ubah4ActionPerformed(evt);
            }
        });

        t_hapus4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_hapus4.setText("Hapus");
        t_hapus4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_hapus4ActionPerformed(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel6.setText("Jenis Barang");

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel11.setText("Nama Barang");

        t_simpan4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan4.setText("Simpan");
        t_simpan4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpan4ActionPerformed(evt);
            }
        });

        t_batal4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal4.setText("Batal");
        t_batal4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batal4ActionPerformed(evt);
            }
        });

        c_jenis_barang4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_jenis_barang4ActionPerformed(evt);
            }
        });

        jLabel21.setBackground(new java.awt.Color(255, 255, 255));
        jLabel21.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel21.setText("Harga Sewa");

        i_harga_sewa.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        i_harga_sewa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                i_harga_sewaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 185, Short.MAX_VALUE)
                        .addComponent(t_simpan4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_batal4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(c_nama_barang4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(c_jenis_barang4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_harga_sewa)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_jenis_barang4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_nama_barang4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_harga_sewa, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_batal4)
                    .addComponent(t_simpan4))
                .addContainerGap())
        );

        l_ubah2.setBackground(new java.awt.Color(255, 255, 255));
        l_ubah2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        l_ubah2.setText("Tambah Item Sewa");

        javax.swing.GroupLayout p_item_sewaLayout = new javax.swing.GroupLayout(p_item_sewa);
        p_item_sewa.setLayout(p_item_sewaLayout);
        p_item_sewaLayout.setHorizontalGroup(
            p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_item_sewaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(p_item_sewaLayout.createSequentialGroup()
                        .addComponent(t_tambah4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_ubah4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_hapus4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(l_ubah2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        p_item_sewaLayout.setVerticalGroup(
            p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_item_sewaLayout.createSequentialGroup()
                .addGroup(p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(p_item_sewaLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t_tambah4)
                            .addComponent(t_ubah4)
                            .addComponent(t_hapus4)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p_item_sewaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(l_ubah2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(p_item_sewaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Item Sewa", p_item_sewa);

        tbl_lapangan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Jenis", "Nama Jenis"
            }
        ));
        tbl_lapangan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_lapanganMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tbl_lapanganMouseEntered(evt);
            }
        });
        jScrollPane7.setViewportView(tbl_lapangan);

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel9.setText("Id Lapangan");

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel12.setText("Nama Lapangan");

        t_simpan5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        t_simpan5.setText("Simpan");
        t_simpan5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_simpan5ActionPerformed(evt);
            }
        });

        t_batal5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        t_batal5.setText("Batal");
        t_batal5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_batal5ActionPerformed(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel13.setText("Harga");

        i_id_lapangan.setEditable(false);
        i_id_lapangan.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_nama_lapangan.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        i_harga_lapangan.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel14.setText("Status");

        c_status_lapangan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aktif", "Nonaktif" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGap(0, 185, Short.MAX_VALUE)
                        .addComponent(t_simpan5, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t_batal5, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(i_harga_lapangan))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(i_id_lapangan, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
                            .addComponent(i_nama_lapangan, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(c_status_lapangan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(i_id_lapangan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(i_nama_lapangan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(i_harga_lapangan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_status_lapangan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(t_batal5)
                    .addComponent(t_simpan5))
                .addContainerGap())
        );

        javax.swing.GroupLayout p_item_sewa1Layout = new javax.swing.GroupLayout(p_item_sewa1);
        p_item_sewa1.setLayout(p_item_sewa1Layout);
        p_item_sewa1Layout.setHorizontalGroup(
            p_item_sewa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_item_sewa1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        p_item_sewa1Layout.setVerticalGroup(
            p_item_sewa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p_item_sewa1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(p_item_sewa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Lapangan", p_item_sewa1);

        javax.swing.GroupLayout panelTransparan31Layout = new javax.swing.GroupLayout(panelTransparan31);
        panelTransparan31.setLayout(panelTransparan31Layout);
        panelTransparan31Layout.setHorizontalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTransparan31Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 847, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );
        panelTransparan31Layout.setVerticalGroup(
            panelTransparan31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTransparan31Layout.createSequentialGroup()
                .addContainerGap(68, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
        );

        getContentPane().add(panelTransparan31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 530));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Soccer-Ball-Wallpaper-HD-Desktop-Background-2014-Soccer-Ball-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t_batal5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batal5ActionPerformed
        i_id_lapangan.setText("");
        i_nama_lapangan.setText("");
        i_harga_lapangan.setText("");
        c_status_lapangan.setSelectedIndex(0);
        getdatalapangan();
    }//GEN-LAST:event_t_batal5ActionPerformed

    private void t_simpan5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpan5ActionPerformed
        String id_lp = i_id_lapangan.getText(),
                nm_lp = i_nama_lapangan.getText(),
                hr_lp = i_harga_lapangan.getText(),
                st_lp = (String) c_status_lapangan.getSelectedItem();
        int hr_lp1 = 0;
        if (id_lp.equals("") || nm_lp.equals("") || hr_lp.equals("") || st_lp.equals("")) {
            JOptionPane.showMessageDialog(null, "Masukan Data Dengan Benar", "Gagal Dihapus", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                Statement stat = (Statement) koneksi.Getconnection().createStatement();
                stat.executeUpdate("update lapangan set nama_lapangan='" + nm_lp + "',harga='" + hr_lp + "',status='" + st_lp + "' where id_lapangan='" + id_lp + "'");
                stat.close();
                JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
            }
        }
        i_id_lapangan.setText("");
        i_nama_lapangan.setText("");
        i_harga_lapangan.setText("");
        c_status_lapangan.setSelectedIndex(0);
        getdatajenis();
        getdatabarang();
        getdataitem();
        getdatalapangan();
        hapus_c_jenis();
        hapus_c_jenis2();
        hapus_c_jenis3();
        c_tampil_jenis();
        c_tampil_jenis2();
        c_tampil_jenis3();
    }//GEN-LAST:event_t_simpan5ActionPerformed

    private void tbl_lapanganMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_lapanganMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_lapanganMouseEntered

    private void tbl_lapanganMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_lapanganMouseClicked
        GetData_View5();
    }//GEN-LAST:event_tbl_lapanganMouseClicked

    private void i_harga_sewaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_i_harga_sewaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_i_harga_sewaActionPerformed

    private void c_jenis_barang4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_jenis_barang4ActionPerformed
        hapus_c_jenis3();
        c_tampil_jenis3();
    }//GEN-LAST:event_c_jenis_barang4ActionPerformed

    private void t_batal4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batal4ActionPerformed
        c_jenis_barang4.setSelectedItem("-Jenis Barang-");
        c_nama_barang4.setSelectedItem("-Nama Barang-");
    }//GEN-LAST:event_t_batal4ActionPerformed

    private void t_simpan4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpan4ActionPerformed
        String jenis = (String) c_jenis_barang4.getSelectedItem(),
                nama = (String) c_nama_barang4.getSelectedItem(), nm_js = null,
                harga = i_harga_sewa.getText(), idb = null, ids = null;

        try {
            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select id_jenis from jenis_barang where jenis_barang.nama_jenis='" + jenis + "'");
            while (res.next()) {
                nm_js = res.getString("id_jenis");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        try {
            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select id_barang from barang where barang.nama_barang='" + nama + "'");
            while (res.next()) {
                idb = res.getString("id_barang");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        if (st4 == 0) {
            if (jenis.equals("-Jenis Barang-") || nama.equals("-Nama Barang-") || harga.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("insert into item_sewa values('" + idis + "','" + nm_js + "','" + idb + "','" + nama + "','" + Integer.parseInt(harga) + "')");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        } else if (st4 == 1) {
            if (jenis.equals("-Jenis Barang-") || nama.equals("-Nama Barang-") || harga.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update item_sewa set nama_barang='" + nama + "',harga_sewa='" + Integer.parseInt(harga) + "',id_barang='" + idb + "',id_jenis='" + nm_js + "' where id_item='" + row_id4 + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        } else if (st4 == 2) {
            if (jenis.equals("-Jenis Barang-") || nama.equals("-Nama Barang-")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                int ok = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.OK_CANCEL_OPTION);
                if (ok == 0) {
                    try {
                        Statement stat = (Statement) koneksi.Getconnection().createStatement();
                        stat.execute("delete from item_sewa where id_item ='" + row_id4 + "'");
                        stat.close();
                        JOptionPane.showMessageDialog(null, "Data Berhasil di Hapus");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane, "Gagal dihapus! Error : " + e.getMessage());
                    }
                }
            }
        }
        c_jenis_barang4.setSelectedItem("-Jenis Barang-");
        c_nama_barang4.setSelectedItem("-Nama Barang-");
        i_harga_sewa.setText("");
        getdatajenis();
        getdatabarang();
        getdataitem();
        getdatalapangan();
        iditem();
        hapus_c_jenis();
        hapus_c_jenis2();
        hapus_c_jenis3();
        c_tampil_jenis();
        c_tampil_jenis2();
        c_tampil_jenis3();
    }//GEN-LAST:event_t_simpan4ActionPerformed

    private void t_hapus4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hapus4ActionPerformed
        st4 = 2;
        l_ubah2.setText("Hapus Item Sewa");
        t_hapus4.setBackground(Color.CYAN);
        t_tambah4.setBackground(new java.awt.Color(188, 188, 188));
        t_ubah4.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan4.setText("Hapus");
        c_jenis_barang4.setSelectedItem("-Jenis Barang-");
        c_nama_barang4.setSelectedItem("-Nama Barang-");
        i_harga_sewa.setText("");
    }//GEN-LAST:event_t_hapus4ActionPerformed

    private void t_ubah4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ubah4ActionPerformed
        st4 = 1;
        l_ubah2.setText("Ubah Item Sewa");
        t_ubah4.setBackground(Color.CYAN);
        t_tambah4.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus4.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan4.setText("Simpan");
        c_jenis_barang4.setSelectedItem("-Jenis Barang-");
        c_nama_barang4.setSelectedItem("-Nama Barang-");
        i_harga_sewa.setText("");
    }//GEN-LAST:event_t_ubah4ActionPerformed

    private void t_tambah4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_tambah4ActionPerformed
        st4 = 0;
        iditem();
        l_ubah2.setText("Tambah Item Sewa");
        t_tambah4.setBackground(Color.CYAN);
        t_ubah4.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus4.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan4.setText("Simpan");
        c_jenis_barang4.setSelectedItem("-Jenis Barang-");
        c_nama_barang4.setSelectedItem("-Nama Barang-");
        i_harga_sewa.setText("");
    }//GEN-LAST:event_t_tambah4ActionPerformed

    private void tbl_item_sewaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_item_sewaMouseEntered

    }//GEN-LAST:event_tbl_item_sewaMouseEntered

    private void tbl_item_sewaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_item_sewaMouseClicked
        GetData_View4();
    }//GEN-LAST:event_tbl_item_sewaMouseClicked

    private void t_batal3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batal3ActionPerformed
        i_id_barang.setText("");
        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-Jenis Barang-");
        i_satuan_barang.setText("");
        i_harga_barang.setText("");
        getdatabarang();
    }//GEN-LAST:event_t_batal3ActionPerformed

    private void t_simpan3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpan3ActionPerformed
        String id_barang = i_id_barang.getText(),
                nama_barang = i_nama_barang.getText(),
                jenis_barang = (String) c_jenis_barang.getSelectedItem(),
                satuan = i_satuan_barang.getText(),
                harga = i_harga_barang.getText(),
                stk = i_min_stok.getText(),
                nm_js = null;

        try {
            Statement stat = (Statement) koneksi.Getconnection().createStatement();
            ResultSet res = stat.executeQuery("select id_jenis from jenis_barang where jenis_barang.nama_jenis='" + jenis_barang + "'");
            while (res.next()) {
                nm_js = res.getString("id_jenis");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }

        if (st3 == 0) {
            if (id_barang.equals("") || nama_barang.equals("") || jenis_barang.equals("") || satuan.equals("") || harga.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("insert into barang values('" + id_barang + "','" + nama_barang + "','" + nm_js + "','" + "0" + "','" + satuan + "','" + harga + "','" + "0" + "','" + stk + "')");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        } else if (st3 == 1) {
            if (id_barang.equals("") || nama_barang.equals("") || jenis_barang.equals("") || satuan.equals("") || harga.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update barang set id_barang='" + id_barang + "',nama_barang='" + nama_barang + "',id_jenis='" + nm_js + "',satuan='" + satuan + "',harga_jual='" + harga + "',min_stok='" + stk + "' where id_barang='" + i_id_barang.getText() + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        } else if (st3 == 2) {
            if (id_barang.equals("") || nama_barang.equals("") || jenis_barang.equals("") || satuan.equals("") || harga.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Dihapus", JOptionPane.ERROR_MESSAGE);
            } else {
                int ok = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.OK_CANCEL_OPTION);
                if (ok == 0) {
                    try {
                        Statement stat = (Statement) koneksi.Getconnection().createStatement();
                        stat.execute("delete from barang where id_barang ='" + i_id_barang.getText() + "'");
                        stat.close();
                        JOptionPane.showMessageDialog(null, "Data Berhasil di Hapus");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane, "Gagal dihapus! Error : " + e.getMessage());
                    }
                }
            }
        }
        i_id_barang.setText("");
        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-nama_jenis-");
        i_satuan_barang.setText("");
        i_harga_barang.setText("");
        i_min_stok.setText("");
        getdatajenis();
        getdatabarang();
        getdataitem();
        getdatalapangan();
        idbarang();
        hapus_c_jenis();
        hapus_c_jenis2();
        hapus_c_jenis3();
        c_tampil_jenis();
        c_tampil_jenis2();
        c_tampil_jenis3();
    }//GEN-LAST:event_t_simpan3ActionPerformed

    private void t_hapus3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hapus3ActionPerformed
        st3 = 2;
        l_ubah1.setText("Hapus Barang");
        t_hapus3.setBackground(Color.CYAN);
        t_ubah3.setBackground(new java.awt.Color(188, 188, 188));
        t_tambah3.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan3.setText("Hapus");
        i_id_barang.setText("");
        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-Pilih-");
        i_satuan_barang.setText("");
        i_harga_barang.setText("");
        hapus_c_jenis();
        c_tampil_jenis();
    }//GEN-LAST:event_t_hapus3ActionPerformed

    private void t_ubah3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ubah3ActionPerformed
        st3 = 1;
        l_ubah1.setText("Ubah Barang");
        t_ubah3.setBackground(Color.CYAN);
        t_tambah3.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus3.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan3.setText("Simpan");
        i_id_barang.setText("");
        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-Pilih-");
        i_satuan_barang.setText("");
        i_harga_barang.setText("");
        hapus_c_jenis();
        c_tampil_jenis();
    }//GEN-LAST:event_t_ubah3ActionPerformed

    private void t_tambah3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_tambah3ActionPerformed
        st3 = 0;
        idbarang();
        l_ubah1.setText("Tambah Barang");
        t_tambah3.setBackground(Color.CYAN);
        t_ubah3.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus3.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan3.setText("Simpan");

        i_nama_barang.setText("");
        c_jenis_barang.setSelectedItem("-Jenis Barang-");
        i_satuan_barang.setText("");
        i_harga_barang.setText("");
        hapus_c_jenis();
        c_tampil_jenis();
    }//GEN-LAST:event_t_tambah3ActionPerformed

    private void tbl_barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_barangMouseClicked
        GetData_View3();
    }//GEN-LAST:event_tbl_barangMouseClicked

    private void t_batal2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_batal2ActionPerformed
        i_id_jenis.setText("");
        i_nama_jenis.setText("");
        getdatajenis();
    }//GEN-LAST:event_t_batal2ActionPerformed

    private void t_simpan2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_simpan2ActionPerformed
        String id_jenis = i_id_jenis.getText(),
                nama_jenis = i_nama_jenis.getText();

        if (st2 == 0) {
            if (id_jenis.equals("") || nama_jenis.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    //int i = 0;
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("insert into jenis_barang values('" + id_jenis + "','" + nama_jenis + "')");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        } else if (st2 == 1) {
            if (id_jenis.equals("") || nama_jenis.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Disimpan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    Statement stat = (Statement) koneksi.Getconnection().createStatement();
                    stat.executeUpdate("update jenis_barang set id_jenis='" + i_id_jenis.getText() + "',nama_jenis='" + i_nama_jenis.getText() + "' where id_jenis='" + i_id_jenis.getText() + "'");
                    stat.close();
                    JOptionPane.showMessageDialog(rootPane, "Berhasil Menyimpan!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan! Error : " + e.getMessage());
                }
            }
        } else if (st2 == 2) {
            if (id_jenis.equals("") || nama_jenis.equals("")) {
                JOptionPane.showMessageDialog(null, "Data tidak boleh kosong", "Gagal Dihapus", JOptionPane.ERROR_MESSAGE);
            } else {
                int ok = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.OK_CANCEL_OPTION);
                if (ok == 0) {
                    try {
                        Statement stat = (Statement) koneksi.Getconnection().createStatement();
                        stat.execute("delete from jenis_barang where id_jenis ='" + i_id_jenis.getText() + "'");
                        stat.close();
                        JOptionPane.showMessageDialog(null, "Data Berhasil di Hapus");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane, "Gagal dihapus! Error : " + e.getMessage());
                    }
                }
            }
        }
        i_id_jenis.setText("");
        i_nama_jenis.setText("");
        idjenis();
        getdatajenis();
        getdatabarang();
        getdataitem();
        getdatalapangan();
        hapus_c_jenis();
        hapus_c_jenis2();
        hapus_c_jenis3();
        c_tampil_jenis();
        c_tampil_jenis2();
        c_tampil_jenis3();
    }//GEN-LAST:event_t_simpan2ActionPerformed

    private void t_hapus2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_hapus2ActionPerformed
        st2 = 2;
        l_ubah.setText("Hapus Jenis Barang");
        t_hapus2.setBackground(Color.CYAN);
        t_ubah2.setBackground(new java.awt.Color(188, 188, 188));
        t_tambah2.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan2.setText("Hapus");
        i_id_jenis.setText("");
        i_nama_jenis.setText("");
    }//GEN-LAST:event_t_hapus2ActionPerformed

    private void t_ubah2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_ubah2ActionPerformed
        st2 = 1;
        l_ubah.setText("Ubah Jenis Barang");
        t_ubah2.setBackground(Color.CYAN);
        t_tambah2.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus2.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan2.setText("Simpan");
        i_id_jenis.setText("");
        i_nama_jenis.setText("");
    }//GEN-LAST:event_t_ubah2ActionPerformed

    private void t_tambah2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_tambah2ActionPerformed
        idjenis();
        st2 = 0;

        l_ubah.setText("Tambah Jenis Barang");
        t_tambah2.setBackground(Color.CYAN);
        t_ubah2.setBackground(new java.awt.Color(188, 188, 188));
        t_hapus2.setBackground(new java.awt.Color(188, 188, 188));
        t_simpan2.setText("Simpan");
        i_nama_jenis.setText("");
    }//GEN-LAST:event_t_tambah2ActionPerformed

    private void tbl_jenisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_jenisMouseClicked
        GetData_View2();
    }//GEN-LAST:event_tbl_jenisMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> c_jenis_barang;
    private javax.swing.JComboBox<String> c_jenis_barang4;
    private javax.swing.JComboBox<String> c_nama_barang4;
    private javax.swing.JComboBox<String> c_status_lapangan;
    private javax.swing.JTextField i_harga_barang;
    private javax.swing.JTextField i_harga_lapangan;
    private javax.swing.JTextField i_harga_sewa;
    private javax.swing.JTextField i_id_barang;
    private javax.swing.JTextField i_id_jenis;
    private javax.swing.JTextField i_id_lapangan;
    private javax.swing.JTextField i_min_stok;
    private javax.swing.JTextField i_nama_barang;
    private javax.swing.JTextField i_nama_jenis;
    private javax.swing.JTextField i_nama_lapangan;
    private javax.swing.JTextField i_satuan_barang;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel l_ubah;
    private javax.swing.JLabel l_ubah1;
    private javax.swing.JLabel l_ubah2;
    private javax.swing.JPanel p_item_sewa;
    private javax.swing.JPanel p_item_sewa1;
    private javax.swing.JPanel p_jenis_barang;
    private javax.swing.JPanel p_tambah_barang;
    private FV.PanelTransparan2 panelTransparan21;
    private FV.PanelTransparan3 panelTransparan31;
    private javax.swing.JButton t_batal2;
    private javax.swing.JButton t_batal3;
    private javax.swing.JButton t_batal4;
    private javax.swing.JButton t_batal5;
    private javax.swing.JButton t_hapus2;
    private javax.swing.JButton t_hapus3;
    private javax.swing.JButton t_hapus4;
    private javax.swing.JButton t_simpan2;
    private javax.swing.JButton t_simpan3;
    private javax.swing.JButton t_simpan4;
    private javax.swing.JButton t_simpan5;
    private javax.swing.JButton t_tambah2;
    private javax.swing.JButton t_tambah3;
    private javax.swing.JButton t_tambah4;
    private javax.swing.JButton t_ubah2;
    private javax.swing.JButton t_ubah3;
    private javax.swing.JButton t_ubah4;
    private javax.swing.JTable tbl_barang;
    private javax.swing.JTable tbl_item_sewa;
    private javax.swing.JTable tbl_jenis;
    private javax.swing.JTable tbl_lapangan;
    // End of variables declaration//GEN-END:variables
}
