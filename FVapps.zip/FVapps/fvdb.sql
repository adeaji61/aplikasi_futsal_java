-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2019 at 09:59 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fvdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `id_jenis` varchar(10) NOT NULL,
  `stok` int(10) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `harga_jual` int(10) NOT NULL,
  `harga_beli` int(10) NOT NULL,
  `min_stok` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `id_jenis`, `stok`, `satuan`, `harga_jual`, `harga_beli`, `min_stok`) VALUES
('BR00001', 'Sepatu', 'J01', 0, 'Pcs', 200000, 0, 10),
('BR00002', 'Rompi', 'J06', 0, 'Pcs', 50000, 0, 10),
('BR00003', 'Handuk', 'J01', 0, 'Pcs', 40000, 0, 10),
('BR00004', 'Coca-Cola', 'J05', 0, 'Pcs', 10000, 0, 10),
('BR00005', 'Chitato', 'J04', 0, 'Pcs', 10000, 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id_booking` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `id_lapangan` varchar(20) NOT NULL,
  `jam` varchar(20) NOT NULL,
  `harga` int(10) NOT NULL,
  `durasi` int(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `id_member` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `telepon` varchar(25) NOT NULL,
  `id_sewa` varchar(10) NOT NULL,
  `dp` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `status_main` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id_booking`, `tanggal`, `id_lapangan`, `jam`, `harga`, `durasi`, `status`, `id_member`, `nama`, `telepon`, `id_sewa`, `dp`, `total`, `status_main`) VALUES
('B00001', '2019-02-16', 'L01', '01:00', 70000, 1, 'Member', 'M00001', 'Malih', '897635487', '-', 20000, 70000, 'Lunas'),
('B00002', '2019-02-22', 'L02', '02:00', 70000, 1, 'NonMember', '-', 'Mail', '098754675', '-', 2000, 70000, 'Lunas'),
('B00003', '2019-02-16', 'L01', '03:00', 70000, 1, 'NonMember', '-', 'Ucup', '087886544563', '-', 50000, 70000, 'Lunas'),
('B00004', '2019-02-16', 'L02', '01:00', 70000, 1, 'NonMember', '-', 'Mamat', '085764422331', '-', 30000, 70000, 'Lunas'),
('B00005', '2019-02-16', 'L02', '19:00', 70000, 1, 'NonMember', '-', 'Farid', '08976653666', '-', 25000, 70000, 'Lunas'),
('B00006', '2019-02-18', 'L02', '09:00', 70000, 2, 'NonMember', '-', 'Mulki', '087564455', '-', 90000, 140000, 'Pending'),
('B00007', '2019-02-16', 'L03', '10:00', 70000, 1, 'NonMember', '-', 'Duta', '08566754536', '-', 20000, 70000, 'Pending'),
('B00008', '2019-02-23', 'L04', '23:00', 70000, 1, 'NonMember', '-', 'Asep', '08766552435', '-', 30000, 70000, 'Pending'),
('B00009', '2019-02-17', 'L01', '19:00', 70000, 2, 'NonMember', '-', 'Fakhry', '082258098066', '-', 50000, 140000, 'Pending'),
('B00010', '2019-02-17', 'L02', '19:00', 70000, 1, 'NonMember', '-', 'Dwi', '082258098066', '-', 20000, 70000, 'Pending'),
('B00011', '2019-02-16', 'L03', '19:00', 70000, 2, 'NonMember', '-', 'Riyan', '082258098066', '-', 40000, 140000, 'Pending'),
('B00012', '2019-02-17', 'L03', '19:00', 70000, 2, 'NonMember', '-', 'Dwi', '082258098066', '-', 40000, 140000, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `item_sewa`
--

CREATE TABLE `item_sewa` (
  `id_item` varchar(20) NOT NULL,
  `id_jenis` varchar(20) NOT NULL,
  `id_barang` varchar(20) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_sewa` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_sewa`
--

INSERT INTO `item_sewa` (`id_item`, `id_jenis`, `id_barang`, `nama_barang`, `harga_sewa`) VALUES
('IS001', 'J01', 'BR00001', 'Sepatu', 20000),
('IS002', 'J06', 'BR00002', 'Rompi', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_barang`
--

CREATE TABLE `jenis_barang` (
  `id_jenis` varchar(10) NOT NULL,
  `nama_jenis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_barang`
--

INSERT INTO `jenis_barang` (`id_jenis`, `nama_jenis`) VALUES
('J01', 'Aksesoris'),
('J02', 'Makanan Ringan'),
('J03', 'Cemilan'),
('J04', 'Makanan'),
('J05', 'Minuman'),
('J06', 'Pakaian'),
('J07', 'Perhiasan');

-- --------------------------------------------------------

--
-- Table structure for table `keuangan`
--

CREATE TABLE `keuangan` (
  `tanggal` date NOT NULL,
  `sumber` varchar(50) NOT NULL,
  `id` varchar(20) NOT NULL,
  `debet` int(10) NOT NULL,
  `kredit` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuangan`
--

INSERT INTO `keuangan` (`tanggal`, `sumber`, `id`, `debet`, `kredit`) VALUES
('2019-02-16', 'Sewa Lapangan', 'B00001', 70000, 0),
('2019-02-16', 'Sewa Barang', 'S00001', 70000, 0),
('2019-02-16', 'Sewa Barang', 'S00001', 70000, 0),
('2019-02-22', 'Sewa Lapangan', 'B00002', 70000, 0),
('2019-02-22', 'Sewa Barang', 'S00002', 60000, 0),
('2019-02-16', 'Sewa Lapangan', 'B00003', 70000, 0),
('2019-02-16', 'Sewa Lapangan', 'B00004', 70000, 0),
('2019-02-16', 'Sewa Lapangan', 'B00005', 70000, 0),
('2019-02-18', 'Sewa Lapangan', 'B00006', 140000, 0),
('2019-02-16', 'Sewa Lapangan', 'B00007', 70000, 0),
('2019-02-23', 'Sewa Lapangan', 'B00008', 70000, 0),
('2019-02-17', 'Sewa Lapangan', 'B00009', 140000, 0),
('2019-02-17', 'Sewa Lapangan', 'B00010', 70000, 0),
('2019-02-16', 'Sewa Lapangan', 'B00011', 140000, 0),
('2019-02-17', 'Sewa Lapangan', 'B00012', 140000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lapangan`
--

CREATE TABLE `lapangan` (
  `id_lapangan` varchar(10) NOT NULL,
  `nama_lapangan` varchar(50) NOT NULL,
  `harga` int(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lapangan`
--

INSERT INTO `lapangan` (`id_lapangan`, `nama_lapangan`, `harga`, `status`) VALUES
('L01', 'Lapangan 1', 70000, 'Aktif'),
('L02', 'Lapangan 2', 70000, 'Aktif'),
('L03', 'Lapangan 3', 70000, 'Aktif'),
('L04', 'Lapangan 4', 70000, 'Aktif'),
('L05', 'Lapangan 5', 70000, 'Nonaktif'),
('L06', 'Lapangan 6', 70000, 'Nonaktif'),
('L07', 'Lapangan 7', 70000, 'Nonaktif'),
('L08', 'Lapangan 8', 70000, 'Nonaktif'),
('L09', 'Lapangan 9', 70000, 'Nonaktif');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` varchar(20) NOT NULL,
  `no_ktp` varchar(30) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telp` int(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `no_ktp`, `nama`, `no_telp`, `status`) VALUES
('M00001', '1234567890', 'Malih', 897635487, 'Aktif'),
('M00002', '1324567890', 'Mimin', 987675423, 'Nonaktif');

-- --------------------------------------------------------

--
-- Table structure for table `operasional`
--

CREATE TABLE `operasional` (
  `id_op` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` varchar(10) NOT NULL,
  `id_booking` varchar(10) NOT NULL,
  `id_sewa` varchar(10) NOT NULL,
  `tanggal` date NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_booking`, `id_sewa`, `tanggal`, `total`) VALUES
('BY000001', 'B00003', '-', '2019-02-16', 50000),
('BY000002', 'B00002', '-', '2019-02-16', 2000),
('BY000003', 'B00004', '-', '2019-02-16', 30000),
('BY000004', 'B00001', '-', '2019-02-16', 20000),
('BY000005', 'B00005', '-', '2019-02-16', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` varchar(10) NOT NULL,
  `tanggal` date NOT NULL,
  `id_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `id_jenis` varchar(10) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `harga_beli` int(10) NOT NULL,
  `total_beli` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` varchar(10) NOT NULL,
  `tanggal` date NOT NULL,
  `id_barang` varchar(10) NOT NULL,
  `id_jenis` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `harga` int(10) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE `sewa` (
  `id_sewa` varchar(20) NOT NULL,
  `id_barang` varchar(10) NOT NULL,
  `id_booking` varchar(20) NOT NULL,
  `harga` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
('U01', 'Benidiktus', 'admin', 'admin', 'Admin'),
('U02', 'Ade Aji', 'futsal', 'futsal', 'Kasir Futsal'),
('U03', 'Dwi Yanto', 'store', 'store', 'Kasir Penjualan'),
('U04', 'Fakhry Hilmy', 'fakhry', 'fakhry', 'Kasir Penjualan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id_booking`);

--
-- Indexes for table `item_sewa`
--
ALTER TABLE `item_sewa`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `jenis_barang`
--
ALTER TABLE `jenis_barang`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD PRIMARY KEY (`id_lapangan`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
